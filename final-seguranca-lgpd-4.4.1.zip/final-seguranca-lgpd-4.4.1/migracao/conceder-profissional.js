// FrilaOne — aprova (ou revoga) profissionais Acadêmicos. SÓ quem está em profissionais_aprovados/{uid} (ativo:true) enxerga e aceita
// pedidos de agendamento. O cliente não consegue escrever essa coleção (regras v17).
//   node conceder-profissional.js                          → SIMULAÇÃO: lista candidatos (tipo academico) e quem já está aprovado
//   node conceder-profissional.js --aprovar=UID1,UID2      → simulação do que seria aprovado
//   node conceder-profissional.js --aprovar=UID1 --executar
//   node conceder-profissional.js --revogar=UID1 --executar
// ANTES de aprovar: confira o registro profissional (CRP, OAB, CRN...) no site do conselho. O app não consegue conferir sozinho.
async function executar({ db, aprovar = [], revogar = [], exec = false, agora = Date.now() }) {
  const out = { candidatos: [], aprovados: [], revogados: [], naoEncontrados: [], simulacao: !exec };
  const snap = await db.collection('usuarios').where('tipo', '==', 'academico').get();
  const mapa = {}; snap.forEach((d) => { mapa[d.id] = d.data(); });
  for (const id of Object.keys(mapa)) {
    const ap = await db.collection('profissionais_aprovados').doc(id).get();
    const cm = mapa[id].cadMaster || {};
    out.candidatos.push({ uid: id, nome: mapa[id].nome || '', area: cm.area || '', registro: cm.registro || cm.crp || cm.numeroRegistro || '', aprovado: ap.exists && ap.data().ativo === true });
  }
  for (const id of aprovar) {
    const u = (await db.collection('usuarios').doc(id).get());
    if (!u.exists) { out.naoEncontrados.push(id); continue; }
    if (exec) await db.collection('profissionais_aprovados').doc(id).set({ ativo: true, aprovadoEm: agora, origem: 'conceder-profissional.js' }, { merge: true });
    out.aprovados.push(id);
  }
  for (const id of revogar) {
    if (exec) await db.collection('profissionais_aprovados').doc(id).set({ ativo: false, revogadoEm: agora }, { merge: true });
    out.revogados.push(id);
  }
  return out;
}
module.exports = { executar };
if (require.main === module) {
  const admin = require('firebase-admin');
  admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
  const arg = (n) => ((process.argv.find((a) => a.startsWith('--' + n + '=')) || '').split('=')[1] || '').split(',').filter(Boolean);
  executar({ db: admin.firestore(), aprovar: arg('aprovar'), revogar: arg('revogar'), exec: process.argv.includes('--executar') })
    .then((r) => { console.log(r.simulacao ? 'SIMULAÇÃO (nada gravado; use --executar)' : 'EXECUTADO'); console.table(r.candidatos); console.log({ aprovados: r.aprovados, revogados: r.revogados, naoEncontrados: r.naoEncontrados }); })
    .catch((e) => { console.error(e.message); process.exit(1); });
}
