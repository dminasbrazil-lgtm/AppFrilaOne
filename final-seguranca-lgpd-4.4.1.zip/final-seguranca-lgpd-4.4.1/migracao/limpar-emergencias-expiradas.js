// Lista (e, só com --apagar, remove) registros de "emergencias" JÁ VENCIDOS. POR PADRÃO NÃO APAGA NADA.
//   node limpar-emergencias-expiradas.js                  → simulação: lista vencidos, recentes e sem data
//   node limpar-emergencias-expiradas.js --apagar         → apaga SOMENTE os vencidos
//   node limpar-emergencias-expiradas.js --uid=UID        → restringe a uma pessoa (útil para conferir)
// Critério: campo numérico "expiraEm" (milissegundos, gravado pelo app = data do registro + 90 dias) MENOR que agora.
// Documentos sem "expiraEm" válido NUNCA são apagados por este script: só aparecem no relatório (decidir à parte).
// Rode apenas depois de decidir o prazo de retenção (ver docs/DECISOES-LGPD.md). Precisa de credencial de administrador.
async function executar({ db, agora, apagar, uid }) {
  let q = db.collection('emergencias');
  if (uid) q = q.where('uid', '==', uid);
  const snap = await q.get();
  const r = { total: 0, vencidos: [], vigentes: 0, semData: [], apagados: 0 };
  snap.forEach((d) => {
    r.total++;
    const e = d.data().expiraEm;
    if (typeof e !== 'number' || !isFinite(e)) r.semData.push(d.id);
    else if (e < agora) r.vencidos.push(d.ref);
    else r.vigentes++;
  });
  if (apagar && r.vencidos.length) {
    let lote = db.batch(), n = 0;
    for (const ref of r.vencidos) { lote.delete(ref); if (++n % 400 === 0) { await lote.commit(); lote = db.batch(); } }
    await lote.commit();
    r.apagados = n;
  }
  return r;
}
module.exports = { executar };
if (require.main === module) {
  const admin = require('firebase-admin');
  admin.initializeApp();
  const apagar = process.argv.includes('--apagar');
  const uidArg = (process.argv.find((a) => a.startsWith('--uid=')) || '').slice(6) || null;
  executar({ db: admin.firestore(), agora: Date.now(), apagar, uid: uidArg }).then((r) => {
    console.log(apagar ? 'MODO APAGAR' : 'SIMULAÇÃO (nada será apagado; use --apagar)');
    console.log('Total:', r.total, '| vencidos:', r.vencidos.length, '| ainda dentro do prazo:', r.vigentes, '| sem data válida (não tocados):', r.semData.length);
    if (r.semData.length) console.log('Sem data válida:', r.semData.slice(0, 50).join(', '));
    if (apagar) console.log('Apagados:', r.apagados);
  }).catch((e) => { console.error(e.message); process.exit(1); });
}
