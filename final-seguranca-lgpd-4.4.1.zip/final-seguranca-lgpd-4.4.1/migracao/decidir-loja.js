// FrilaOne — decisão administrativa de "Minha Loja" pela linha de comando (enquanto o painel administrativo não existe).
// Usa a MESMA lógica da função decidirLoja (functions/loja-lib.js) e o Admin SDK: o cliente/usuário comum não passa por aqui.
//   node decidir-loja.js --listar                                   → lojas por situação (somente leitura)
//   node decidir-loja.js --negId=neg_UID --aprovar                  → SIMULAÇÃO do que seria gravado
//   node decidir-loja.js --negId=neg_UID --aprovar --executar       → grava a aprovação (publicaAte = campanha ou pago até)
//   node decidir-loja.js --negId=neg_UID --pendencia --motivo="faltam fotos dos produtos" --executar   (avise o dono pelo chat do app)
//   node decidir-loja.js --negId=neg_UID --recusar --motivo="..." --executar
//   node decidir-loja.js --aprovar-legado --negId=neg_A,neg_B [--executar]  → só as lojas ANTIGAS (sem aprovacaoStatus) que você listar passam a 'aprovada'.
//        NÃO existe aprovação em massa: confira cada loja antes. Gratuidade permanente é outro controle (marcar-loja-gratuita.js).
// Aprovar NÃO substitui a cobrança: depois de 30/11/2026 a loja só continua publicada com pagamento registrado (autorizar-loja.js).
const L = require('../functions/loja-lib.js');
const ADMIN = 'script:decidir-loja.js';
async function listar(db) {
  const snap = await db.collection('negocios').get(); const out = [];
  snap.forEach((d) => { const x = d.data() || {}; out.push({ negId: d.id, nome: x.nome || '', situacao: x.aprovacaoStatus || '(antiga, sem status)', publicaAte: x.publicaAte ? new Date(x.publicaAte).toISOString() : '', motivo: x.aprovacaoMotivo || '' }); });
  return out;
}
async function executar({ db, negId, negIds = [], decisao, motivo = '', legado = false, exec = false, agora = Date.now() }) {
  if (legado) {
    if (!negIds.length) return { ok: false, erro: 'informe_os_negIds' };
    const lojas = await listar(db); const r = { simulacao: !exec, aprovadas: [], erros: [], ignoradas: negIds.filter((i) => !lojas.some((l) => l.negId === i && l.situacao === '(antiga, sem status)')) };
    for (const l of lojas.filter((x) => x.situacao === '(antiga, sem status)' && negIds.includes(x.negId))) {
      const x = await L.decidir({ db, negId: l.negId, decisao: 'aprovar', adminUid: ADMIN, agora, simulacao: !exec });
      (x.ok ? r.aprovadas : r.erros).push(l.negId);
    }
    return r;
  }
  return L.decidir({ db, negId, decisao, motivo, adminUid: ADMIN, agora, simulacao: !exec });
}
module.exports = { executar, listar };
if (require.main === module) {
  const admin = require('firebase-admin');
  admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
  const arg = (n) => ((process.argv.find((a) => a.startsWith('--' + n + '=')) || '').split('=').slice(1).join('=') || '');
  const tem = (n) => process.argv.includes('--' + n);
  const db = admin.firestore();
  const dec = tem('aprovar') ? 'aprovar' : tem('recusar') ? 'recusar' : tem('pendencia') ? 'pendencia' : '';
  (async () => {
    if (tem('listar')) { console.table(await listar(db)); return; }
    if (tem('aprovar-legado')) { const r = await executar({ db, legado: true, negIds: arg('negId').split(',').filter(Boolean), exec: tem('executar') }); if (r.erro) { console.error('ERRO: ' + r.erro + ' (use --negId=neg_A,neg_B)'); process.exit(1); } console.log(r.simulacao ? 'SIMULAÇÃO (nada gravado; use --executar)' : 'EXECUTADO', r); return; }
    if (!dec) { console.error('Informe --listar, --aprovar-legado ou --negId=... com --aprovar/--recusar/--pendencia'); process.exit(1); }
    const r = await executar({ db, negId: arg('negId'), decisao: dec, motivo: arg('motivo'), exec: tem('executar') });
    if (!r.ok) { console.error('ERRO: ' + r.erro); process.exit(1); }
    console.log(r.simulacao ? 'SIMULAÇÃO (nada gravado; use --executar)' : 'EXECUTADO', r);
  })().catch((e) => { console.error(e.message); process.exit(1); });
}
