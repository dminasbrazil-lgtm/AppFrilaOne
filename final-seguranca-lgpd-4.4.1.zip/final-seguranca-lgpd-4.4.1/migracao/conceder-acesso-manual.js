// FrilaOne — concede acesso a quem JÁ PAGOU pelos links antigos do Mercado Pago (que não avisam o servidor).
// Você monta um arquivo JSON com os pagantes (conferindo no painel do Mercado Pago) e roda:
//   node conceder-acesso-manual.js pagantes.json                                   → SIMULAÇÃO (não grava; consulta o Mercado Pago se MP_ACCESS_TOKEN estiver definido)
//   MP_ACCESS_TOKEN=... node conceder-acesso-manual.js pagantes.json --executar    → concede SÓ quem o Mercado Pago confirma
//   node conceder-acesso-manual.js pagantes.json --executar --sem-verificar-mp      → concede sem consultar o MP (exceção, fica registrado)
// Formato:  [ { "uid": "UID_DO_FIREBASE", "plano": "golden|master|diamond", "ate": "2026-12-31", "idPagamentoMP": "NÚMERO DO PAGAMENTO NO PAINEL DO MERCADO PAGO", "valorPago": 29.9 (opcional), "motivo": "link antigo, pago em 10/10" } ]
// REGRAS: (1) exige o número do pagamento; (2) com verificação ligada, o pagamento precisa existir no Mercado Pago com status "approved"
// (e, se você informar "valorPago", com esse valor); (3) o mesmo pagamento não vale para duas contas; (4) repetir o comando não duplica nada.
// O servidor reconhece esse acesso (campos manualAte/manualPlano em assinaturas/{uid}); o usuário não consegue alterá-lo.
const L = require('../functions/assinatura-lib.js');
async function processar({ db, lista, exec, buscarPagamento, agora = Date.now(), verificar = true }) {
  const r = { concedidos: [], jaConcedidos: [], invalidos: [], recusadosMP: [], conflitos: [], simulacao: !exec, verificouMP: !!(verificar && buscarPagamento) };
  for (const p of lista) {
    const ate = Date.parse(p.ate + (String(p.ate).length <= 10 ? 'T23:59:59-03:00' : ''));
    const ref = String(p.idPagamentoMP || '').trim();
    if (!p.uid || !ref || !['golden', 'master', 'diamond'].includes(p.plano) || isNaN(ate) || ate < agora) { r.invalidos.push(p); continue; }
    // o mesmo pagamento não pode valer para duas contas
    const usados = await db.collection('assinaturas').where('manualRefPagamento', '==', ref.slice(0, 80)).get();
    let outra = false, mesma = false; usados.forEach((d) => { if (d.id === p.uid) mesma = true; else outra = true; });
    if (outra) { r.conflitos.push({ uid: p.uid, idPagamentoMP: ref, motivo: 'pagamento já usado por outra conta' }); continue; }
    if (mesma) { r.jaConcedidos.push(p.uid); continue; }
    let valorMP = null;
    if (verificar && (buscarPagamento || exec)) {
      if (!buscarPagamento && exec) { r.invalidos.push(Object.assign({ motivo: 'sem MP_ACCESS_TOKEN para verificar' }, p)); continue; }
      let pg = null; try { pg = await buscarPagamento(ref); } catch (e) { pg = null; }
      if (!pg || pg.status !== 'approved') { r.recusadosMP.push({ uid: p.uid, idPagamentoMP: ref, motivo: pg ? 'status ' + pg.status : 'não encontrado no Mercado Pago' }); continue; }
      // Pagamentos feitos pelos links ANTIGOS foram cobrados com os valores antigos; por isso o valor só é cobrado de volta se você informar "valorPago".
      if (p.valorPago !== undefined && Math.abs(Number(pg.transaction_amount) - Number(p.valorPago)) > 0.01) { r.recusadosMP.push({ uid: p.uid, idPagamentoMP: ref, motivo: 'valor no Mercado Pago R$ ' + pg.transaction_amount + ' difere do informado R$ ' + p.valorPago }); continue; }
      valorMP = Number(pg.transaction_amount);
    }
    if (exec) {
      const alvo = db.collection('assinaturas').doc(p.uid); const a = (await alvo.get()).data() || {};
      const novo = { manualAte: ate, manualPlano: p.plano, manualMotivo: String(p.motivo || '').slice(0, 200), manualRefPagamento: ref.slice(0, 80), manualEm: agora, manualVerificadoMP: !!(verificar && buscarPagamento), manualValorMP: valorMP };
      await alvo.set(novo, { merge: true });
      await alvo.set(L.camposDerivados(Object.assign({}, a, novo), agora), { merge: true });
    }
    r.concedidos.push(p.uid);
  }
  return r;
}
module.exports = { processar };
if (require.main === module) {
  const fs = require('fs'); const admin = require('firebase-admin');
  const arq = process.argv[2]; const exec = process.argv.includes('--executar'); const semMP = process.argv.includes('--sem-verificar-mp');
  if (!arq || arq.startsWith('--')) { console.error('Informe o arquivo JSON com os pagantes.'); process.exit(1); }
  const token = process.env.MP_ACCESS_TOKEN;
  if (exec && !semMP && !token) { console.error('Para conceder, defina MP_ACCESS_TOKEN (verificação no Mercado Pago) ou use --sem-verificar-mp (exceção).'); process.exit(1); }
  const buscarPagamento = token ? async (id) => { const r = await fetch('https://api.mercadopago.com/v1/payments/' + encodeURIComponent(id), { headers: { Authorization: 'Bearer ' + token } }); if (!r.ok) return null; return r.json(); } : null;
  admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
  processar({ db: admin.firestore(), lista: JSON.parse(fs.readFileSync(arq, 'utf8')), exec, buscarPagamento, verificar: !semMP })
    .then((r) => console.log(JSON.stringify(r, null, 2))).catch((e) => { console.error(e.message); process.exit(1); });
}
