// SOMENTE LEITURA. Lista contas criadas a partir de uma data que NÃO têm registro em aceites_termos.
//   node auditar-aceites.js 2026-10-15      (data de corte = quando o registro de aceite entrou no ar)
// Serve para acompanhar se o aceite está sendo gravado e para decidir, com dados, se vale exigir o aceite no servidor.
const admin = require('firebase-admin');
admin.initializeApp();
(async () => {
  const corte = Date.parse(process.argv[2] || '');
  if (!isFinite(corte)) { console.error('Informe a data de corte, ex.: node auditar-aceites.js 2026-10-15'); process.exit(1); }
  const db = admin.firestore(); let token, total = 0, sem = 0; const exemplos = [];
  do {
    const lote = await admin.auth().listUsers(1000, token); token = lote.pageToken;
    for (const u of lote.users) {
      if (Date.parse(u.metadata.creationTime) < corte) continue;
      total++;
      if (!(await db.collection('aceites_termos').doc(u.uid).get()).exists) { sem++; if (exemplos.length < 50) exemplos.push(u.uid); }
    }
  } while (token);
  console.log('Contas criadas desde', process.argv[2], ':', total, '| sem registro de aceite:', sem);
  if (exemplos.length) console.log('UIDs (até 50):', exemplos.join(', '));
})().catch((e) => { console.error(e.message); process.exit(1); });
