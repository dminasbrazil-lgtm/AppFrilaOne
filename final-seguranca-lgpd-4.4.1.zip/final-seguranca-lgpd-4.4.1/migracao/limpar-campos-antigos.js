// FrilaOne — REMOVE os campos antigos (cpf, contatoEmergencia, email, emailContato, ultima_emergencia_*) dos documentos PÚBLICOS.
// SÓ rode depois de: (1) regras v18 publicadas, (2) app novo no ar e testado, (3) migrar-dados-privados.js --verificar sem divergências.
// Este script RE-CONFERE cada documento e só apaga o campo antigo se o privado tiver o mesmo valor.
//   node limpar-campos-antigos.js                                   → SIMULAÇÃO (padrão)
//   node limpar-campos-antigos.js --executar --confirmo-que-verifiquei
// Reversão: o valor continua nos documentos privados; para devolver ao documento antigo, basta copiar de volta (não recomendado: volta a expor).
const admin = require('firebase-admin');
const exec = process.argv.includes('--executar') && process.argv.includes('--confirmo-que-verifiquei');
admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
const db = admin.firestore(); const FV = admin.firestore.FieldValue;
async function varrer(colecao, aoDoc) {
  let ultimo = null;
  for (;;) {
    let q = db.collection(colecao).orderBy(admin.firestore.FieldPath.documentId()).limit(300); if (ultimo) q = q.startAfter(ultimo);
    const snap = await q.get(); if (snap.empty) break; for (const d of snap.docs) await aoDoc(d); ultimo = snap.docs[snap.docs.length - 1];
  }
}
(async () => {
  const r = { usuariosLimpos: 0, lojasLimpas: 0, pulados: [] };
  await varrer('usuarios', async (d) => {
    const u = d.data(); const del = {};
    const priv = (await db.collection('usuarios_privado').doc(d.id).get()).data() || {};
    if (u.cpf !== undefined) { if (priv.cpf === u.cpf) del.cpf = FV.delete(); else r.pulados.push('usuarios/' + d.id + ' cpf'); }
    if (u.contatoEmergencia !== undefined) { if (priv.contatoEmergencia === u.contatoEmergencia) del.contatoEmergencia = FV.delete(); else r.pulados.push('usuarios/' + d.id + ' contatoEmergencia'); }
    if (u.email !== undefined) { if (priv.email === u.email) del.email = FV.delete(); else r.pulados.push('usuarios/' + d.id + ' email'); }
    if (u.emailContato !== undefined) { if (priv.emailContato === u.emailContato) del.emailContato = FV.delete(); else r.pulados.push('usuarios/' + d.id + ' emailContato'); }
    ['ultima_emergencia_tipo', 'ultima_emergencia_ts', 'ultima_emergencia_coords'].forEach((k) => { if (u[k] !== undefined) del[k] = FV.delete(); }); // sem leitor no app; o registro oficial está em emergencias
    if (!Object.keys(del).length) return;
    if (exec) await d.ref.update(del); r.usuariosLimpos++;
  });
  await varrer('negocios', async (d) => {
    const n = d.data(); if (n.cpf === undefined) return;
    const priv = (await db.collection('negocios_privado').doc(d.id).get()).data() || {};
    if (priv.cpf !== n.cpf) { r.pulados.push('negocios/' + d.id); return; }
    if (exec) await d.ref.update({ cpf: FV.delete() }); r.lojasLimpas++;
  });
  console.log(exec ? 'EXECUTADO' : 'SIMULAÇÃO (nada apagado)'); console.log(JSON.stringify(r, null, 2));
})().catch((e) => { console.error(e.message); process.exit(1); });
