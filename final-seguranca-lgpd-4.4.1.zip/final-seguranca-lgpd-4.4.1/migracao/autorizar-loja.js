// FrilaOne — registra (ou revoga) o PAGAMENTO/direito comercial de "Minha Loja" de uma conta: lojas_autorizadas/{uid}.ate.
// Minha Loja é um fluxo INDEPENDENTE dos planos Golden/Master/Diamond. O cliente não consegue escrever essa coleção (regras v18.3);
// só este script / o painel do dono (Admin SDK). Ainda NÃO existe cobrança automática da Minha Loja: o registro é manual.
//   node autorizar-loja.js --uid=UID --ate=2027-01-31              → SIMULAÇÃO (nada gravado)
//   node autorizar-loja.js --uid=UID --ate=2027-01-31 --executar   → grava (merge; repetir não duplica)
//   node autorizar-loja.js --uid=UID --revogar --executar          → encerra a autorização (ate = agora)
// v4.3: isto é o PAGAMENTO/direito comercial da Minha Loja — NÃO é a aprovação (essa é decidir-loja.js). Se a loja já estiver aprovada,
// publicaAte é recalculado (aprovada + pago até esta data). Depois da campanha (30/11/2026) a loja aprovada só fica publicada com pagamento.
const L = require('../functions/loja-lib.js');
async function executar({ db, uid, ate, revogar = false, exec = false, agora = Date.now() }) {
  const out = { simulacao: !exec, uid, acao: revogar ? 'revogar' : 'autorizar', gravado: null, erro: null };
  if (!uid || /[\/\s]/.test(uid)) { out.erro = 'uid inválido'; return out; }
  const u = await db.collection('usuarios').doc(uid).get();
  if (!u.exists) { out.erro = 'usuário não encontrado'; return out; }
  let fim;
  if (revogar) fim = agora;
  else {
    fim = /^\d{4}-\d{2}-\d{2}$/.test(String(ate || '')) ? Date.parse(ate + 'T23:59:59-03:00') : NaN;
    if (!(fim > agora)) { out.erro = '--ate=AAAA-MM-DD é obrigatório e precisa estar no futuro'; return out; }
  }
  out.gravado = { ate: fim, origem: 'autorizar-loja.js', atualizadoEm: agora };
  if (exec) await db.collection('lojas_autorizadas').doc(uid).set(out.gravado, { merge: true });
  const neg = await db.collection('negocios').doc('neg_' + uid).get();
  if (neg.exists && (neg.data() || {}).aprovacaoStatus === 'aprovada') out.loja = await L.decidir({ db, negId: 'neg_' + uid, decisao: 'recalcular', adminUid: 'script:autorizar-loja.js', agora, simulacao: !exec });
  return out;
}
module.exports = { executar };
if (require.main === module) {
  const admin = require('firebase-admin');
  admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
  const arg = (n) => ((process.argv.find((a) => a.startsWith('--' + n + '=')) || '').split('=')[1] || '');
  executar({ db: admin.firestore(), uid: arg('uid'), ate: arg('ate'), revogar: process.argv.includes('--revogar'), exec: process.argv.includes('--executar') })
    .then((r) => { if (r.erro) { console.error('ERRO: ' + r.erro); process.exit(1); } console.log(r.simulacao ? 'SIMULAÇÃO (nada gravado; use --executar)' : 'EXECUTADO', r); })
    .catch((e) => { console.error(e.message); process.exit(1); });
}
