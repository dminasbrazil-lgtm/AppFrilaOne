// FrilaOne — migração do CPF / contato de emergência / e-mails (login e de contato) para os documentos PRIVADOS.
// NÃO é executada automaticamente. Rode você, no seu computador, depois de revisar.
//   Pré-requisitos: Node 20, `npm i firebase-admin`, e credenciais da SUA conta (gcloud auth application-default login).
//   Nenhuma chave é colada em arquivo.
//
//   node migrar-dados-privados.js              → SIMULAÇÃO (só conta e mostra; não grava nada)  [padrão]
//   node migrar-dados-privados.js --executar   → COPIA para usuarios_privado / negocios_privado (nunca apaga, nunca sobrescreve dado privado existente)
//   node migrar-dados-privados.js --verificar  → confere se tudo que existe no documento antigo está igual no privado
const admin = require('firebase-admin');
const modo = process.argv.includes('--executar') ? 'executar' : process.argv.includes('--verificar') ? 'verificar' : 'simular';
admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
const db = admin.firestore();

async function varrer(colecao, aoDoc) {
  let ultimo = null, total = 0;
  for (;;) {
    let q = db.collection(colecao).orderBy(admin.firestore.FieldPath.documentId()).limit(300);
    if (ultimo) q = q.startAfter(ultimo);
    const snap = await q.get();
    if (snap.empty) break;
    for (const d of snap.docs) { total++; await aoDoc(d); }
    ultimo = snap.docs[snap.docs.length - 1];
  }
  return total;
}
(async () => {
  const r = { usuariosVarridos: 0, usuariosComDados: 0, copiadosUsuarios: 0, lojasVarridas: 0, lojasComCpf: 0, copiadasLojas: 0, divergencias: [] };
  r.usuariosVarridos = await varrer('usuarios', async (d) => {
    const u = d.data(); const dados = {};
    if (u.cpf) dados.cpf = u.cpf;
    if (u.contatoEmergencia) dados.contatoEmergencia = u.contatoEmergencia;
    if (u.email) dados.email = u.email;                 // v18: e-mail de login que o app antigo gravava no perfil público
    if (u.emailContato) dados.emailContato = u.emailContato;
    if (!Object.keys(dados).length) return;
    r.usuariosComDados++;
    const ref = db.collection('usuarios_privado').doc(d.id); const atual = (await ref.get()).data() || {};
    if (modo === 'verificar') { for (const k in dados) if (atual[k] !== dados[k]) r.divergencias.push('usuarios/' + d.id + ' campo ' + k); return; }
    const faltam = {}; for (const k in dados) if (atual[k] === undefined) faltam[k] = dados[k];   // nunca sobrescreve
    if (!Object.keys(faltam).length) return;
    if (modo === 'executar') { faltam.atualizadoEm = Date.now(); await ref.set(faltam, { merge: true }); }
    r.copiadosUsuarios++;
  });
  r.lojasVarridas = await varrer('negocios', async (d) => {
    const n = d.data(); if (!n.cpf) return;
    r.lojasComCpf++;
    if (!n.uid) { r.divergencias.push('negocios/' + d.id + ' sem uid (não migrada)'); return; }
    const ref = db.collection('negocios_privado').doc(d.id); const atual = (await ref.get()).data() || {};
    if (modo === 'verificar') { if (atual.cpf !== n.cpf) r.divergencias.push('negocios/' + d.id + ' cpf'); return; }
    if (atual.cpf !== undefined) return;
    if (modo === 'executar') await ref.set({ uid: n.uid, cpf: n.cpf, atualizadoEm: Date.now() }, { merge: true });
    r.copiadasLojas++;
  });
  console.log('MODO:', modo.toUpperCase()); console.log(JSON.stringify(r, null, 2));
  if (modo === 'simular') console.log('\nNada foi gravado. Para copiar de verdade: --executar');
  process.exit(r.divergencias.length ? 2 : 0);
})().catch((e) => { console.error(e.message); process.exit(1); });
