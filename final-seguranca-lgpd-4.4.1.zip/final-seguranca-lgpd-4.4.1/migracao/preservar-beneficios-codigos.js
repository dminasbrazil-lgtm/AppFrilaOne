// FrilaOne — PRESERVA direitos já concedidos pelo antigo sistema de códigos (GP/MN/CV), agora retirado.
// Só lê o que está GRAVADO no Firestore (usuarios.trial_cod / trial_fim). Não apaga nada, não cria código novo.
//   node preservar-beneficios-codigos.js             → SIMULAÇÃO: lista quem tem benefício por código ainda válido (nada é gravado)
//   node preservar-beneficios-codigos.js --todos     → idem, inclusive os que terminam antes de 30/11/2026 (a campanha já cobre esses)
//   node preservar-beneficios-codigos.js --executar  → grava assinaturas/{uid}.codigoFim = fim do benefício (nunca diminui o que já existe)
// Atenção: códigos GP/CV resgatados só no aparelho (sem gravação no Firestore) NÃO aparecem aqui e não podem ser comprovados pelo servidor.
// Se alguém reclamar, confira e use conceder-acesso-manual.js (exige o número do pagamento/registro).
const admin = require('firebase-admin');
const L = require('../functions/assinatura-lib.js');
const exec = process.argv.includes('--executar'); const todos = process.argv.includes('--todos');
admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
const db = admin.firestore();
(async () => {
  const agora = Date.now(); const lista = [];
  const snap = await db.collection('usuarios').get();   // somente leitura
  snap.forEach((d) => {
    const u = d.data() || {}; const cod = String(u.trial_cod || '');
    if (!cod || cod === 'AUTO') return;
    const fim = Number(u.trial_fim) || 0;
    if (fim <= agora) return;
    if (!todos && fim <= L.CAMPANHA_ATE) return;
    lista.push({ uid: d.id, cod, fim, fimData: new Date(fim).toISOString() });
  });
  console.log(exec ? 'GRAVANDO' : 'SIMULAÇÃO (nada gravado)', '— benefícios por código ainda válidos:', lista.length);
  lista.forEach((x) => console.log(' ', x.uid, x.cod, x.fimData));
  if (!exec) return;
  for (const x of lista) {
    const ref = db.collection('assinaturas').doc(x.uid); const a = (await ref.get()).data() || {};
    const novo = { codigoFim: Math.max(a.codigoFim || 0, x.fim), codigoOrigem: x.cod.slice(0, 40), codigoPreservadoEm: agora };
    await ref.set(novo, { merge: true });
    await ref.set(L.camposDerivados(Object.assign({}, a, novo), agora), { merge: true });
  }
  console.log('Concluído.');
})().catch((e) => { console.error(e.message); process.exit(1); });
