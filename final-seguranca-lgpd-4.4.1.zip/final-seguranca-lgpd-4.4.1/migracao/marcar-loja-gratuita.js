// FrilaOne — gratuidade PERMANENTE de lojas específicas (as lojas anteriores à cobrança da Minha Loja).
// Grava lojas_gratuitas/{uid}. O usuário NÃO consegue escrever essa coleção (regras v18.4); só este script (Admin SDK), com os negId que
// VOCÊ confirmar. Não identifica por nome nem por data (dados que o usuário controla) e não existe lista embutida no código.
// A gratuidade NÃO aprova a loja: ela só fica publicada se também estiver APROVADA (decidir-loja.js). Aprovação e cobrança continuam separadas.
//   node marcar-loja-gratuita.js --negId=neg_UID1,neg_UID2                       → SIMULAÇÃO: mostra nome/situação de cada loja, não grava
//   node marcar-loja-gratuita.js --negId=neg_UID1,neg_UID2 --executar --confirmo-que-sao-estas-lojas
//   node marcar-loja-gratuita.js --negId=neg_UID1 --revogar --executar --confirmo-que-sao-estas-lojas   (volta à regra normal: aprovação + cobrança)
// Trava de segurança: no máximo 2 lojas gratuitas no total (use --permitir-mais só se o dono do app mudar a decisão comercial).
// Não altera os dados da loja; se ela já estiver aprovada, só recalcula publicaAte.
const L = require('../functions/loja-lib.js');
const MOTIVO = 'Loja cadastrada antes da cobrança da Minha Loja — gratuidade permanente definida pelo dono do app';
async function executar({ db, negIds = [], revogar = false, exec = false, confirmo = false, permitirMais = false, maximo = 2, motivo = MOTIVO, agora = Date.now() }) {
  const out = { simulacao: !exec, acao: revogar ? 'revogar' : 'conceder', lojas: [], erro: null };
  negIds = [...new Set(negIds.filter(Boolean))];
  if (!negIds.length) { out.erro = 'informe_os_negIds'; return out; }
  if (exec && !confirmo) { out.erro = 'falta_confirmacao'; return out; }
  for (const negId of negIds) {
    if (!L.idValido(negId)) { out.erro = 'id_invalido:' + negId; return out; }
    const snap = await db.collection('negocios').doc(negId).get();
    if (!snap.exists) { out.erro = 'loja_inexistente:' + negId; return out; }
    const n = snap.data() || {}; const uid = negId.slice(4);
    if (n.uid !== uid) { out.erro = 'loja_inconsistente:' + negId; return out; }
    out.lojas.push({ negId, uid, nome: n.nome || '', local: n.local || '', situacao: n.aprovacaoStatus || '(antiga, sem status)', jaGratuita: await L.lojaGratuita(db, negId) });
  }
  if (!revogar) {
    const todas = await db.collection('lojas_gratuitas').get(); const ativas = new Set();
    todas.forEach((d) => { const x = d.data() || {}; if (x.permanente === true && !x.revogadaEm && x.negId) ativas.add(x.negId); });
    negIds.forEach((i) => ativas.add(i));
    if (ativas.size > maximo && !permitirMais) { out.erro = 'limite_excedido:' + ativas.size + '>' + maximo; return out; }
  }
  if (!exec) return out;
  for (const l of out.lojas) {
    const ref = db.collection('lojas_gratuitas').doc(l.uid);
    if (revogar) await ref.set({ negId: l.negId, permanente: false, revogadaEm: agora, revogadaPor: 'script:marcar-loja-gratuita.js' }, { merge: true });
    else { await ref.set({ negId: l.negId, nome: l.nome, permanente: true, concedidaEm: agora, concedidaPor: 'script:marcar-loja-gratuita.js', motivo, revogadaEm: null }, { merge: true }); }
    if (l.situacao === 'aprovada') l.recalculo = await L.decidir({ db, negId: l.negId, decisao: 'recalcular', adminUid: 'script:marcar-loja-gratuita.js', agora });
  }
  return out;
}
module.exports = { executar, MOTIVO };
if (require.main === module) {
  const admin = require('firebase-admin');
  admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
  const arg = (n) => ((process.argv.find((a) => a.startsWith('--' + n + '=')) || '').split('=').slice(1).join('=') || '');
  const tem = (n) => process.argv.includes('--' + n);
  executar({ db: admin.firestore(), negIds: arg('negId').split(',').filter(Boolean), revogar: tem('revogar'), exec: tem('executar'), confirmo: tem('confirmo-que-sao-estas-lojas'), permitirMais: tem('permitir-mais') })
    .then((r) => { if (r.erro) { console.error('ERRO: ' + r.erro); process.exit(1); } console.log(r.simulacao ? 'SIMULAÇÃO (nada gravado; confira os nomes e use --executar --confirmo-que-sao-estas-lojas)' : 'EXECUTADO'); console.table(r.lojas); })
    .catch((e) => { console.error(e.message); process.exit(1); });
}
