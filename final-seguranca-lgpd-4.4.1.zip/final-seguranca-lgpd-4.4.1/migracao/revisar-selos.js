// FrilaOne — revisa o selo "verificado" (usuarios.verificado) e o modo Master gravados ANTES das regras v18, quando o próprio aparelho podia se dar o selo.
//   node revisar-selos.js                                            → SIMULAÇÃO (padrão): só lista quem tem selo sem documento de verificação válido
//   node revisar-selos.js --executar --confirmo-que-revisei          → tira o selo (verificado=false) de quem NÃO tem verificação válida. Antes grava um backup JSON.
// O que conta como "verificação válida": verificacoes/{uid} com CPF de dígitos válidos e selfie enviada (a mesma checagem da função confirmarVerificacao).
// Quem tiver verificação válida NÃO é alterado. Nada é apagado; para desfazer, use o arquivo de backup (verificado volta a true).
// Observação: o modo Master (master_ativo) NÃO é tratado aqui: o servidor o desliga sozinho no próximo login de quem não tem direito (statusAcesso).
const fs = require('fs');
const { cpfValido } = require('../functions/assinatura-lib.js');
async function executar({ db, exec, confirmo, escreverBackup = (nome, texto) => fs.writeFileSync(nome, texto), agora = Date.now() }) {
  const r = { comSelo: 0, comVerificacaoValida: 0, semVerificacaoValida: [], alterados: 0, backup: null };
  const snap = await db.collection('usuarios').get();
  for (const d of snap.docs) {
    if (d.data().verificado !== true) continue; r.comSelo++;
    const v = (await db.collection('verificacoes').doc(d.id).get()); const vd = v.exists ? v.data() : null;
    if (vd && cpfValido(vd.cpf) && typeof vd.selfie === 'string' && vd.selfie.length >= 200) r.comVerificacaoValida++; else r.semVerificacaoValida.push(d.id);
  }
  if (!exec) return Object.assign(r, { modo: 'simulacao' });
  if (!confirmo) throw new Error('Para executar, confirme com --confirmo-que-revisei (rode antes a simulação e confira a lista).');
  if (r.semVerificacaoValida.length) {
    const nome = 'backup-selos-' + agora + '.json'; r.backup = nome;
    escreverBackup(nome, JSON.stringify({ geradoEm: agora, uidsComSeloRemovido: r.semVerificacaoValida }, null, 2));   // gravado ANTES de alterar
    for (const uid of r.semVerificacaoValida) { await db.collection('usuarios').doc(uid).set({ verificado: false }, { merge: true }); r.alterados++; }
  }
  return Object.assign(r, { modo: 'executado' });
}
module.exports = { executar };
if (require.main === module) {
  const admin = require('firebase-admin'); admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
  executar({ db: admin.firestore(), exec: process.argv.includes('--executar'), confirmo: process.argv.includes('--confirmo-que-revisei') })
    .then((r) => console.log(JSON.stringify(r, null, 2))).catch((e) => { console.error(e.message); process.exit(1); });
}
