// FrilaOne — chave config/seguranca.exigirAcesso (SÓ ela; a proteção de campos não tem mais chave: está sempre ligada nas regras v18).
// Para que serve: ANTECIPAR a exigência de acesso pago para ANTES de 01/12/2026 (por exemplo, para testar com uma conta de teste).
// Não é necessária para a proteção valer: a partir de 01/12/2026 (Brasília) as regras v18 exigem o acesso gravado pelo servidor sozinhas.
// SÓ rode depois de: funções publicadas, regras v18 publicadas, app publicado com _ASSINATURA_ATIVA=true e verificar-prontidao.js sem bloqueios.
//   node ligar-chaves-seguranca.js                                   → mostra o estado atual
//   node ligar-chaves-seguranca.js --executar --confirmo-modo-servidor   → liga exigirAcesso (antecipa a cobrança)
//   node ligar-chaves-seguranca.js --desligar --executar                 → desliga (volta a valer só a data 01/12/2026)
async function executar({ db, ligar, desligar, exec, confirmo, agora = Date.now() }) {
  const ref = db.collection('config').doc('seguranca'); const atual = (await ref.get()).data() || null;
  if (!exec || (!ligar && !desligar)) return { acao: 'mostrar', atual };
  if (ligar && !confirmo) throw new Error('Para ligar, confirme com --confirmo-modo-servidor (funções, regras v18 e app em Modo Servidor já publicados).');
  const novo = { exigirAcesso: !!ligar, alteradoEm: agora };
  await ref.set(novo, { merge: true });
  return { acao: ligar ? 'ligado' : 'desligado', atual, novo };
}
module.exports = { executar };
if (require.main === module) {
  const admin = require('firebase-admin'); admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
  executar({ db: admin.firestore(), ligar: process.argv.includes('--executar') && !process.argv.includes('--desligar'), desligar: process.argv.includes('--desligar'), exec: process.argv.includes('--executar'), confirmo: process.argv.includes('--confirmo-modo-servidor') })
    .then((r) => console.log(JSON.stringify(r, null, 2))).catch((e) => { console.error(e.message); process.exit(1); });
}
