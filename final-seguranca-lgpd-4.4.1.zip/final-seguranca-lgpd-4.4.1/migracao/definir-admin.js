// FrilaOne — marca UMA conta como administradora (custom claim "admin"). Nada é concedido automaticamente.
//   node definir-admin.js UID_DA_CONTA              → mostra a conta (simulação)
//   node definir-admin.js UID_DA_CONTA --executar   → define admin=true (a pessoa precisa sair e entrar de novo)
//   node definir-admin.js UID_DA_CONTA --remover --executar
const admin = require('firebase-admin');
const uid = process.argv[2]; const exec = process.argv.includes('--executar'); const remover = process.argv.includes('--remover');
if (!uid || uid.startsWith('--')) { console.error('Informe o UID da conta (Console → Authentication).'); process.exit(1); }
admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
(async () => {
  const u = await admin.auth().getUser(uid);
  console.log('Conta:', u.email, '| e-mail verificado:', u.emailVerified, '| claims atuais:', JSON.stringify(u.customClaims || {}));
  if (!exec) { console.log('SIMULAÇÃO: nada alterado.'); return; }
  await admin.auth().setCustomUserClaims(uid, Object.assign({}, u.customClaims || {}, { admin: !remover }));
  console.log(remover ? 'admin removido.' : 'admin definido. A pessoa precisa sair e entrar de novo.');
})().catch((e) => { console.error(e.message); process.exit(1); });
