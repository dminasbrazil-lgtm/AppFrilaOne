// FrilaOne — SOMENTE LEITURA. Diz o que precisa estar resolvido antes de publicar as regras v18 / ligar o Modo Servidor, sem quebrar ninguém.
//   node verificar-prontidao.js
// Não altera nada. Lista quantidades e o que precisa ser resolvido.
const INICIO_COBRANCA = Date.parse('2026-12-01T00:00:00-03:00');   // igual às regras v18 (1796094000000)
const PAGOS = ['prestador', 'academico', 'empresa', 'negocio'];
async function analisar(db, agora = Date.now()) {
  const r = { chaves: null, usuarios: 0, comCpfNoPerfilPublico: 0, comEmailNoPerfilPublico: 0, verificadosSemDocumentoDeVerificacao: 0, prestadoresSemRegistroDeAcesso: 0, contasDePlanoSemAcessoValidoAgora: 0,
    comTrialGravadoNoPerfil: 0, masterAtivoNoPerfil: 0, comPlanoPagoNoPerfil: 0, academicosNaoAprovados: 0, aceitesRegistrados: 0, pedidosExclusaoComErro: 0, cobrancaJaAtiva: agora >= INICIO_COBRANCA };
  const cfg = await db.collection('config').doc('seguranca').get();
  r.chaves = cfg.exists ? { exigirAcesso: cfg.data().exigirAcesso === true } : { exigirAcesso: false, aviso: 'config/seguranca não existe (normal: a exigência vale pela data 01/12/2026)' };
  const us = await db.collection('usuarios').get();
  for (const d of us.docs) {
    const u = d.data(); r.usuarios++;
    if (u.cpf || u.contatoEmergencia) r.comCpfNoPerfilPublico++;
    if (u.email || u.emailContato) r.comEmailNoPerfilPublico++;
    if (u.verificado === true && !(await db.collection('verificacoes').doc(d.id).get()).exists) r.verificadosSemDocumentoDeVerificacao++;
    if (u.trial_fim !== undefined || u.trial_inicio !== undefined) r.comTrialGravadoNoPerfil++;   // legado: ignorado no Modo Servidor
    if (u.master_ativo === true) r.masterAtivoNoPerfil++;
    if (u.plano && u.plano !== 'free') r.comPlanoPagoNoPerfil++;
    if (PAGOS.includes(u.tipo) || u.master_ativo === true) {
      const as = await db.collection('assinaturas').doc(d.id).get();
      if (!as.exists) { r.prestadoresSemRegistroDeAcesso++; r.contasDePlanoSemAcessoValidoAgora++; }
      else { const a = as.data(); const ate = a.acessoRegraAte !== undefined ? a.acessoRegraAte : (a.acessoValidoAte || 0) + 3 * 86400e3; if (!(ate > Math.max(agora, INICIO_COBRANCA))) r.contasDePlanoSemAcessoValidoAgora++; }
    }
    if (u.tipo === 'academico') { const a = await db.collection('profissionais_aprovados').doc(d.id).get(); if (!(a.exists && a.data().ativo === true)) r.academicosNaoAprovados++; }
  }
  r.aceitesRegistrados = (await db.collection('aceites_termos').get()).size;
  r.pedidosExclusaoComErro = (await db.collection('solicitacoes_exclusao').where('status', '==', 'erro').get()).size;
  r.bloqueios = [];
  if (r.comCpfNoPerfilPublico || r.comEmailNoPerfilPublico) r.bloqueios.push('Rodar migrar-dados-privados.js e depois limpar-campos-antigos.js: ainda há CPF/contato/e-mail no perfil público.');
  if (r.academicosNaoAprovados) r.bloqueios.push('Aprovar os profissionais com conceder-profissional.js (senão perdem acesso aos pedidos de agendamento).');
  if (r.contasDePlanoSemAcessoValidoAgora) r.bloqueios.push('Há contas de plano sem acesso válido para depois de 01/12/2026: o app em Modo Servidor cria o teste/acesso no próximo login (statusAcesso). Publique o Modo Servidor ANTES de 01/12/2026 e peça que entrem no app; quem não entrar fica sem publicar vaga/ficar disponível até entrar.');
  if (r.verificadosSemDocumentoDeVerificacao) r.bloqueios.push('Há selos "verificado" sem documento de verificação (o app antigo deixava o cliente se dar o selo). Veja revisar-selos.js (simulação por padrão).');
  if (r.pedidosExclusaoComErro) r.bloqueios.push('Há pedidos de exclusão com erro: a pessoa precisa pedir de novo ou o suporte deve tratar.');
  return r;
}
module.exports = { analisar, INICIO_COBRANCA };
if (require.main === module) {
  const admin = require('firebase-admin'); admin.initializeApp({ projectId: process.env.GCLOUD_PROJECT || 'frilaone-e6247' });
  analisar(admin.firestore()).then((r) => { console.log(JSON.stringify(r, null, 2)); }).catch((e) => { console.error(e.message); process.exit(1); });
}
