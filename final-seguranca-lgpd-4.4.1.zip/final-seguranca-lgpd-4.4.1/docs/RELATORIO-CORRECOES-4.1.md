# RELATÓRIO — CORREÇÕES 4.1 (`final-seguranca-lgpd-4.1`)

**Não está pronto para produção.** As regras v18.1 passaram em 388/388 no avaliador **simulado** (não é o Emulador oficial). **O Emulador oficial NÃO foi executado:** neste ambiente `npm view firebase-tools` não responde e o download do JAR do Emulador retorna HTTP 403. Nada foi publicado no Firebase, nenhum dado foi migrado, nenhuma cobrança foi ativada, nada foi enviado ao GitHub. `final-seguranca-lgpd-4.zip` foi preservado; o app (`teste-final.html`) e as funções **não foram alterados** nesta etapa.

## 1. Correções
### 1.1 Estagiário em `acessoDisponivel()` (contorno de acesso)
**Problema:** a v18 liberava "Tô disponível" a qualquer documento com `categoria:'estagiario'`. Quem tinha plano vencido (ou tipo/`master_ativo` de plano) só precisava escolher essa categoria — o teste da v18 chegava a registrar esse contorno como "permite".
**Como o app cadastra estagiário** (`cadastrarEstagiario` / `toggleEstOnline`): grava `estagiarios/{uid}` (nome, área, período, faculdade…; auto-gravável, como o currículo) e, ao ficar online, `disponiveis/{uid}` com `categoria:'estagiario'` + campos do perfil; o heartbeat (a cada 20 s, merge) acrescenta whatsapp/bairro/cidade/atendimento. O app já bloqueia conta de plano sem acesso (`_permitirAcaoPaga`).
**Regra nova (`disponivelEstagiario`)** — a isenção só vale se TODAS forem verdadeiras: categoria `estagiario`; `uid` do documento = próprio; só campos que o app grava; **a conta não é de plano** (`contaDePlano`: `precisaPlano` gravado pelo servidor, tipo de plano ou `master_ativo`); existe `estagiarios/{uid}` com área e faculdade.
**Limite honesto:** `estagiarios/{uid}` é editável pelo próprio usuário; esse requisito só garante coerência com o fluxo do app. A barreira real é "não ser conta de plano", cujo dado é do servidor. Uma conta que nunca foi de plano pode aparecer como estagiário de graça — é o que o app já oferece a quem não tem plano. Efeito colateral aceito: conta de plano sem acesso válido também não aparece como estagiário.

### 1.2 `acessoLoja()` exige direito de loja
Agora (após 01/12/2026): `acessoServidor(uid)` **e** `assinaturas/{uid}.acessoPlano` ∈ {`diamond`, `todos`}. `todos` = teste grátis, benefício legado ou concessão manual total (o servidor já grava esses valores). Golden e Master **não** criam loja (decisão seguindo o pedido: Diamond ou direito explícito). Campanha até 30/11/2026 continua livre; preços intactos. Efeitos: lojas já existentes não são afetadas (só a criação); contas antigas sem `acessoPlano` só criam loja depois de passar por `statusAcesso` → **publicar funções antes das regras**. Não implementei um direito "explícito" novo (ex.: flag própria) por exigir mudança de servidor/produto fora do escopo.

## 2. Arquivos alterados (em relação ao 4.zip)
| Arquivo | Alteração |
|---|---|
| `firestore-regras-v18.1.txt` (novo) | `disponivelEstagiario`, `acessoDisponivel`, `acessoLoja` (v18 mantida p/ reversão) |
| `testes/regras/testar-regras.js` | 388 testes (eram 359): +29 novos; apontado p/ v18.1; ver §3 |
| `testes/teste-acesso-regras.js` | loja agora esperada só onde `acessoPlano` ∈ diamond/todos (antes: igual a "tem acesso") |
| `testes/regras/executar-simulado.js`, `firebase.json`, `testes/teste-regressao-app.js`, `testes/rodar-todos.sh` | apontam para a v18.1 |
| `docs/ATIVACAO-SEGURA.md`, `docs/LEIA-ME-PRIMEIRO.md`, `testes/regras/EXECUTAR-NO-COMPUTADOR.md` | v18.1, 388 testes, avisos de ativação |
| `.backup-4/` | cópias da v18, do app e de `testar-regras.js` antes das edições |

## 3. Expectativas de testes que mudaram (com justificativa)
1. `[v18 acesso] LIMITAÇÃO CONHECIDA: T1 (golden) cria loja` — *permite → bloqueia*: era a limitação que esta etapa corrige.
2. `[v18 acesso] quem tem plano vencido tenta passar por "estagiario"` — *permite → bloqueia*: era o contorno (registrado antes como aceito).
3. `Pessoa Física (estagiário) fica disponível` — continua *permite*, mas o teste agora usa o **payload real do app** e semeia `estagiarios/T10` (o app sempre cadastra antes). Sem isso a nova exigência de cadastro o bloquearia por falta de seed, não por erro.
4. Seeds `assinaturas/P` e `assinaturas/LJ` ganharam `acessoPlano:'diamond'` (os testes "Prestador com acesso válido cria loja" e "usuário cria a própria loja" tratam de assinante de loja; a intenção — id `neg_`+uid, acesso válido — não mudou). Seeds sem `acessoPlano` seguem testados como *bloqueia* (L14, T6).
Nenhum teste foi removido ou enfraquecido.

## 4. Testes realmente executados
| Teste | Resultado |
|---|---|
| `bash testes/rodar-todos.sh` | **passou tudo**: teste-app, app-sem-privilegios, acesso, acesso-regras, regressao-app (Chromium, Firestore falso), servidor-simulado, botao-ja-assinei, assinatura-duplicidade, migracao, beneficios, exclusao, aceite, emergencias, scripts |
| Regras v18.1 no avaliador **SIMULADO** | **388/388** (não é aprovação oficial) |
| Prova de que os testes discriminam | mesmo `testar-regras.js` contra a **v18**: **16 falhas** (os novos casos de loja, estagiário e contorno); contra a v18.1: 0 |
| Emulador oficial do Firebase | **NÃO EXECUTADO** (npm sem resposta; JAR 403) |
| Firebase real, Mercado Pago real, celular | NÃO EXECUTADO |

Novos testes — **estagiário:** payload real permitido; heartbeat (merge) permitido; trocar categoria para prestador, campo estranho (`plano`), `uid` alheio, escrever disponibilidade de outra pessoa, PF sem cadastro, cadastro sem faculdade, plano vencido (T2), tipo prestador sem servidor, `master_ativo`, `precisaPlano` — todos bloqueados; plano válido permitido; nas 4 datas do simulador (antes/depois de 01/12/2026). **Loja:** Master, Golden com tipo `negocio`, Diamond vencido, sem `acessoPlano`, registro antigo, PF — bloqueados; Diamond e "todos" permitidos; usuário não consegue gravar `acessoPlano` nem trocar `tipo` para escapar.

## 5. Pendências
1. **Emulador oficial** (item crítico), incl. `request.time.toMillis()` e as novas expressões (`in [...]`, `hasOnly`, `exists/get` em `estagiarios`).
2. Decidir se o plano **Master** ("todas as áreas") deve criar loja — hoje não cria.
3. Demais riscos do relatório da etapa anterior seguem valendo (admin não confirmado, `wa` público, Storage, `x-signature`, etc.).

## 6. Comandos para o seu computador
Node 18+ e Java 11+:
```
cd testes/regras
npm install
npm test
```
Esperado: nenhuma linha `FALHOU`; no Emulador a contagem esperada é **367** (1 cenário de data em vez de 4; no simulador são 388). Depois `bash testes/rodar-todos.sh`. Se algo falhar: não publique; envie as linhas `FALHOU`.

## 7. Reversão
Republicar `firestore-regras-v18.txt` (ou v17/v16) no Console; restaurar `final-seguranca-lgpd-4.zip`. Esta etapa não tocou app, funções, dados nem Firebase.
