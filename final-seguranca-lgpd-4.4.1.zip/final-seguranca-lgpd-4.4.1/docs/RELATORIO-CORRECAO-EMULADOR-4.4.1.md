# Relatório 4.4.1 — correção da execução do Firestore Emulator

**Nada foi publicado, migrado ou alterado em dados reais. NÃO está pronto para produção.**
**O Emulator oficial NÃO foi executado por mim**: neste ambiente o `npm install` (firebase-tools, @firebase/rules-unit-testing) é negado pela política de rede (HTTP 403) e o JAR do emulador também não baixa. Tudo abaixo marcado "simulado" vem do avaliador local próprio, que **não aprova regras**. Você precisa rodar `npm test` no seu Windows para a confirmação oficial.

Base: pacote 4.4 (que contém o 4.3 + lojas gratuitas). A correção vale igualmente para 4.3.

## 1. Causa real do erro `Firestore has already been started and its settings can no longer be changed.`
Inspeção de `testes/regras/testar-regras.js` inteiro: toda chamada `ctx.firestore()` / `env.*Context().firestore()` foi listada. A única forma de o código chamar `firestore()` **duas vezes no mesmo contexto** (o SDK reconfigura/conecta o emulador a cada chamada e recusa quando a instância já está em uso) estava em dois pontos:
- linha 277: `withSecurityRulesDisabled(ctx => { setDoc(doc(ctx.firestore(),…)); setDoc(doc(ctx.firestore(),…)) })` (semear `assinaturas/LJ` e `lojas_autorizadas/LJ`);
- linha 460 (dentro do laço de datas): dois `deleteDoc(doc(ctx.firestore(),…))` no mesmo `ctx`.
Todos os outros usos já guardavam `const d = ctx.firestore()` uma vez, ou criavam um contexto novo por chamada.
**Limite da prova:** não consegui executar o Emulador, então a confirmação é por inspeção + reprodução no simulador. Para reproduzir, o avaliador local ganhou um **modo estrito** (`__FIRESTORE_ESTRITO`, ligado só por `executar-simulado.js`) que lança exatamente essa mensagem na segunda chamada de `firestore()` no mesmo contexto. Antes da correção o modo estrito falhou na linha 277 com esse erro; depois, passou. Esse comportamento do SDK é uma premissa minha — se o seu erro persistir, envie a linha do stack trace.

## 2. Correções
1. `testar-regras.js`: `const d = ctx.firestore()` uma única vez por contexto nos dois pontos. Nenhum teste removido.
2. **Caminho de regras**: `firebase.json` agora usa `"rules": "firestore.rules"` (dentro de `testes/regras`). `preparar-regras.js` copia o arquivo oficial `firestore-regras-v18.4.txt` para essa cópia (script `pretest` do `npm test`, e também ao iniciar `testar-regras.js`). Assim o teste usa o conteúdo oficial, sem duplicar manualmente.
3. **Aprovação administrativa**: o teste antigo `[v18.3 ADMIN]` esperava que o administrador **pelo app** aprovasse direto no Firestore (as regras permitiam, por `ehDono()`). Isso contraria o fluxo oficial. Foi substituído por 8 testes `[v18.4.1 …]`:
   - admin pelo app NÃO aprova direto (status+publicaAte, só publicaAte, só status; e-mail do dono verificado também não) → **bloqueia**;
   - admin pelo app ainda edita campos comuns (ex.: `ativo`) → permite;
   - **o mesmo código do servidor** (`functions/loja-lib.js decidir()`, usado pela função `decidirLoja`) roda sobre um adaptador com regras desligadas (equivale ao Admin SDK) e aprova uma loja pendente; confere status gravado, auditoria em `lojas_decisoes` e que o dono não desfaz depois.
4. **Mudança nas regras (única, restritiva)**: em `negocios`, `allow update` para `ehDono()` agora exclui os campos `aprovacaoStatus, publicaAte, aprovacaoEm, aprovacaoPor, aprovacaoMotivo`. Dono da loja, outros usuários, chat e app não mudam. Reverter: usar `firestore-regras-v18.3.txt`. O app não escreve esses campos como administrador (verificado: o app só envia `pendente` e remove campos do servidor).

## 3. Resultados reais
| Teste | Resultado | Tipo |
|---|---|---|
| `bash testes/rodar-todos.sh` (16 arquivos) | 16 passaram | simulado |
| Regras no avaliador local, modo estrito | **447/447** | simulado, NÃO oficial |
| Firestore Emulator oficial | **não executado** | — |
| Esperado no Emulator oficial | 414 testes (447 − 33: 1 cenário de data em vez de 4), nenhuma linha `FALHOU` | previsão |

## 4. Como rodar no Windows
```
cd testes\regras
npm install
npm test
```
(Node 18+, Java 11+). Se falhar, me envie as linhas `FALHOU`/`detalhe` e o stack trace completo. Possíveis divergências que só o Emulator mostra: data/relógio dos cenários (o Emulator usa a data real) e sintaxe das regras.
