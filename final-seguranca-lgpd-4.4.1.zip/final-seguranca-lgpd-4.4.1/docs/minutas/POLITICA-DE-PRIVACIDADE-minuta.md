# Política de Privacidade — MINUTA (não publicada)
> Rascunho para revisão jurídica. Itens **[A CONFIRMAR]** não foram inventados: dependem de dados oficiais ou decisão. Baseada na v1.1 do app, corrigida contra o código real.

**Versão:** 1.2-minuta · **Vigência:** [A CONFIRMAR]

## 1. Quem é o responsável (controlador)
[A CONFIRMAR: razão social/CNPJ ou nome e CPF do responsável, endereço]. FrilaOne, Sete Lagoas – MG.
**Canal de privacidade (encarregado/DPO):** [A CONFIRMAR: e-mail oficial] · **WhatsApp:** [A CONFIRMAR]

## 2. Dados que tratamos e para quê
| Dado | Finalidade | Base legal sugerida **[validação jurídica]** |
|---|---|---|
| Nome, e-mail, WhatsApp, tipo de perfil, área, cidade/bairro | criar e manter a conta, conectar pessoas | execução de contrato |
| Foto de perfil | exibir no perfil | execução de contrato / consentimento |
| CPF e selfie de verificação (opcional, para o selo) | confirmar identidade para o selo | consentimento / legítimo interesse |
| Registro profissional (CRP, OAB, CRN etc.) informado por profissionais | aprovar o selo de profissional que dá acesso aos pedidos de atendimento | execução de contrato / legítimo interesse **[validação jurídica]** |
| Conversas, pedidos de atendimento, avaliações | funcionamento do serviço | execução de contrato |
| Texto de saúde ou situação jurídica em pedidos de atendimento (sensível) | enviar aos profissionais escolhidos | **consentimento específico**, dado no próprio pedido, revogável |
| Contato de confiança e localização (Botão de Pânico, “Avisar que estou indo”) | segurança da pessoa | consentimento / proteção da vida **[validar]** |
| Dados de assinatura e pagamento (status, valores, datas; não guardamos número de cartão) | cobrança e obrigações fiscais | execução de contrato / obrigação legal |
| Registro de aceite dos Termos (versões, data e hora) | prova do aceite | legítimo interesse / exercício regular de direitos |

## 3. Localização
Só com a sua confirmação na hora. No Pânico e no “Avisar que estou indo”, ela vai por WhatsApp ao contato que você cadastrou — nunca à polícia/SAMU automaticamente — e fica gravada em nosso banco (data, hora, localização) por **[A CONFIRMAR: prazo — texto atual diz 90 dias; ver DECISOES-LGPD.md item 2]**.
Para descobrir a **cidade**, o app envia as **coordenadas** ao serviço **OpenStreetMap/Nominatim** (Fundação OpenStreetMap), depois que você autoriza; só a cidade fica no seu aparelho.

## 4. Com quem compartilhamos
Não vendemos dados. Operadores/terceiros que o app realmente usa (conferido no código):
- **Google/Firebase** — login (e-mail/senha e “Entrar com Google”) e banco de dados; os componentes do Firebase e a fonte de letra do app (Google Fonts) são carregados de servidores do Google, que recebem seu endereço IP.
- **Mercado Pago** — pagamento das assinaturas; o cartão é informado no ambiente do Mercado Pago, não no FrilaOne.
- **OpenStreetMap/Nominatim** — ao autorizar a localização, as coordenadas são enviadas para descobrir a cidade; só a cidade fica no aparelho.
- **BrasilAPI** — ao cadastrar uma empresa, o CNPJ informado é consultado em base pública.
- **WhatsApp (Meta)** e **Google Maps** — apenas por links que abrem quando você toca em um botão (conversar, avisar contato de confiança, ver mapa); no mapa de “minha localização”, as coordenadas vão no link aberto.
Outros usuários veem o que você publica (perfil, vagas, avaliações) e o conteúdo das conversas de que participa. Transferência internacional: servidores de alguns desses terceiros ficam fora do Brasil **[validação jurídica]**.

## 5. Armazenamento no aparelho, cookies e análise
O app **não usa cookies próprios** e **não carrega ferramenta de análise de uso de terceiros** [confirmar antes da publicação se alguma for adicionada]. Guarda no navegador/aparelho (armazenamento local) preferências, sessão e rascunhos; o Firebase Auth mantém sua sessão no aparelho. Limpar os dados do navegador apaga isso.

## 6. Por quanto tempo guardamos
Enquanto a conta existir. Ao excluir a conta (“Deletar minha conta”) apagamos perfil, vagas, CPF, contato de emergência, verificação e registros de emergência. **Mantemos**: registros de pagamento/assinatura **[A CONFIRMAR: prazo e base legal]**, comprovante do pedido de exclusão e do aceite dos Termos **[A CONFIRMAR]**, código embaralhado do e-mail por 30 dias (evita recadastro imediato) e conteúdo que pertence também a outras pessoas (conversas, avaliações) **[A CONFIRMAR: política]**.

## 7. Seus direitos (LGPD, art. 18)
Confirmação e acesso, correção, anonimização/bloqueio/eliminação, portabilidade, informação sobre compartilhamento, revogação de consentimento e revisão de decisões automatizadas. Peça em [A CONFIRMAR: canal] ou use “Deletar minha conta” em Configurações. Você também pode reclamar à ANPD.

## 8. Crianças e adolescentes
[A CONFIRMAR: idade mínima e regra para menores]

## 9. Mudanças
Avisaremos no app e, quando exigido, pediremos novo aceite. A versão vigente aparece no topo.
