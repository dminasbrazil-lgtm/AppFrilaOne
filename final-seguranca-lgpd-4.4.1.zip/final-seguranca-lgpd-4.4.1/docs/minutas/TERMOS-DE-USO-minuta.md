# Termos de Uso — MINUTA (não publicada)
> Rascunho a partir da v1.1 do app; apenas ajustes de coerência. Itens **[A CONFIRMAR]** dependem de decisão/validação jurídica.

**Versão:** 1.2-minuta · **Responsável:** [A CONFIRMAR: identificação do controlador]

1. **Aceitação.** Ao criar conta e usar o FrilaOne você concorda com estes Termos e declara estar ciente da Política de Privacidade (que é um aviso, não um consentimento para todas as finalidades; consentimentos específicos são pedidos à parte).
2. **O que é o FrilaOne.** Plataforma que conecta empresas, trabalhadores, prestadores, profissionais e clientes em Sete Lagoas/MG. Não é empregador nem intermediário formal de contratações.
3. **Responsabilidades do usuário.** Dados verdadeiros e atualizados; guardar a senha; não publicar conteúdo falso, ofensivo ou ilegal; cumprir acordos feitos com outros usuários.
4. **Planos e pagamentos.** Valores vigentes: Golden R$ 14,90, Master (“Todas as áreas de acesso”) R$ 34,90, Diamond (“Meu Negócio”) R$ 79,90; Pessoa Física gratuita. [A CONFIRMAR: condições do período gratuito até 30/11/2026 e do teste de 7 dias para cadastros a partir de 01/12/2026.] Pagamento via Mercado Pago; o FrilaOne não armazena dados de cartão. Cancelamento: [A CONFIRMAR]. **Reembolso:** [A CONFIRMAR — o texto atual “sem reembolso após 7 dias” precisa de validação à luz do Código de Defesa do Consumidor].
5. **Conteúdo e vagas.** De responsabilidade de quem publica; o FrilaOne pode remover o que violar os Termos ou a lei.
6. **Segurança e Botão de Pânico.** Registra a ocorrência e a hora, tenta obter a localização e envia por WhatsApp ao contato de confiança que você cadastrou — não à polícia nem ao SAMU. Em perigo real ligue 190 ou 192. O FrilaOne não garante resposta.
7. **Atendimento com profissionais.** O FrilaOne apenas conecta; não presta serviço de saúde, jurídico ou outro regulamentado. Emergência: 188 (CVV) ou 192 (SAMU).
8. **Conta e exclusão.** Você pode excluir a conta em Configurações; o tratamento dos dados na exclusão segue a Política de Privacidade.
9. **Modificações.** Avisaremos no app; mudanças relevantes podem exigir novo aceite.
10. **Contato.** [A CONFIRMAR: e-mail e WhatsApp oficiais]. **Foro:** [A CONFIRMAR].
