# Ativação segura (v18) — ordem de publicação e reversão
**NADA disto foi executado.** Pré-requisito de tudo: `cd testes/regras && npm install && npm test` no seu computador (Emulador oficial) com todos os testes OK. Sem isso, pare.

## Como a segurança funciona na v18
- **Sempre ligado nas regras** (sem chave): `trial_*`, `verificado:true`, `master_ativo:true`, plano pago e nota própria não podem ser gravados pelo usuário no próprio perfil. O app v4 já não os grava. A chave `protegerCampos` **deixou de existir**.
- **Exigência de acesso (vaga, "tô disponível", loja)** liga **sozinha em 01/12/2026 00:00 (Brasília)**, por data, sem depender de ninguém. Opcionalmente pode ser antecipada com `config/seguranca.exigirAcesso=true` (`migracao/ligar-chaves-seguranca.js`).
- Vale só para conta de plano: `precisaPlano:true` (gravado pelo servidor, permanente) OU `tipo` prestador/acadêmico/empresa/negócio OU `master_ativo`. Mudar `tipo` para "pessoa física" **não** escapa.
- Acesso = campos `acessoRegraAte`/`acessoPlano` em `assinaturas/{uid}`, escritos só pelo servidor (inclui 3 dias de carência).
- **Se o Modo Servidor não estiver publicado até 30/11**, quem é de plano ficará sem acesso em 01/12 (não há quem escreva o acesso). Por isso o Modo Servidor deve estar no ar e testado **antes**.

## Ordem (cada passo só depois de testar o anterior)
1. Testes das regras no Emulador oficial (acima).
2. Segredos das funções: `MP_ACCESS_TOKEN` (**teste** do Mercado Pago) e `MP_WEBHOOK_SECRET`; plano Blaze (ver `functions/LEIA-ME-SERVIDOR.md`).
3. Administrador: `node migracao/definir-admin.js UID` (simulação → `--executar`). Confirmar no Console o UID e o e-mail verificado de `frilaoneapp@gmail.com`.
4. Profissionais existentes: `node migracao/conceder-profissional.js` (lista) → conferir no conselho → `--aprovar=UID --executar`.
5. Dados privados: `migrar-dados-privados.js` (simulação → `--executar` → `--verificar`; agora inclui `email` e `emailContato`). `limpar-campos-antigos.js` só quando a verificação não tiver divergência.
6. `node migracao/verificar-prontidao.js` (somente leitura): resolver os bloqueios.
7. `node migracao/revisar-selos.js` (simulação) e decidir sobre selos sem verificação válida.
8. Publicar **funções**: `firebase deploy --only functions`.
9. Publicar o **app** (`_ASSINATURA_ATIVA = true`, só com credenciais de teste) **ANTES das regras**: o app antigo em cache falha ao salvar com as regras v18.3 (grava campos hoje bloqueados).
10. Publicar **regras v18.4** (Console → Firestore → Regras).
11. Testar com contas de teste: cadastro, login, trial criado pelo servidor, selo, Master, "Já assinei", exclusão, aceite, vaga, loja.
12. Opcional: `ligar-chaves-seguranca.js --executar --confirmo-modo-servidor` para antecipar a exigência.
13. Cobrança real (token de produção) é decisão sua, fora deste pacote.

## Reversão
- Regras: republicar `firestore-regras-v17.txt` (ou v16). Chave antecipada: `ligar-chaves-seguranca.js --desligar --executar`. App: publicar a versão anterior. Funções: `firebase functions:delete NOME` ou redeploy anterior.
- Nada acima apaga dados.

## v18.4 (inclui v18.3) — estágio e Minha Loja (decisões de produto 4.2 e 4.3)
- **Estágio é separado do "Tô disponível":** cadastro e presença em `estagiarios/{uid}` (gratuito, sem privilégio). Nenhum `disponiveis` pode ter `categoria:'estagiario'`.
- **Minha Loja — aprovação administrativa (4.3):** o dono cadastra (nasce `aprovacaoStatus:'pendente'`, não aparece na vitrine nem abre). O administrador decide pela função `decidirLoja` (ou, por enquanto, `node migracao/decidir-loja.js`). Só o servidor grava `aprovada/pendencia/recusada` e `publicaAte`. **A aprovação não substitui a cobrança:** `publicaAte = max(30/11/2026, pago até)`; o pagamento é registrado em `lojas_autorizadas/{uid}.ate` (`node migracao/autorizar-loja.js`, manual — ainda não há cobrança automática da Minha Loja).
- **Ordem:** funções (inclui `decidirLoja`) → app → regras v18.4. **Antes das regras/app**: (1) `node migracao/decidir-loja.js --listar`; (2) confirme o `negId` das DUAS lojas (Tênis Life e Loja FrilaOne); (3) `node migracao/marcar-loja-gratuita.js --negId=neg_X,neg_Y` (simulação) e depois com `--executar --confirmo-que-sao-estas-lojas`; (4) aprove cada uma: `node migracao/decidir-loja.js --aprovar-legado --negId=neg_X,neg_Y` (simulação, depois `--executar`). Sem isso elas somem da vitrine (o app novo lista por `publicaAte`). Só essas lojas ficam grátis para sempre; todas as novas passam por aprovação e cobrança.
- Reversão: republicar `firestore-regras-v18.2.txt` (ou v18.1/v18/v17/v16) e o app anterior.
