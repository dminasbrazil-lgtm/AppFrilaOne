# FrilaOne — Decisões e pendências LGPD (etapa de correções controladas, 12/10/2026)

Nada aqui foi publicado nem aplicado em produção. Tudo marcado **[A CONFIRMAR]** depende de decisão sua ou de validação jurídica.

## 1. Exclusão de conta (`processarExclusao`) — o que apaga e o que mantém

| Dado | Destino | Motivo |
|---|---|---|
| `usuarios/{uid}`, `disponiveis`, `curriculos`, `estagiarios`, `negocios/neg_{uid}`, `vagas` da pessoa | **Apaga** (já era assim) | perfil público e anúncios |
| `usuarios_privado/{uid}` (CPF, contato de emergência) | **Apaga** (novo) | dado pessoal sem finalidade após a exclusão |
| `negocios_privado/neg_{uid}` e docs com `uid` da pessoa (CPF da loja) | **Apaga** (novo) | idem |
| `verificacoes/{uid}` (CPF, selfie) | **Apaga** (novo) | dado sensível usado só para o selo |
| `emergencias` com `uid` da pessoa (localização, aviso de saída/pânico) | **Apaga** (novo) | dado de localização; a Política já promete exclusão a pedido |
| Login (Firebase Auth) | **Apaga** | já era assim |
| `assinaturas/{uid}`, `pagamentos` | **Mantém** | registro financeiro/fiscal e defesa em disputa de cobrança. **[A CONFIRMAR]** prazo e base legal com contador/advogado |
| `exclusoes_bloqueadas/{hash}` | **Mantém** (30 dias) | só o código embaralhado do e-mail, sem e-mail legível |
| `solicitacoes_exclusao/{uid}` | **Mantém** | prova de que o pedido foi atendido (e-mail é removido do documento) |
| `aceites_termos/{uid}` | **Mantém** | prova do aceite dos Termos. **[A CONFIRMAR]** por quanto tempo |
| Conversas, avaliações e indicações que envolvem **outras pessoas** | **Mantém** (não tocado) | pertencem também à outra parte. **[A CONFIRMAR]** política (ex.: anonimizar o nome do autor) |

Prova: `testes/teste-exclusao.js` (Firebase falso em memória; nada real tocado). Verifica itens apagados, itens mantidos, dados de **outra conta** intactos, e-mail só em hash.

Ainda não coberto: cópias do mesmo dado em outros lugares (ex.: nome gravado dentro de conversas/avaliações de terceiros, fotos em storage — o Storage não é usado pelo app). Registrado como pendência.

## 2. Divergência: “90 dias” × ausência de rotina de limpeza

- A Política (v1.1) diz que o registro de localização/saída é guardado “por até 90 dias”. O app grava `expiraEm` em cada documento de `emergencias`, mas **não existe nenhuma rotina que apague** documentos vencidos (regras: cliente não apaga). Hoje a promessa não é cumprida automaticamente.
- **Solução proposta (sem prazo legal inventado):**
  1. **Opção A (recomendada):** função agendada diária que apaga `emergencias` com `expiraEm < agora`. Só entra em produção depois de você decidir o prazo (manter 90 dias ou outro) e de revisão jurídica. Até lá **não foi criada nem ativada**.
  2. **Opção B:** trocar o texto da Política por “guardamos até você excluir a conta” (sem automatismo).
  3. Até decidir: rodar manualmente `migracao/limpar-emergencias-expiradas.js` (criado nesta etapa; **por padrão só lista**, não apaga; apagar exige `--apagar`).
- Nenhuma exclusão automática irreversível foi implementada.

## 3. Aceite dos Termos (P2/P3)

- **Cadastro por e-mail:** a caixa já era obrigatória; agora, após criar a conta, o app pede ao servidor (`registrarAceite`) para gravar o aceite.
- **Conta nova pelo Google:** antes de entrar, aparece uma tela com os links e uma caixa para aceitar. Quem **recusa** tem a conta do login cancelada (o servidor apaga o perfil recém-criado, função `limparPerfilDoLoginExcluido`); se o cancelamento falhar, a tela continua aberta e a pendência fica marcada. A tela reaparece se a pessoa recarregar a página antes de aceitar.
- **Quem já tem conta:** nada muda (login, recuperação de senha e sessões intactos). Não há reaceite forçado.
- **Registro (`aceites_termos/{uid}` + subcoleção `eventos`):** versões dos Termos e da Política, data/hora **do servidor**, tipo de ação, origem e navegador. Só o servidor grava (regra `allow write: if false`); a pessoa só lê o próprio. O `uid` vem do token — não dá para registrar aceite para outra conta.
- **Ciência ≠ consentimento:** esse registro vale para Termos + ciência da Política. Consentimentos específicos (ex.: dado de saúde no pedido de atendimento) continuam com tela e registro próprios e **não** são cobertos por ele.
- **Mudança de versão:** o servidor só aceita a versão vigente (constante `TEXTOS_VIGENTES` em `functions/assinatura.js`, e `_TERMOS_VERSAO/_PRIVACIDADE_VERSAO` no app — mudar os dois juntos). O fluxo de reaceite proporcional (aviso ao abrir o app) fica **pendente**; a ação `reaceite` do servidor já existe.
- **Limites honestos:** (a) o portão do Google é aplicado pelo app, não pelo servidor; quem burlar o app teria conta sem registro em `aceites_termos` (detectável). (b) Se a rede falhar na hora do aceite, o app tenta de novo no próximo acesso. (c) Depende de publicar as funções e as regras.

## 4. Pontos que dependem de você (não inventados)

- **[A CONFIRMAR]** Identificação do controlador (razão social/CNPJ ou nome e CPF do responsável, endereço).
- **[A CONFIRMAR]** E-mail oficial de privacidade e canal de WhatsApp. **Atenção:** os textos **já publicados no app** trazem `suporte@frilaone.com.br` como “Encarregado (DPO)” e o WhatsApp `(31) 98229-9024` nos Termos. Não alterei nem confirmei; se não forem os oficiais, corrija antes do lançamento.
- **[A CONFIRMAR]** Prazos de retenção (pagamentos, aceites, emergências), idade mínima, cláusula de reembolso (“sem reembolso após 7 dias”), bases legais por finalidade, foro.

## 5. Conferência das afirmações da Política contra o código real

| Afirmação / tema | O que o código mostra | Ação |
|---|---|---|
| “Dados de uso (acessos, navegação)” | Nenhum SDK de análise carregado (`_track` só age se existir `firebase.analytics`); 0 cookies; ~128 chaves `frilaone_*` no armazenamento local do aparelho | Texto da minuta corrigido: sem análise de uso por terceiros hoje; armazenamento local descrito |
| Cookies | Nenhum cookie próprio. Armazenamento local (localStorage) para preferências/sessão; o Firebase Auth usa armazenamento local/IndexedDB | Minuta descreve |
| Localização | Pânico e “estou indo”: enviada por WhatsApp ao contato escolhido e gravada em `emergencias` | Já descrito; retenção: ver item 2 |
| **BrasilAPI / Google Fonts / Google Maps** | CNPJ digitado vai à BrasilAPI (l. ~3779); fonte carregada de fonts.googleapis.com; links do Google Maps com coordenadas (l. ~14746) | **Não constavam** na Política v1.1 nem na minuta anterior. Incluídos na minuta 4 |
| Firebase Storage | SDK carregado, mas **sem nenhum uso** no código | Confirmar no Console se o Storage está desativado ou com regras que negam tudo |
| **OpenStreetMap/Nominatim** | `_pedirLocalizacao` envia as **coordenadas** ao servidor do Nominatim (OpenStreetMap) para descobrir a cidade, após a pessoa autorizar; só a cidade fica no aparelho | **Não consta** na Política v1.1. Incluído na minuta |
| Terceiros | Firebase/Google (login e banco), Mercado Pago (pagamento), OpenStreetMap/Nominatim, WhatsApp (links `wa.me`, iniciados pela pessoa) | Minuta lista todos |
| “Compartilhamos apenas com Firebase e Mercado Pago” | Incompleto (faltam Nominatim e WhatsApp) | Corrigido na minuta |

A Política publicada no app **não foi alterada** nesta etapa (v1.1 continua). As minutas ficam em `docs/minutas/` para revisão jurídica; só depois viram v1.2 no app (e o servidor/app passam a exigir a nova versão).


## 6. Atualização da auditoria (12/10/2026, 2ª etapa)
- **Exclusão com repetição:** `processarExclusao` agora dispara em qualquer gravação e só age com `status == 'pendente'`; marca `processando`, e só grava `concluida` se **todas** as etapas deram certo. Em falha grava `erro` e **não** apaga o login; a pessoa pode pedir de novo (o app regrava `pendente`). Antes, um pedido com erro ficava parado para sempre. Pendência operacional: acompanhar no Console pedidos com `status == 'erro'` (o app avisa “sendo excluída” e desconecta a pessoa de qualquer forma).
- **Emergências:** script `limpar-emergencias-expiradas.js` usa `expiraEm` (número, gravado pelo app nos dois pontos de gravação), só apaga vencidos, nunca mexe em recentes, sem data válida ou outras coleções, e é simulação por padrão (`--apagar` para apagar; `--uid=` para restringir). **Decisões necessárias antes de publicar a Política:** (1) confirmar 90 dias ou outro prazo; (2) escolher limpeza agendada (função diária) ou manual; (3) o que fazer com registros antigos sem `expiraEm` (o script só lista).
- **Aceite no servidor:** ver `RELATORIO-AUDITORIA-LGPD.md`, seção 1 (proposta, não implementada).

## 7. Atualização (3ª etapa — correções definitivas)
- **Profissional Acadêmico:** deixou de ser auto-declarado (`cadMaster` no próprio perfil). Agora só vê/aceita pedidos de agendamento quem está em `profissionais_aprovados/{uid}` (`ativo:true`), gravado só por você (script `conceder-profissional.js`) depois de conferir o registro no conselho. Motivo: o campo `descricao` do pedido pode conter **dado de saúde (sensível)**; não pode ficar legível por quem apenas escreve um campo no próprio perfil. Efeito para o usuário: profissional novo vê a mensagem “cadastro em análise” até ser aprovado. **[A CONFIRMAR]** o fluxo/prazo de aprovação e se haverá taxa de verificação; **[validação jurídica]** base legal para tratar o número de registro profissional.
- **Exclusão:** também apaga `profissionais_aprovados/{uid}`. Continua mantendo pagamentos/assinaturas, aceites e demais itens do item 1 (prazos **[A CONFIRMAR]**).
- **Perfil público:** CPF e contato de emergência não podem mais ser gravados em `usuarios` (só apagar). Perfis legados ainda os contêm até rodar a migração (script `verificar-prontidao.js` conta quantos).
- **Acesso manual (pagamentos de links antigos):** agora confere o pagamento no Mercado Pago (aprovado; valor, se você informar) e impede o mesmo pagamento em duas contas.


## Atualização v18 — e-mails e campos públicos de `usuarios`
- `email` e `emailContato` agora são gravados em `usuarios_privado/{uid}` (só titular/admin leem). O app v4 não os envia ao perfil público; `migrar-dados-privados.js` copia os antigos e `limpar-campos-antigos.js` apaga do público só quando o privado é idêntico.
- As regras NÃO bloqueiam `email` no perfil público de propósito (compatibilidade com app antigo em cache); a limpeza é feita pela migração.
- `usuarios` continua legível por qualquer logado: restam apenas campos de perfil público necessários à busca, destaque, perfil e conversa (nome, foto, bio, cidade, bairro, wa, tipo, xp, bloqueados, cadMaster/cadParceiro…). `wa` e `ultimoLogin` ficam públicos — decisão de produto/jurídica pendente.
