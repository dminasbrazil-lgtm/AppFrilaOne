> **HISTÓRICO de etapa anterior** — números e arquivos podem estar defasados. Vale `RELATORIO-ETAPA-FINAL.md`.

# Relatório — auditoria do pacote LGPD (12/10/2026, 2ª etapa)
Base: `final-seguranca-lgpd` da etapa anterior, relido diretamente (app, funções, regras, testes, docs). Nada publicado; nenhum dado de produção alterado; nenhuma cobrança ativada. Resultado: pacote novo `final-seguranca-lgpd-2.zip` (a versão anterior permanece como estava).

## 1. Aceite (registrarAceite, cadastro e Google)
| Verificação | Resultado | Como foi verificado |
|---|---|---|
| Identidade vem do token, não do cliente | OK | leitura + teste (uid no corpo ignorado) |
| Servidor valida versões e ação | OK | teste (409/400) |
| Cliente não falsifica histórico | OK | regra `write: if false` (leitura do texto; **teste de regras pendente**) |
| Gravação atômica | **Problema: registro e histórico eram dois passos** → corrigido com lote único; falha responde 500 e não grava pela metade | teste |
| Falha temporária da função | OK: não trava o app, deixa lembrete, tenta de novo no próximo acesso; lembrete de outra conta não é usado | teste no Chromium |
| Recusa no Google | **Problema: se o cancelamento da conta falhasse (login antigo/sem rede), a pessoa saía com a conta criada e sem aceite, e no próximo Google a conta já não seria “nova”.** Corrigido: tenta cancelar; se pedir login recente, confirma com o Google; se ainda falhar, a tela continua e a pendência fica marcada. O perfil público criado é apagado pelo servidor (nova função `limparPerfilDoLoginExcluido`) | teste no Chromium |
| Usuários existentes | OK: `loginGoogle` de conta existente entra direto, sem tela e sem marca | teste no Chromium (antes era só leitura de código) |
| Aceite ≠ consentimento específico | OK: registro só tem termos + ciência da política | teste |

**Exigir aceite no servidor (proposta, NÃO implementada):** as operações que fazem sentido exigir são só as de **publicar conteúdo/oferta**: criar vaga (`vagas`), criar loja (`negocios`), ficar disponível (`disponiveis`), pedir agendamento. **Não** exigir em: login, recuperação de senha, leitura, exclusão de conta, pedidos do titular, pagamento/assinatura, emergência.
Dificuldade: contas existentes não têm registro; a regra precisaria distinguir “conta anterior ao corte” de “conta nova sem aceite”, e o campo `criadoEm` do perfil é escrito pelo próprio usuário (não confiável). Caminhos seguros: (A) **claim** no login (`aceite=true`) gravada por `registrarAceite`, exigida nas regras só para quem foi criado após o corte — exige juntar com a claim `admin` já usada, renovar o token no app e testar tudo no Emulador; (B) coleção `contas_novas/{uid}` criada por função no cadastro e removida em `registrarAceite`, exigida na regra. Ambas mexem em regras e no fluxo de cadastro → **precisam da sua aprovação do impacto antes**. Passo intermediário sem risco: `migracao/auditar-aceites.js` (somente leitura) lista contas novas sem aceite, para medir o problema antes de bloquear.
Limite atual: o portão do Google é do app; quem burlar o app fica sem registro (detectável pelo script acima).

## 2. Exclusão de conta
- Cobre `usuarios_privado`, `negocios_privado` (por id `neg_{uid}` **e** por campo `uid`), `verificacoes`, `emergencias` (por `uid`) além do que já apagava. Vínculos conferidos nas regras/código.
- **Problema encontrado:** o gatilho era só “ao criar”; um pedido que terminasse em `erro` nunca era refeito (regravar o pedido não disparava). Corrigido: dispara em qualquer gravação, age só com `status == 'pendente'`, marca `processando`, e só grava `concluida` se todas as etapas deram certo; em falha, `erro` e o login **não** é apagado; novo pedido refaz.
- Mantidos (documentado em `DECISOES-LGPD.md`): pagamentos, assinaturas, aceites, bloqueio de recadastro, pedido de exclusão, dados de terceiros — prazos **[A CONFIRMAR]** juridicamente.
- Risco que permanece: o app mostra “sendo excluída” e desconecta mesmo se o servidor depois falhar; acompanhar pedidos com `status == 'erro'` no Console.

## 3. Retenção de emergências
Script revisado e refeito para ser testável: usa `expiraEm` (número em ms; o app grava nos **dois** pontos de gravação), só vencidos, nunca recentes/no limite/sem data/outras coleções, simulação por padrão. Nenhuma rotina agendada criada. **Decisões pendentes:** prazo definitivo, limpeza agendada ou manual, destino de registros antigos sem `expiraEm`.

## 4. Regras do Firestore v16 (leitura completa)
Regras **não aprovadas**: 103 testes preparados e **NÃO executados** (instruções em `testes/regras/EXECUTAR-NO-COMPUTADOR.md`).
Riscos encontrados (nenhum alterado sem teste no Emulador):
1. **Chaves desligadas = sem proteção.** Enquanto `config/seguranca` não tiver `protegerCampos`/`exigirAcesso` ligados, qualquer usuário pode gravar no próprio perfil `plano`, `verificado`, `trial_*`, `master_ativo` e a própria nota. **Alto, é o estado atual do arquivo.**
2. **Dono por e-mail sem verificação** (`ehDono`): se a conta `frilaoneapp@gmail.com` não existir/estiver sem e-mail verificado, outra pessoa pode registrá-la e ler selfies/CPF (`verificacoes`), denúncias, aceites etc. **Alto**; aplicar a linha `email_verified` depois de confirmar no Console.
3. **Dados de saúde em `agendamentos` abertos:** quem tem o campo `cadMaster` no próprio perfil (campo que o próprio usuário escreve) lê todos os pedidos abertos, cuja `descricao` pode ter dado sensível. **Alto/médio** (LGPD). Solução estrutural: selo de profissional concedido pelo servidor.
4. `usuarios` é legível por qualquer logado (e-mail, WhatsApp, etc.). Dados legados `cpf`/`contatoEmergencia` ainda ali até rodar `migrar-dados-privados.js`/`limpar-campos-antigos.js`. **Médio.**
5. `negocios`: criação não exige id `neg_{uid}` (o app também usa `meuId`/`negId` variáveis) → possível “ocupar” o id de outra pessoa; e o dono pode trocar o campo `uid`. **Baixo/médio.**
6. `exclusoes_bloqueadas` permite `get` público (confirmar se um e-mail foi excluído há pouco, só com o hash). **Baixo**, por desenho.
7. `indicacoes`: qualquer novo usuário escolhe o `referrerUid` (risco de indicações falsas se houver recompensa). **Baixo.**
8. Firebase **Storage**: SDK carregado e sem uso; confirmar no Console que está desativado ou nega tudo (arquivo de regras de Storage não está no pacote).
Sem achados novos em: `pagamentos`, `assinaturas`, `aceites_termos`, `usuarios_privado`, `negocios_privado`, `conversas`/`mensagens`, `emergencias` (sem update/delete pelo cliente).

## 5. Documentos
Comparados com o código: faltavam na Política (e na minuta) **BrasilAPI** (CNPJ), **Google Fonts**, **Google Maps** (links) e a carga dos componentes Firebase pelo Google; incluídos na minuta. Cookies: 0 próprios; armazenamento local; sem análise de uso de terceiros — coerente. Nominatim, Mercado Pago, WhatsApp: coerentes. Mantidos todos os `[A CONFIRMAR]`; nada inventado. Os textos publicados no app não foram alterados (continuam v1.1 e com e-mail/WhatsApp que **você** precisa confirmar).

## 6. Testes
**Executados (Node/Chromium reais, Firebase/MP simulados):** teste-app 43/43 · teste-acesso 25/25 · teste-servidor-simulado OK (14 chamadas falsas) · teste-botao-ja-assinei 5/5 · teste-migracao 8/8 · teste-beneficios 5/5 · **teste-exclusao** (inclui falha, nova tentativa, status do servidor ignorados, limpeza ao apagar login) · **teste-aceite 22/22** (servidor, links, Google novo/existente, recusa com falha/reautenticação, falha temporária) · **teste-emergencias 4/4** · sintaxe dos 22 scripts do app e de todos os .js · 0 `mpago.la` · preços oficiais presentes.
**Pendentes:** 103 testes de regras no Emulador; qualquer teste com Firebase, Google, celular ou Mercado Pago reais; publicação das funções (`registrarAceite`, `limparPerfilDoLoginExcluido`, `processarExclusao` alterada).

## 7. Arquivos alterados nesta etapa
`functions/index.js` (exclusão com repetição + limpeza de perfil) · `functions/assinatura.js` (lote atômico) · `app/teste-final.html` (recusa do Google) · `firestore-regras-v16.txt` (só comentários reposicionados; lógica igual) · `migracao/limpar-emergencias-expiradas.js` (refeito) · novos: `migracao/auditar-aceites.js`, `testes/teste-emergencias.js`, `testes/regras/EXECUTAR-NO-COMPUTADOR.md`, este relatório · atualizados `testes/teste-exclusao.js`, `testes/teste-aceite.js`, `docs/DECISOES-LGPD.md`, `docs/minutas/POLITICA-DE-PRIVACIDADE-minuta.md`.

## 8. Execução local e reversão
Testes: `cd testes && for t in teste-*.js; do node $t; done` (Node 18+). Regras: ver `testes/regras/EXECUTAR-NO-COMPUTADOR.md`. Simulação de emergências (precisa de credencial admin): `node migracao/limpar-emergencias-expiradas.js`. Reversão: voltar ao `final-seguranca-lgpd.zip` anterior (ou `final-seguranca`); nada foi escrito em produção.
