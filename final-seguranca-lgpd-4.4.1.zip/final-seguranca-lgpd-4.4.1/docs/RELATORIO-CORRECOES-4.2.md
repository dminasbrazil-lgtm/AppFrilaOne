# RELATÓRIO — AJUSTE DE ESCOPO 4.2 (`final-seguranca-lgpd-4.2`)

**Não está pronto para produção.** Regras v18.2: **403/403 no avaliador SIMULADO** (não é aprovação). **Emulador oficial NÃO executado**: nesta sessão o `npm view firebase-tools` não retornou e o download do JAR foi recusado pelo proxy ("organization policy"). Nada foi publicado no Firebase, nenhum dado foi migrado, nenhuma cobrança foi ativada, nada foi enviado ao GitHub. `final-seguranca-lgpd-4.zip` e `-4.1.zip` foram preservados.

## 1. Verificação pedida: o código já mantinha estágio e disponibilidade separados?
**Não.** Encontrei em `teste-final.html` (4.1):
- `toggleEstOnline()` gravava `disponiveis/{uid}` com `categoria:'estagiario'` — ou seja, o estagiário "online" entrava na coleção do "Tô disponível" e aparecia na lista da tela inicial junto com profissionais;
- o status "Online" da aba Estágio era lido de `_disponiveisUids` (cache do "Tô disponível");
- o botão online do estágio consultava a trava de assinatura (`_permitirAcaoPaga`);
- ficar offline / excluir cadastro de estagiário chamavam `_pararHeartbeatPresenca()` e **apagavam `disponiveis/{uid}`** — o que também derrubava a disponibilidade de um profissional que fosse a mesma conta.
Por isso o código **precisou** ser alterado (pouco, sem tocar em telas).

## 2. Mudanças efetivamente feitas
**App (`app/teste-final.html`)** — sem alterar cards, abas, textos visuais ou navegação:
- Estágio online/offline passa a gravar só `estagiarios/{uid}` (`online`, `onlineTs`; renovação a cada 60 s; sem renovar por 2 h = offline) e a aba Estágio lê isso. Funções novas: `_estEstaOnline`, `_estIniciarHeartbeat`, `_estPararHeartbeat`.
- Removidos: gravação em `disponiveis` com `categoria:'estagiario'`, uso de `_disponiveisUids` pelo estágio, o `delete` de `disponiveis` ao sair/excluir cadastro, o uso do heartbeat do "Tô disponível" e a trava de assinatura no botão (estágio é gratuito e independente de plano). Logout põe `online:false` no cadastro do estagiário.
- Preservados: cadastro, busca/lista de estagiários, chat, toggles e mensagens do estágio.

**Regras (`firestore-regras-v18.2.txt`, a partir da v18.1):**
- Removida a isenção `disponivelEstagiario` (proposta da 4.1). `acessoDisponivel = !cobrancaAtiva() || acessoServidor`.
- `disponiveis` recusa **qualquer** documento com `categoria:'estagiario'` (é o que impede misturar estudantes com profissionais; sem atalho por categoria).
- `estagiarios/{uid}` inalterada (qualquer logado lê; só o dono escreve): gratuito e sem efeito sobre plano, `master_ativo` ou áreas pagas.
- **Minha Loja independente:** `acessoLoja = !cobrancaAtiva() || lojaAutorizada(uid)`, onde `lojaAutorizada` lê `lojas_autorizadas/{uid}.ate` > agora. Coleção nova, `write: if false` para clientes (inclusive administrador pelo app); titular e admin leem. Vale para criar a loja e para a loja "aberta" (`disponiveis` com `categoria:'negocio'`). **Substitui** a regra da 4.1 que exigia `acessoPlano` diamond/todos. Golden, Master, Diamond, teste grátis e `tipo` não concedem loja automaticamente. Campanha (antes de 01/12/2026) continua livre. Lojas já existentes não são afetadas.
- Nada mais foi desfeito: proteção permanente de `trial_*`/`verificado`/`master_ativo`/plano, `precisaPlano`, e-mails privados, etc. seguem como na v18.

**Script novo `migracao/autorizar-loja.js`:** simulação por padrão; `--uid=… --ate=AAAA-MM-DD --executar` grava a autorização; `--revogar`. Só escreve em `lojas_autorizadas`.
**Servidor:** nenhuma alteração de lógica (só o comentário de `acessoPlano`, que continua sendo gravado, mas agora é informativo). **Preços e demais funcionalidades: intactos.**

## 3. Testes alterados / acrescentados (e justificativa)
Mudanças de expectativa **deliberadas**, causadas pela decisão de produto 4.2:
1. `T8 (Diamond válido) cria a loja` e `T9 (teste grátis) cria a loja`: *permite → bloqueia* (loja não deriva mais de plano).
2. Testes da 4.1 de estagiário em `disponiveis` (permitir/heartbeat/"plano válido como estagiário") foram **substituídos** por testes da regra nova (bloqueia sempre); os de loja por plano (`acessoPlano`) foram substituídos por testes da autorização própria.
3. Seeds de loja `P` e `LJ` ganharam `lojas_autorizadas` (a intenção desses testes — criar a própria loja `neg_`+uid — não mudou).
4. `teste-acesso-regras.js`: em todos os cenários de plano a loja é negada sem autorização e permitida com `lojas_autorizadas`.
Novos: estágio gratuito mesmo com plano vencido; presença do estagiário só no próprio cadastro; categoria `estagiario` bloqueada em `disponiveis` (inclusive merge, com plano válido e nas 4 datas); cadastro de estagiário não libera "Tô disponível" de profissional; loja: autorização válida/vencida, plano Master/Golden/Diamond/teste sem autorização, cliente/admin não gravam autorização, titular lê só a própria, loja aberta exige autorização; no Chromium: botão online/offline/excluir do estágio nos dois modos do servidor (nunca toca `disponiveis`, sem trava de assinatura, expiração de 2 h) e replay das gravações nas regras; varredura estática; 2 testes do script.

## 4. Testes realmente executados
| Teste | Resultado |
|---|---|
| `bash testes/rodar-todos.sh` | **passou tudo** (14 suítes) |
| Regras v18.2, avaliador SIMULADO | **403/403** |
| Acesso×regras / regressão do app (Chromium, Firestore falso) / app sem privilégios / scripts | 67 OK / 26 OK / 9 OK / 15 OK |
| Sintaxe dos 22 scripts do app | OK |
| Discriminação: regressão do app contra o app 4.1 | falha no teste de estágio (prova que pega o problema) |
| **Emulador oficial do Firebase** | **NÃO EXECUTADO** |
| Firebase real, Mercado Pago real, celular | NÃO EXECUTADO |

## 5. Pendências reais
1. **Emulador oficial** (crítico) — inclui `toMillis()` e as expressões novas (`exists/get` em `lojas_autorizadas`, operador ternário em `disponiveis`).
2. **Decisão sua:** como a autorização de Minha Loja será concedida a quem contratar (hoje só manual, por script). Sem isso, ninguém novo cria loja após 01/12/2026. Quem hoje pagaria "Diamond = Minha Loja" não recebe loja automaticamente.
3. App em cache antigo: o botão online do estagiário falha silenciosamente sob as regras v18.2 → publicar o app antes das regras.
4. Documentos antigos em `disponiveis` com `categoria:'estagiario'` (criados pelo app anterior) não foram migrados nem apagados; somem pela expiração de 2 h/saída do usuário ou podem ser apagados por você.
5. Texto/toggle "Aparecendo como Especialista" na aba Estágio (`_estComoEsp`) existe só no aparelho (não grava nada); não alterei por ser visual — avalie se deve sair para não sugerir mistura.
6. Riscos anteriores seguem: administrador não confirmado, `wa`/`ultimoLogin` públicos, Storage, `x-signature`, revisão jurídica.

## 6. Comandos para o seu computador
```
cd testes/regras
npm install
npm test
```
Node 18+ e Java 11+. Esperado: nenhuma linha `FALHOU`; no Emulador a contagem esperada é **376** (1 cenário de data em vez de 4; simulador: 403). Depois `bash testes/rodar-todos.sh`. Se algo falhar, não publique e me envie as linhas `FALHOU`.

## 7. Reversão
Republicar `firestore-regras-v18.1.txt` (ou v18/v17/v16) no Console; restaurar `final-seguranca-lgpd-4.1.zip`/`-4.zip`. Cópias de segurança em `.backup-4.1/`. `lojas_autorizadas` só existe se você rodar o script com `--executar`.
