> **HISTÓRICO de etapa anterior** — números e arquivos podem estar defasados. Vale `RELATORIO-ETAPA-FINAL.md`.

# Relatório — correções controladas (12/10/2026)
Pacote: `final-seguranca-lgpd` (cópia de `final-seguranca`, que ficou **intacto**). Nada publicado, nenhum dado de produção alterado, nenhuma cobrança ativada.

## Arquivos alterados
| Arquivo | Mudança |
|---|---|
| `functions/index.js` | R1: `processarExclusao` agora apaga `usuarios_privado`, `negocios_privado`, `verificacoes`, `emergencias` da pessoa |
| `functions/assinatura.js` | P3: novo endpoint `registrarAceite` |
| `firestore-regras-v16.txt` | P3: regra `aceites_termos` (cliente não escreve) — **continua NÃO aprovada** |
| `app/teste-final.html` | P1 links; P2 tela de aceite p/ conta nova do Google; P3 chamada de registro (e-mail e Google) |
| `testes/regras/testar-regras.js` | +7 testes de `aceites_termos` (total 103 = 96 + 7) |
| Novos | `testes/teste-exclusao.js`, `testes/teste-aceite.js`, `migracao/limpar-emergencias-expiradas.js` (só lista por padrão), `docs/DECISOES-LGPD.md`, `docs/minutas/*` |

## O que foi feito
- **R1:** matriz do que apaga/mantém em `docs/DECISOES-LGPD.md`. Pagamentos, assinaturas, bloqueio de recadastro, pedido de exclusão, aceite e dados de terceiros são **mantidos**.
- **P1:** “Termos de Uso” e “Política de Privacidade” (PT e EN, cadastro e rodapés) abrem os textos existentes sem marcar o aceite e sem apagar campos.
- **P2:** conta **nova** pelo Google vê tela de aceite antes de entrar; recusar apaga a conta recém-criada. Quem já tem conta, login, recuperação de senha e sessões não mudam.
- **P3:** aceite gravado só pelo servidor (uid do token, data/hora do servidor, versões 1.1/1.1, histórico). Ciência da Política ≠ consentimento específico (mantidos separados).
- **LGPD:** minutas (com **[A CONFIRMAR]**), divergência dos 90 dias registrada com proposta, OpenStreetMap/Nominatim, cookies/análise conferidos no código.

## Testes
**Executados (Node + Chromium reais, com Firebase falso):**
teste-app 43/43 · teste-acesso 25/25 · teste-servidor-simulado (14 chamadas falsas MP) OK · teste-botao-ja-assinei 5/5 · teste-migracao 8/8 · teste-beneficios 5/5 · **teste-exclusao** OK (11 apagados, 12 mantidos) · **teste-aceite** 15/15 (8 servidor + 7 telas no Chromium) · análise de sintaxe dos 22 scripts do app e de todos os .js · 0 ocorrências de `mpago.la`.
**Simulados:** tudo acima usa Firebase/Mercado Pago falsos.
**NÃO executados / pendentes:**
- **Regras Firestore (103 testes, incl. os 96 anteriores): PENDENTE** — Emulador indisponível aqui. Regras v16 seguem **não aprovadas**.
- Teste de “usuário Google já existente não vê a tela de aceite”: conferido por leitura do código (a tela só abre com `isNewUser`), **não** executado.
- Nada testado com Firebase real, Google real, celular real ou Mercado Pago real.

## Riscos
1. **Portão do Google é do app**, não do servidor; quem burlar fica sem registro em `aceites_termos` (detectável).
2. **Recusa apaga a conta:** depende de login recente (normal logo após o Google); se falhar, apenas sai da conta (a conta pode ficar sem aceite).
3. Exclusão não cobre cópias do nome em conversas/avaliações de terceiros.
4. `emergencias` seguem sem limpeza automática (decisão pendente).
5. Textos **já publicados** no app trazem `suporte@frilaone.com.br` (como DPO) e WhatsApp `(31) 98229-9024` — não confirmados por mim.
6. O aceite só funciona após publicar `registrarAceite` + regras; antes disso o app tenta de novo a cada acesso, sem travar.

## Pendências suas
Dados do controlador; e-mail/WhatsApp oficiais; prazos (pagamentos, aceites, emergências); idade mínima; reembolso; bases legais; revisão jurídica das minutas; executar as regras no Emulador; publicar funções/regras (nesta ordem: funções → regras); decidir reaceite ao mudar versão.

## Como desfazer
Voltar ao pacote `final-seguranca` (intacto). Nada foi escrito em produção.
