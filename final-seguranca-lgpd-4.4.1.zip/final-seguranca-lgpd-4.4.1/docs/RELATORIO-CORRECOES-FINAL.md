> **HISTÓRICO de etapa anterior** — números e arquivos podem estar defasados. Vale `RELATORIO-ETAPA-FINAL.md`.

# RELATORIO-CORRECOES-FINAL — FrilaOne (12/10/2026)
Pacote: `final-seguranca-lgpd-3.zip`, a partir de `final-seguranca-lgpd-2.zip` (preservado, inalterado). **Nada foi publicado, nenhum dado de produção foi tocado, nenhuma cobrança foi ativada.**

## Veredito (sem exagero)
**NÃO está pronto para produção.** Corrigi o que o código permite e testei o que foi possível, mas **as regras v17 não foram executadas no Emulador oficial** (o ambiente bloqueia npm e o download do Emulador) e algumas proteções só fecham com o Modo Servidor ligado (ver “Riscos que permanecem”). Resultado das regras: **190/190 no avaliador local SIMULADO** — não é aprovação.

## 1. Problemas encontrados e correções
| # | Problema (evidência) | Correção | Teste |
|---|---|---|---|
| 1 | **Admin por e-mail sem verificação**: qualquer pessoa que cadastrasse `frilaoneapp@gmail.com` sem verificar lia selfies/CPF/denúncias (regra v16 `ehDono`) | v17: e-mail do dono só vale com `email_verified == true`; custom claim `admin` continua (script `definir-admin.js`) | 12 testes de regras (simulado) |
| 2 | **Selo de profissional auto-declarado**: quem escrevia `cadMaster` no próprio perfil lia todos os pedidos de agendamento abertos (dado de saúde em `descricao`) e podia aceitar | v17: só `profissionais_aprovados/{uid}` (cliente não escreve). Script `conceder-profissional.js`; app mostra “cadastro em análise” | 17 testes de regras + 1 de tela |
| 3 | **Plano pago / nota própria graváveis pelo cliente** quando as chaves estão desligadas | v17: sempre protegidos (o app nunca grava isso). `trial_*`, `verificado`, `master_ativo`: continuam sob a chave `protegerCampos` (o app antigo grava) — ver “Riscos” | 15 testes (10 com chaves ligadas + 5 desligadas) |
| 4 | **CPF/contato de emergência gravável no perfil público** (qualquer logado lê) | v17: só é permitido apagar; perfil legado continua atualizando outros campos | 10 testes |
| 5 | **Loja**: qualquer um criava loja com id alheio (“ocupar” `neg_X`) e o dono podia trocar `uid` | v17: id = `neg_`+uid; `uid` imutável | 7 testes | **Pedido de exclusão forjável** (cliente se declarava “concluída”; sem campos limitados) e **sem nova tentativa** após erro | v17: cliente só grava `pendente` com campos fixos; função refaz ao regravar (etapa anterior) | 7 testes + teste-exclusao |
| 7 | **Emergências** aceitavam campos/tipos livres | v17: campos e `tipo` fixos | 7 testes |
| 8 | **Assinatura**: clique duplo criava 2 assinaturas; link antigo autorizado depois ficava cobrando sem acompanhamento; “Já assinei” sem limite | link pendente reaproveitado (30 min), anteriores cancelados no MP, assinatura órfã cancelada no aviso, chave de idempotência por plano/5 min, limite de 1 consulta/15 s | 10 testes |
| 9 | **Acesso manual**: só dependia de você conferir o pagamento | agora consulta o MP (aprovado; valor se informado), impede o mesmo pagamento em 2 contas, idempotente | 8 testes |
| 10 | Denúncia: teste antigo usava payload que o app não envia | teste corrigido ao payload real (evidência: app `denuncianteUid…`) | — |
| 11 | Exclusão não removia `profissionais_aprovados` | incluído | teste-exclusao |

Mudanças deliberadas nos testes antigos (não para “fazê-los passar”): dono com `email_verified:true`; seed `profissionais_aprovados/B` para o profissional B; teste “[admin] PENDENTE … permite” virou “bloqueia”; payload de denúncia. Nenhum teste foi removido. Total de testes de regras: **103 originais + 87 novos = 190**.

## 2. Arquivos alterados e motivo
`firestore-regras-v17.txt` (novo; v16 preservado) · `functions/index.js` (exclusão: apaga selo de profissional) · `functions/assinatura.js` (duplicidade, órfã, limite) · `app/teste-final.html` (aviso “em análise”) · `migracao/conceder-acesso-manual.js` (verificação MP) · `migracao/limpar-campos-antigos.js` (texto) · **novos:** `migracao/conceder-profissional.js`, `verificar-prontidao.js`, `ligar-chaves-seguranca.js` · `testes/regras/{testar-regras.js, firebase.json, package.json, EXECUTAR-NO-COMPUTADOR.md, executar-simulado.js, avaliador-local/*}` · `testes/{teste-assinatura-duplicidade,teste-scripts}.js`, `rodar-todos.sh`; atualizados `teste-aceite/exclusao/beneficios.js` · `docs/{ATIVACAO-SEGURA,DECISOES-LGPD,RELATORIO-CORRECOES-FINAL}.md`, minuta da Política, `functions/LEIA-ME-SERVIDOR.md`.

## 3. Resultado real dos testes
**Executados e aprovados (Node + Chromium reais; Firebase e Mercado Pago simulados):** teste-app 43/43 · teste-acesso 25/25 · servidor simulado (14 chamadas falsas) · botão “Já assinei” 5/5 · assinatura-duplicidade 10/10 · migração 8/8 · benefícios 5/5 · exclusão · aceite 23/23 (inclui login Google novo/existente, recusa com falha, falha temporária, “em análise”) · emergências 4/4 · scripts 12/12 · sintaxe dos 22 scripts do app e de todos os .js · carga do app sem erro de página · 0 `mpago.la` · preços oficiais presentes (14,90 / 34,90 / 79,90).
**Simulados:** 190/190 regras no avaliador local (não é Emulador). Teste de “mutação”: as regras v16 falham 26 dos testes novos, como deveriam.
**Falhos:** nenhum no final (durante o trabalho: 1 teste de denúncia com payload errado — corrigido; 4 testes antigos ajustados por mudança deliberada).
**NÃO executados:** regras no Emulador oficial; qualquer coisa com Firebase, Google, celular ou Mercado Pago reais (incl. sandbox do MP); `firebase deploy`.

## 4. Comandos para reproduzir
`bash testes/rodar-todos.sh` (tudo que não precisa de Emulador, inclui o simulado). Emulador oficial: `cd testes/regras && npm install && npm test` (esperado `190/190`). Detalhes: `testes/regras/EXECUTAR-NO-COMPUTADOR.md`.

## 5. Reversão
Pacote anterior `final-seguranca-lgpd-2.zip` (intacto). Em produção, por componente: regras → republicar `firestore-regras-v16.txt`; chaves → `ligar-chaves-seguranca.js --desligar --executar`; app e funções → redeploy da versão anterior. Nada foi publicado, então nada precisa ser revertido agora.

## 6. Riscos que permanecem
1. **Regras v17 não aprovadas** até `npm test` passar no Emulador (crítico para publicar).
2. **Modo antigo do app** (`_ASSINATURA_ATIVA=false`): o app grava `trial_fim`, `verificado` e `master_ativo` no próprio perfil; enquanto estiver assim, qualquer usuário pode se dar teste, selo ou Master. Fecha ao seguir `docs/ATIVACAO-SEGURA.md` (funções + app em Modo Servidor + chaves). **Crítico até lá.**
3. O selo “verificado” confere só formato do CPF e presença de selfie (não consulta Receita nem compara rosto).
4. `tipo` da conta (define o plano) continua escolhido pelo usuário.
5. `usuarios` segue legível por qualquer logado (e-mail, WhatsApp…); CPF legado fica visível até rodar a migração.
6. Firebase Storage: SDK carregado e sem uso; confirmar no Console que está desativado/nega tudo.
7. Retenção de emergências e demais prazos: decisões suas/jurídicas (`DECISOES-LGPD.md`).
8. Avaliador local não reproduz 100% o Emulador (ex.: análise estática de consultas `list`).

## 7. Pendências que dependem de você
UID/e-mail verificado da conta administradora · rodar `npm test` no seu computador · aprovar profissionais existentes · credenciais do Mercado Pago (teste → produção) e segredos · decisões jurídicas/empresariais (controlador, e-mail do encarregado, WhatsApp, idade mínima, retenção, reembolso) · confirmar Storage no Console.

## 8. Passos para publicação segura
Em `docs/ATIVACAO-SEGURA.md` (11 passos, com reversão em cada etapa).
