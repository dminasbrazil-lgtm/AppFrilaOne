# Relatório 4.4 — gratuidade permanente das duas lojas antigas

**Nada foi publicado, migrado, cobrado ou enviado ao GitHub. NÃO está pronto para produção** (regras ainda não passaram no Emulador oficial).

## 1. Identificação das lojas — NÃO foi possível por código
Não há UID, `negId` nem lista das lojas em nenhum arquivo do pacote. Pela vitrine (sua captura) as lojas são **"Tênis Life"** e **"Loja FrilaOne"**, mas **nome não é identificação segura** (qualquer usuário pode cadastrar uma loja com esse nome) e `criado` é gravado pelo cliente. Por isso **nenhum UID foi inventado** e a gratuidade **não** depende de nome, data ou plano. Quem identifica é você, com dados reais:
`node migracao/decidir-loja.js --listar` (somente leitura) → anote o `negId` (neg_…) das duas lojas, conferindo nome, dono e se há outra loja com nome parecido. Também não se presume que estejam aprovadas.

## 2. O que foi implementado
- **`lojas_gratuitas/{uid}`** (nova, regras **v18.4**): leitura só do titular/administrador; **escrita proibida pelo cliente** (nem o administrador pelo cliente). Só o Admin SDK grava.
- **`migracao/marcar-loja-gratuita.js`**: recebe os `negId` que você confirmar; simulação por padrão (mostra nome/situação); `--executar` exige `--confirmo-que-sao-estas-lojas`; confere que a loja existe e `uid` = id; **teto de 2 lojas gratuitas** (`--permitir-mais` só se mudar a decisão comercial); `--revogar` desfaz; não altera os dados da loja (só grava a gratuidade e, se já aprovada, recalcula `publicaAte`).
- **`functions/loja-lib.js`**: `publicaAte` = `0` se não aprovada; se aprovada e gratuita → sem fim; senão `max(30/11/2026, pago até)`. Gratuidade só vale se o registro tiver o mesmo `negId`, `permanente:true` e não revogado. Auditoria (`lojas_decisoes`) registra `gratuita`.
- **`migracao/decidir-loja.js --aprovar-legado`** agora **exige `--negId=…`** (antes aprovava todas as lojas sem status — contrariava "não presumir que toda loja antiga está aprovada"). Teste 11 do `teste-aprovacao-loja.js` atualizado por isso (a intenção — legado só atinge lojas sem status — foi mantida; acrescentou-se: sem lista, nada é aprovado; loja não listada não é aprovada).
- **App (`teste-final.html`) não foi alterado.** Sem mudança visual.

## 3. Regras de negócio resultantes
| Situação | Resultado |
|---|---|
| Loja antiga marcada + aprovada | Visível sempre, sem pagamento |
| Loja antiga marcada, não aprovada/recusada/pendência | Não aparece (gratuidade ≠ aprovação) |
| Loja nova | Nasce pendente; precisa de aprovação; sem gratuidade; após 30/11/2026 só com pagamento registrado |
| Loja nova com nome "Tênis Life" | Nenhum efeito |
| Pagamento registrado, mas não aprovada | Não aparece (cobrança ≠ aprovação) |

## 4. Testes realmente executados (todos SIMULADOS; nenhum no Emulador oficial)
- `bash testes/rodar-todos.sh`: 16 arquivos de teste passaram, incluindo o novo **`teste-loja-gratuita.js` (11 OK)** que cobre os 4 pontos pedidos: (1) duas lojas antigas gratuitas e visíveis hoje, após 01/12/2026 e em 2035, dados preservados, qualquer ordem de operação; (2) loja nova pendente, não abre, não se auto-aprova; (3) loja nova sem gratuidade (mesmo nome, registro adulterado/outro negId/revogado, teto de 2, usuário/admin pelo cliente não escrevem); (4) matriz aprovação × cobrança × gratuidade.
- Regras no avaliador local: **440/440** (4 testes novos `[v18.4 GRATUITA]`). Observação honesta: esses 4 também passariam na v18.3 (coleção sem regra = negada por padrão); a v18.4 torna a negação explícita e documentada.
- Esperado no Emulador oficial: **407** (440 − 33, porque roda 1 cenário de data em vez de 4). **Não executado** aqui.

## 5. O que você precisa fazer (nesta ordem, antes de publicar app/regras)
1. `cd migracao && node decidir-loja.js --listar` → confirme os dois `negId`.
2. `node marcar-loja-gratuita.js --negId=neg_X,neg_Y` (simulação) → confira nomes → repita com `--executar --confirmo-que-sao-estas-lojas`.
3. Aprove as duas (se já estiverem corretas): `node decidir-loja.js --aprovar-legado --negId=neg_X,neg_Y` (simulação, depois `--executar`). Se alguma não deve ficar no ar, não aprove.
4. Só então publicar funções → app → regras v18.4. Rodar `cd testes/regras && npm install && npm test` (Node 18+, Java 11+) antes.
Reversão: `marcar-loja-gratuita.js --revogar …` (volta à regra normal) e republicar regras v18.3.

## 6. Pendências / limites
Emulador oficial não executado; UID/e-mail verificado do administrador não confirmado; ainda não há cobrança automática da Minha Loja (pagamento manual via `autorizar-loja.js`); não há painel administrativo; editar loja aprovada não reabre revisão; o teto de 2 é uma trava do script, não das regras (as regras bloqueiam qualquer escrita pelo cliente).
