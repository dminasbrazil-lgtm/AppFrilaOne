# FrilaOne — pacote `final-seguranca-lgpd-4`
**Nada foi publicado, migrado, cobrado ou enviado ao GitHub.** Preços: Golden R$ 14,90 · Master R$ 34,90 · Diamond R$ 79,90 · Pessoa Física grátis. Campanha grátis até 30/11/2026; teste de 7 dias para quem entra a partir de 01/12/2026. `_ASSINATURA_ATIVA` continua `false`.

**Comece por `docs/RELATORIO-ETAPA-FINAL.md`** (problemas, arquivos, testes reais × simulados, riscos, comandos, reversão, pendências).
**Status: NÃO pronto para produção.** As regras v18.4 ainda não passaram no Emulador oficial.

- Regras atuais: `firestore-regras-v18.4.txt` (v18.3, v18.2, v18.1, v18, v17 e v16 mantidas para reversão).
- Ativação: `docs/ATIVACAO-SEGURA.md` · Servidor: `functions/LEIA-ME-SERVIDOR.md` · Emulador: `testes/regras/EXECUTAR-NO-COMPUTADOR.md` · LGPD: `docs/DECISOES-LGPD.md`.
- **Lojas gratuitas permanentes (4.4):** `docs/RELATORIO-LOJAS-GRATUITAS-4.4.md` — ANTES de publicar app/regras, rode `node migracao/decidir-loja.js --listar` e siga o passo a passo.
- **Correção do Emulador (4.4.1):** `docs/RELATORIO-CORRECAO-EMULADOR-4.4.1.md`.
- Testes locais: `bash testes/rodar-todos.sh`.
- Os demais relatórios em `docs/` são **históricos** de etapas anteriores (números e nomes de arquivos podem estar defasados).
