# RELATÓRIO — ETAPA FINAL (pacote `final-seguranca-lgpd-4`)

**Conclusão honesta: NÃO está pronto para produção.** O trabalho técnico local foi concluído, mas as regras v18 **nunca rodaram no Emulador oficial do Firebase** (o ambiente não o baixa). Nada foi publicado no Firebase, nenhum dado real foi alterado, nenhuma migração foi executada, nenhuma cobrança foi ativada, nada foi enviado ao GitHub. `_ASSINATURA_ATIVA` continua `false`. O ZIP `final-seguranca-lgpd-3.zip` foi preservado.

---
## 1. Problemas de raiz encontrados
1. **Proteções dependiam de chave manual.** `trial_*`, `verificado:true` e `master_ativo:true` só eram protegidos se alguém criasse `config/seguranca.protegerCampos`. Até lá, o usuário podia se dar teste, selo e Master. → v18: proteção **sempre ligada** nas regras; a chave `protegerCampos` foi removida.
2. **O app gravava esses campos no próprio perfil** (`_ativarTrial`, `salvarPerfil`, selo). Isso impedia ligar a proteção. → app não grava mais; trial/selo/Master passam pelo servidor (`statusAcesso`, `confirmarVerificacao`, `definirModoMaster`).
3. **Contorno por `tipo`.** A exigência de acesso olhava só `tipo`; trocar para "pessoa física" escapava. → `precisaPlano:true` permanente gravado pelo servidor; conta de plano = `precisaPlano` OU `tipo` de plano OU `master_ativo`.
4. **Exigência de acesso dependia de chave manual** (`exigirAcesso`). → liga sozinha por data (01/12/2026 00:00 Brasília = `1796094000000`), com chave opcional só para antecipar.
5. **Carência divergente** entre regras e `calcularAcesso`. → servidor grava `acessoRegraAte` (com 3 dias de carência) e `acessoPlano`; as regras leem esses campos.
6. **Expressão `request.time.toMillis()`** não confirmável localmente. Mantida (é válida na linguagem de regras, `Timestamp.toMillis()`), mas **não confirmada no Emulador** → pendência nº 1.
7. **E-mails no perfil público** (`usuarios.email`/`emailContato`). → movidos para `usuarios_privado` (cadastro, Google, perfil, login); migração copia/limpa sem apagar sem equivalente.
8. **Selos antigos** sem verificação válida. → `revisar-selos.js` (simulação por padrão, com backup).
9. **Cobertura de testes oficiais insuficiente** (poucas operações por coleção). → bloco "v18 COBERTURA": get/list/create/update/delete de todas as coleções.

## 2. Arquivos modificados e justificativa
| Arquivo | Mudança / motivo |
|---|---|
| `firestore-regras-v18.txt` (novo) | Regras v18 (a partir da v17): proteção permanente, `cobrancaAtiva` por data, `contaDePlano`, `acessoServidor/Ok/Disponivel/Loja`, `usuarios_privado` aceita `email`/`emailContato`. v17/v16 mantidas p/ reversão. |
| `app/teste-final.html` | Sem gravação de `trial_*`, `verificado:true`, `master_ativo:true` e e-mail no perfil público; e-mails vão ao doc privado; chamadas ao servidor no modo servidor. Sintaxe OK (22 scripts). |
| `functions/assinatura-lib.js` | `camposDerivados` → `acessoValidoAte/acessoRegraAte/acessoPlano/...`. |
| `functions/assinatura.js` | `atualizarAcesso` grava derivados + `precisaPlano` permanente; `criarAssinatura` marca `precisaPlano`. |
| `testes/regras/testar-regras.js` | 359 testes (v18). **Mudanças de expectativa deliberadas (3 testes), com motivo:** "trial_fim", "master_ativo:true" com chave desligada e a "limitação conhecida trial_fim" passaram de *permite* → *bloqueia*, pois a proteção agora é permanente (não é adaptação para passar: o comportamento exigido pelo pedido mudou). Novos testes adicionados, nenhum outro removido/alterado. |
| `testes/regras/avaliador-local/*`, `executar-simulado.js`, `relatorio-cobertura.js`, `firebase.json`, `package.json` | Simulador com `timestamp`, relógio fixo, cobertura; aponta para v18. |
| `testes/teste-acesso-regras.js`, `teste-regressao-app.js`, `teste-app-sem-privilegios.js` (novos) | Regras × estado do servidor; app no Chromium com Firestore/servidor falsos; varredura estática de privilégios. |
| `testes/teste-acesso.js`, `teste-app.js`, `teste-migracao.js`, `teste-scripts.js`, `rodar-todos.sh` | Novos casos; uma asserção estática de `teste-app.js` atualizada porque o código de `master_ativo` mudou de propósito (agora coberta por comportamento). |
| `migracao/migrar-dados-privados.js`, `limpar-campos-antigos.js` | Incluem `email`/`emailContato` (só copiam o que falta; só apagam se o privado for igual). |
| `migracao/ligar-chaves-seguranca.js`, `verificar-prontidao.js` | Só `exigirAcesso`; contadores novos (somente leitura). |
| `migracao/revisar-selos.js` (novo) | Revisão de selos; simulação padrão; `--executar --confirmo-que-revisei` grava backup JSON antes. |
| `docs/*`, `functions/LEIA-ME-SERVIDOR.md`, `testes/regras/EXECUTAR-NO-COMPUTADOR.md` | Atualizados para v18; relatórios antigos marcados como históricos. |

### Mapa de `tipo`, `trial_*`, `verificado`, `master_ativo` no app
- `tipo`: escolhido pelo usuário (gravação em `usuarios` permitida, pública, usada em busca/UI); **não** define mais acesso sozinho.
- `trial_*`: concedido pelo servidor (`statusAcesso`); no app só local (cache). Regras bloqueiam gravação.
- `verificado`: só `confirmarVerificacao` (servidor) grava `true`; regras bloqueiam o cliente.
- `master_ativo`: cliente só grava `false`; `true` via `definirModoMaster` no servidor.
- Plano pago / nota própria: bloqueados nas regras (já na v17).

### Campos de `usuarios`
- **Público (necessário):** nome, foto, bio, cidade, bairro, wa, tipo/tipo_label/tipo_icon, xp/nível, bloqueados, cadMaster/cadParceiro, disponível, ultimoLogin, etc.
- **Privado (`usuarios_privado`):** cpf, contatoEmergencia, email, emailContato. Lojas: `negocios_privado`. Selfie/CPF de verificação: `verificacoes`.

## 3. Testes efetivamente executados (esta sessão, `bash testes/rodar-todos.sh`: todos passaram)
| Teste | Resultado | Natureza |
|---|---|---|
| `teste-app.js` | 43/43 | local (navegador/Firebase simulados) |
| `teste-app-sem-privilegios.js` | 7/7 | varredura estática |
| `teste-acesso.js` | 28/28 | local (servidor simulado) |
| `teste-acesso-regras.js` | 53/53 | simulado (regras no avaliador próprio) |
| `teste-regressao-app.js` | 22/22 | Chromium real, Firestore/servidor **falsos**; falha 10 testes contra o app antigo (prova que discrimina) |
| `teste-servidor-simulado`, `teste-botao-ja-assinei`, `teste-assinatura-duplicidade` (10), `teste-beneficios` (5), `teste-exclusao`, `teste-aceite` (23), `teste-emergencias` (4) | passaram | locais/simulados |
| `teste-migracao.js` | 9/9 | banco falso |
| `teste-scripts.js` | 13/13 | scripts com banco falso |
| **Regras v18 — avaliador LOCAL** | **359/359** | **SIMULADO — não é aprovação** |
| **Regras v18 — Emulador OFICIAL** | **NÃO EXECUTADO** | npm/Emulador inacessíveis aqui |
| Firebase real, Mercado Pago real, `x-signature` real, celular | **NÃO EXECUTADO** | |

**Cobertura simulada** (`node executar-simulado.js --cobertura`): cada coleção exercitada em get/list/create/update/delete com casos permitidos e negados (tabela completa pela execução). Coleções com células "·" (nunca exercitadas) são lacunas conhecidas, ex.: criação em `estagiarios`, `get` em `cupons_usados`.

### Matriz de regressão (fluxos pedidos)
| Fluxo | Cobertura real |
|---|---|
| Cadastro e login (e-mail) | Chromium (fake) — OK |
| Login Google + aceite dos termos | testes de aceite (função/local); UI Google real não testada |
| Recuperação de senha | Chromium (fake) — OK |
| Perfil e dados privados | Chromium (fake) + regras simuladas — OK |
| Busca de profissionais e lojas | só regras simuladas (leitura); UI não testada |
| Vagas, disponibilidade | regras simuladas + data; UI não testada |
| Conversas e agendamentos | só regras simuladas; UI não testada |
| Exclusão de conta e nova tentativa | `teste-exclusao` (local) |
| Planos, teste grátis, assinatura | `teste-acesso`, `teste-servidor-simulado`, Chromium nos 2 modos |
| "Já assinei" | `teste-botao-ja-assinei` (local) |
Nenhum fluxo foi testado com Firebase ou Mercado Pago reais.

## 4. Riscos críticos ainda existentes
1. **Regras v18 sem aprovação oficial** (inclui `toMillis()`). Não publicar antes.
2. **Ordem de publicação:** app antigo em cache falha ao salvar perfil sob v18 → publicar app **antes** das regras.
3. **Modo Servidor precisa estar no ar antes de 01/12/2026**, senão contas de plano perdem acesso por data.
4. **Admin não confirmado:** UID e e-mail verificado de `frilaoneapp@gmail.com`.
5. **Loja não exige o plano específico** (só acesso válido). Variante estrita comentada nas regras.
6. `usuarios` segue legível por qualquer logado (`wa`, `ultimoLogin` públicos) — decisão de produto/LGPD.
7. Selo = CPF com formato válido + selfie presente (não prova identidade). Cota semanal de vagas só no cliente. Contador `cliques` em perfil alheio é recusado (já era, falha silenciosa).
8. Regras do Storage: situação desconhecida. Formato real do `x-signature` do Mercado Pago não confirmado.
9. Contatos nos textos do app (`suporte@frilaone.com.br`, WhatsApp (31) 98229-9024) não confirmados; retenção de dados e revisão jurídica em aberto.

## 5. Comandos para rodar no seu computador
Requisitos: Node 18+, Java 11+.
```
cd testes/regras
npm install
npm test
```
Esperado: nenhuma linha `FALHOU`, saída 0. Depois, na raiz do pacote: `bash testes/rodar-todos.sh`. Se falhar, **não publique**; me envie as linhas `FALHOU`. Detalhes: `testes/regras/EXECUTAR-NO-COMPUTADOR.md`.

## 6. Reversão
- Regras: republicar `firestore-regras-v17.txt` (ou v16) no Console.
- App: republicar o `index.html` anterior (fora do pacote). Funções: `firebase functions:delete NOME`/redeploy anterior.
- Chave antecipada: `node migracao/ligar-chaves-seguranca.js --desligar --executar`.
- Pacote: restaurar `final-seguranca-lgpd-3.zip` (preservado).
- Scripts de `migracao/` só gravam com `--executar`; `revisar-selos.js` gera backup JSON antes. `limpar-campos-antigos.js` é irreversível: só após `migrar-dados-privados.js --verificar` sem divergência.

## 7. O que depende de você
1. Rodar `npm install && npm test` em `testes/regras` e enviar o resultado.
2. Confirmar UID e e-mail verificado do admin.
3. Credenciais de teste do Mercado Pago, segredos e plano Blaze.
4. Aprovar profissionais (conselho) e decidir sobre selos antigos.
5. Decisões: `wa`/`ultimoLogin` públicos, plano estrito de loja, retenção, contatos de suporte, revisão jurídica.
