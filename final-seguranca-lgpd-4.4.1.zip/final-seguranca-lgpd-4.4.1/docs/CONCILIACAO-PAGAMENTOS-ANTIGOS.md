> **HISTÓRICO de etapa anterior** — números e arquivos podem estar defasados. Vale `RELATORIO-ETAPA-FINAL.md`.

# Pagamentos feitos pelos links antigos do Mercado Pago (`mpago.la`) — como identificar e atender quem já pagou

Os links foram **retirados do app**, mas o dinheiro que entrou por eles continua no seu painel do Mercado Pago. Esses links **não avisam o servidor**, então quem pagou por eles não tem acesso registrado automaticamente. Nada foi apagado nem desativado no Mercado Pago (eu não tenho acesso a ele): **os links continuam existindo lá até você desativá-los**.

## O que cada link era (como estava no app antes desta entrega)
Um mesmo link aparecia em telas com preços diferentes. **Por isso o link sozinho não diz qual plano a pessoa comprou: confira o VALOR do pagamento no painel.**

| Link (final) | Onde aparecia / valor mostrado |
|---|---|
| `…/2y5shyg` | Vagas Brasil — R$ 4,99/mês (card já estava escondido: "desativado por enquanto") |
| `…/2KnHEaC` | Empresas & Negócios anual R$ 308,56; Minha Loja R$ 79,90/mês (tabela de planos) |
| `…/22Mdt2J` | Empresas R$ 29,90/mês; Empresa/Divulgar vagas R$ 14,90; Todas as áreas R$ 34,90 ("completo"); publicar vaga R$ 29,90; vaga "Essencial" R$ 19,90 |
| `…/2SyLYAg` | Prestador / Rede de Parceiros R$ 14,90; Vitrine R$ 14,90 |
| `…/22Yoi8c` | Todas as áreas (Master) R$ 34,90/mês |
| `…/1ciM5JS` | Empresa/Divulgar vagas R$ 14,90; Minha Loja R$ 149,90 por 6 meses; vaga "Premium" R$ 24,90 |
| WhatsApp (31) 98229-9024 | "Pulsar Pro" R$ 24,90/mês, combinado por conversa (sem link) |

## Procedimento (você faz; nada disso é automático)
1. No painel do Mercado Pago → **Atividade / Pagamentos**, exporte os pagamentos aprovados cujo valor seja um dos acima (principalmente 4,99 / 308,56 / 29,90 / 19,90 / 24,90 / 149,90 / 79,90 / 34,90 / 14,90).
2. Para cada pagamento, descubra **quem é a pessoa no app** (e-mail do pagador × e-mail da conta; se não bater, pergunte) e pegue o **UID** em Firebase Console → Authentication.
3. Copie `migracao/pagantes-antigos-modelo.json` para `pagantes.json` e preencha **uid, plano, data final (`ate`) e `idPagamentoMP`** (número do pagamento no painel). Sem o número do pagamento o script **recusa** a linha.
4. Rode primeiro em simulação: `node migracao/conceder-acesso-manual.js pagantes.json`. Confira. Só então `--executar`.
5. Valores que **não existem mais na tabela oficial** (4,99 / 19,90 / 24,90 / 29,90 / 149,90 / 308,56): decida caso a caso com o cliente (honrar o período já pago com o plano oficial equivalente, ou migrar para a tabela oficial). **Eu não decidi isso por você.**

## O que foi mantido de propósito (conciliação)
- Script `conceder-acesso-manual.js` (exige número do pagamento) e o campo `assinaturas/{uid}.manualAte/manualPlano/manualRefPagamento`.
- Função `sincronizarAssinatura`, coleção `pagamentos` (só leitura pelo dono e pelo administrador) e a coleção antiga `cupons_usados` (só administrador) — nenhum registro foi apagado.
- Campo `assinaturas/{uid}.codigoFim` (benefício por código já concedido) e o script `preservar-beneficios-codigos.js`.
- O botão **"Já assinei"** continua consultando o servidor (com o servidor ligado) — ele nunca libera acesso só porque a pessoa disse que pagou.

## Antes de desativar os links no Mercado Pago
Só desative depois de: (a) novo fluxo de cartão testado com a chave de TESTE e depois com um pagamento real seu; (b) lista de pagantes antigos tratada com o passo 4 acima.
