# RELATÓRIO — APROVAÇÃO ADMINISTRATIVA DE MINHA LOJA (`final-seguranca-lgpd-4.3`)

## Veredito
**O código está PREPARADO para a integração com o futuro painel. A aprovação administrativa NÃO está concluída de ponta a ponta para você usar sem ajuda técnica**, porque não existe painel: hoje o administrador só consegue aprovar/recusar pela linha de comando (`migracao/decidir-loja.js`, no computador, com credencial de administrador do Firebase) ou chamando a função `decidirLoja`. Isso funciona **em testes simulados** (banco falso + regras no avaliador local + função real com login falso), **não** no Firebase real nem no Emulador oficial. Por isso não declaro o fluxo concluído.
Nada foi publicado, migrado, cobrado nem enviado ao GitHub. Pacotes anteriores preservados. **Não está pronto para produção** (Emulador oficial não executado — o proxy deste ambiente bloqueia o download).

## 1. O que eu verifiquei antes de alterar
- `lojas_autorizadas/{uid}` (4.2) só controlava **quem podia criar** a loja depois de 01/12/2026 e abri-la. **Não era aprovação.** Não havia nenhum estado "pendente".
- O cadastro (`_salvarCadastroNegocio`) gravava a loja com `ativo:true`, mostrava "Negócio publicado! Já aparece na vitrine." e a vitrine listava `where ativo==true`. Ou seja, **toda loja era publicada automaticamente** ao cadastrar.
- O dono podia editar qualquer campo da própria loja; `ehDono()` (administrador) já existia nas regras (claim `admin` ou e-mail do dono verificado). Não existe tela de administração no app (e não criei nenhuma).
- O chat existente já permite ao administrador falar com o dono da loja (`abrirChatNeg`); não alterei o chat.

## 2. O que já funcionava / o que foi implementado agora / o que depende do painel
| Item | Situação |
|---|---|
| Autenticação e permissão de administrador (`ehDono`: claim `admin` OU e-mail do dono verificado) | **Já existia** — reutilizada nas regras e na função |
| Chat para pedir ajustes ao dono | **Já existia** — uso manual pelo administrador |
| Cadastro da loja com informações e produtos | **Já existia** — agora nasce **pendente** |
| Estado de aprovação (`pendente`/`aprovada`/`pendencia`/`recusada`), `publicaAte`, auditoria | **Implementado agora** (regras v18.3 + servidor) |
| Usuário não aprova a própria loja nem estende `publicaAte` | **Implementado agora** (regras; 43 testes simulados com a marca v18.3) |
| Função `decidirLoja` (só administrador; grava no servidor; log em `lojas_decisoes`) | **Implementada agora** (testada com login falso) |
| Script `decidir-loja.js` (listar/aprovar/recusar/pendência/legado; simulação por padrão) | **Implementado agora** — é o único caminho de uso real até existir painel |
| Vitrine só com lojas publicadas; abrir a loja só se publicada | **Implementado agora** (app + regras) |
| A partir de 01/12/2026 aprovação não substitui cobrança | **Implementado agora**: `publicaAte = max(30/11/2026, pago até)` |
| **Tela/painel do administrador** (lista de pendentes, ver dados, aprovar/recusar, escrever motivo) | **Depende do painel** — não criado |
| Aviso ao dono sobre pendência/recusa | Toast no login (texto simples) + chat manual; **sem notificação automática** |
| **Cobrança da Minha Loja** (como o dono paga e quem registra `lojas_autorizadas.ate`) | **Não existe** — hoje manual (`autorizar-loja.js`). Decisão sua |

## 3. Como funciona (resumo)
1. Dono cadastra → `negocios/neg_{uid}` com `aprovacaoStatus:'pendente'` (o app envia só isso; **nunca** envia `publicaAte`/aprovação). Não aparece na vitrine e `disponiveis` (loja aberta) recusa.
2. O administrador decide pela função/script (servidor). Gravados: `aprovacaoStatus`, `publicaAte`, `aprovacaoEm/Por/Motivo` + registro em `lojas_decisoes` (só o administrador lê).
3. Pendência/recusa exigem motivo; o dono vê o motivo no login (toast), corrige e salva → volta a `pendente` (regras só permitem esse reenvio vindo de `pendencia`/`recusada`).
4. `publicaAte` = aprovada ? `max(30/11/2026 23:59:59, lojas_autorizadas.ate)` : 0. Depois da campanha, sem pagamento a loja some e fecha sozinha (sem rotina agendada). Registrar pagamento recalcula (`autorizar-loja.js`).
5. Editar loja aprovada não pede nova aprovação (**risco aceito**, ver §5).

## 4. Contrato para o futuro painel (nada precisa mudar nas regras)
- **Listar pendentes:** consulta Firestore como administrador (`ehDono`): `negocios` onde `aprovacaoStatus == 'pendente'` (lojas antigas sem status não aparecem nessa consulta; use `decidir-loja.js --listar`). Dados privados da loja: `negocios_privado/{negId}` (administrador lê).
- **Decidir:** `POST https://southamerica-east1-frilaone-e6247.cloudfunctions.net/decidirLoja` com `Authorization: Bearer <idToken do administrador>` e corpo `{"negId":"neg_UID","decisao":"aprovar|recusar|pendencia|recalcular","motivo":"obrigatório em recusar/pendencia"}`. Respostas: 200 `{ok,status,publicaAte,...}`; 401 sem login; 403 `somente_administrador`; 400 `id_invalido|decisao_invalida|motivo_obrigatorio|loja_inconsistente`; 404 `loja_inexistente`.
- **Pedir ajustes:** decisão `pendencia` + motivo, e conversar pelo chat existente.
- **Auditoria:** `lojas_decisoes` (negId, decisão, motivo, porUid, em, publicaAte).

## 5. Riscos e limitações (reais)
1. **Nada disto rodou no Emulador oficial nem no Firebase real.** Os testes são simulados (avaliador próprio das regras; função real, mas com Auth e banco falsos). A função `decidirLoja` nunca foi publicada.
2. **Sem painel**, a aprovação exige computador + credencial de administrador do Firebase (`GOOGLE_APPLICATION_CREDENTIALS`). Dependendo disso, o critério "forma segura e funcional de o administrador aprovar" só vale para uso técnico.
3. **Lojas existentes** (sem status) deixam de aparecer na vitrine quando o app novo for ao ar, até rodar `decidir-loja.js --aprovar-legado --executar` (sua decisão; simulação por padrão).
4. **Leitura aberta:** `negocios` continua legível por qualquer logado; uma loja pendente pode ser lida por quem souber o id. A vitrine do app a esconde, mas isso não é barreira de segurança.
5. **Edição pós-aprovação** não reabre a análise: o dono pode trocar produtos/descrição depois de aprovado. Se quiser reaprovação a cada mudança, é decisão de produto (nova regra + painel).
6. **Cache antigo do app:** um app antigo grava loja sem `merge`, o que as regras recusam em loja aprovada (fecha, não abre). Publicar o app antes das regras.
7. **Cobrança da Minha Loja inexistente** (ver §2). Sem ela, após 30/11/2026 nenhuma loja aprovada continua publicada, a menos que você registre o pagamento à mão.
8. Texto do app alterado por necessidade (a mensagem antiga dizia "publicado, já aparece na vitrine" — passou a ser falsa): "Loja enviada para aprovação. Quando for aprovada, aparece na vitrine." e avisos de pendência/recusa. Layout, cores e telas não mudaram. Se quiser outro texto, é só pedir.
9. Mantidos riscos anteriores (administrador não confirmado, `wa` público, Storage, `x-signature`, revisão jurídica).

## 6. Arquivos alterados (em relação ao 4.2)
`firestore-regras-v18.3.txt` (novo; v18.2 mantida para reversão) · `functions/loja-lib.js`, `functions/loja.js` (novos), `functions/index.js` (exporta `decidirLoja`), `functions/assinatura-lib.js` (comentário) · `app/teste-final.html` (cadastro pendente + merge, sem campos de servidor, vitrine por `publicaAte`, heartbeat da loja só depois de a loja abrir, avisos) · `migracao/decidir-loja.js` (novo), `migracao/autorizar-loja.js` (pagamento recalcula `publicaAte`) · `testes/teste-aprovacao-loja.js` (novo), `testes/regras/testar-regras.js`, `testes/teste-regressao-app.js`, `testes/teste-app-sem-privilegios.js`, `testes/teste-acesso-regras.js`, `testes/teste-app.js`, `testes/rodar-todos.sh` · docs (`ATIVACAO-SEGURA`, `LEIA-ME-PRIMEIRO`, `EXECUTAR-NO-COMPUTADOR`). Backups em `.backup-4.2/`.

### Testes que mudaram de expectativa (com justificativa)
- Regras: "criar loja" por plano/autorização (`T8`, `T9`, `acesso vencido`, `Master`, `tipo negocio`, datas pós-01/12) passou de *bloqueia* para *permite* **o cadastro pendente**, porque a decisão 4.3 move o controle para a **publicação** (aprovação + pagamento). Em compensação, abrir a loja e aparecer na vitrine exigem publicação (testes novos, inclusive por data).
- `teste-app.js`: duas asserções amarradas ao código antigo (`set(_negSemCpf(...))` sem merge; `_negSemCpf` só tirava CPF) foram atualizadas porque o código mudou de propósito (merge e remoção dos campos de servidor); o comportamento está coberto por testes de comportamento novos no Chromium.
- `teste-acesso-regras.js`: o cenário "loja" agora confere cadastro pendente permitido, loja não abre e o dono não se auto-aprova.

## 7. Testes realmente executados (`bash testes/rodar-todos.sh`: todos passaram)
| Teste | Resultado | Natureza |
|---|---|---|
| Regras v18.3, avaliador **SIMULADO** | **436/436** (24 casos falham contra a v18.2 — discriminam) | simulado |
| `teste-aprovacao-loja.js` (cadastro → decisão pela função real → regras/vitrine por data → pagamento → recusa) | **11/11** | simulado |
| Regressão do app (Chromium, Firestore falso) | **34/34** (6 falham no app 4.2 — discriminam) | local |
| App sem privilégios (estático) | 12/12 | estático |
| Acesso×regras | 53/53 | simulado |
| Scripts / app / demais suítes | 15/15 · 43/43 · demais passaram | local |
| Sintaxe (22 scripts do app, functions, migração, testes) | OK | — |
| **Emulador oficial, Firebase real, função publicada, painel, celular** | **NÃO EXECUTADO** | — |

## 8. Comandos para o seu computador
```
cd testes/regras
npm install
npm test
```
Node 18+ e Java 11+. Esperado: nenhuma linha `FALHOU`; no Emulador a contagem esperada é 403 (simulador: 436). Depois `bash testes/rodar-todos.sh`. Para aprovar uma loja hoje (depois de publicadas as funções e com credencial de administrador): `node migracao/decidir-loja.js --listar`, depois `--negId=neg_UID --aprovar` (simulação) e `--executar`.

## 9. Reversão
Republicar `firestore-regras-v18.2.txt` (ou anteriores), o app anterior (`.backup-4.2/teste-final.html`) e, se publicada, apagar a função `decidirLoja` (`firebase functions:delete decidirLoja`). Os campos `aprovacao*`/`publicaAte` ficam nos documentos e são ignorados pelo app antigo (que voltaria a listar por `ativo==true`). `lojas_decisoes` pode ser apagada pelo Console.

## 10. O que depende de você
1. Rodar o Emulador oficial (comandos acima).
2. Decidir como a Minha Loja será cobrada e quem registra o pagamento.
3. Decidir se lojas existentes são aprovadas como legado e se editar loja aprovada exige nova aprovação.
4. Construir/contratar o painel administrativo (contrato no §4) e confirmar a conta de administrador (UID, e-mail verificado).
5. Aprovar os textos de aviso da loja.
