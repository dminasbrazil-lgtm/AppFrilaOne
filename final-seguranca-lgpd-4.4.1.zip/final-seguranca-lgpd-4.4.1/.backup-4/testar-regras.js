// Testes das regras v14 no Emulador (NÃO toca na produção). Rodar: npm install && npm test
const { initializeTestEnvironment, assertSucceeds, assertFails } = require('@firebase/rules-unit-testing');
const fs = require('fs');
const { doc, setDoc, getDoc, updateDoc, deleteDoc, addDoc, collection, writeBatch, increment, arrayUnion, getDocs, query, where, deleteField } = require('firebase/firestore');
let env; const res = [];
async function t(nome, esperado, fn) {            // esperado: 'permite' | 'bloqueia'
  let ok;
  try { await (esperado === 'permite' ? assertSucceeds(fn()) : assertFails(fn())); ok = true; } catch (e) { ok = false; console.error('   detalhe:', e.message.split('\n')[0]); }
  res.push(ok); console.log((ok ? 'OK    ' : 'FALHOU') + ' | esperado: ' + esperado + ' | ' + nome);
}
(async () => {
  env = await initializeTestEnvironment({ projectId: 'frilaone-e6247', firestore: { rules: fs.readFileSync('../../firestore-regras-v18.txt', 'utf8') } });
  const A = env.authenticatedContext('A').firestore(), B = env.authenticatedContext('B').firestore(), C = env.authenticatedContext('C').firestore();
  const dono = env.authenticatedContext('D', { email: 'frilaoneapp@gmail.com', email_verified: true }).firestore(), anon = env.unauthenticatedContext().firestore();
  await env.withSecurityRulesDisabled(async ctx => {
    const d = ctx.firestore();
    await setDoc(doc(d, 'usuarios/A'), { nome: 'A', avaliacaoSoma: 0, avaliacaoCount: 0 });
    await setDoc(doc(d, 'usuarios/B'), { nome: 'B', cadMaster: { nome: 'B' }, cpf: '000' });
    await setDoc(doc(d, 'usuarios/C'), { nome: 'C' });
    // v17: B é profissional Acadêmico APROVADO (antes bastava ter 'cadMaster' no perfil)
    await setDoc(doc(d, 'profissionais_aprovados/B'), { ativo: true });
    await setDoc(doc(d, 'conversas/A_B'), { participantes: ['A', 'B'] });
    await setDoc(doc(d, 'conversas/A_B/mensagens/m1'), { de: 'A', texto: 'oi' });
    await setDoc(doc(d, 'vagas/v1'), { uid: 'A', titulo: 'x' });
    await setDoc(doc(d, 'negocios/neg_A'), { uid: 'A', avaliacaoSoma: 0, avaliacaoCount: 0 });
    await setDoc(doc(d, 'agendamentos/ag1'), { clienteUid: 'A', status: 'aberto', profissionalUid: null, recusadoPor: [], tipoProfissional: 'x' });
    await setDoc(doc(d, 'verificacoes/A'), { cpf: '1', cpfValido: true, selfie: 's', dataEnvio: 1 });
    await setDoc(doc(d, 'assinaturas/A'), { status: 'ativa' });
    await setDoc(doc(d, 'denuncias/d1'), { de: 'A' });
    await setDoc(doc(d, 'emergencias/e1'), { uid: 'A' });
    await setDoc(doc(d, 'usuarios_privado/A'), { cpf: '11144477735', contatoEmergencia: '31999990000' });
    await setDoc(doc(d, 'usuarios_privado/B'), { cpf: '22255588846' });
    await setDoc(doc(d, 'negocios_privado/neg_A'), { uid: 'A', cpf: '11144477735' });
    await setDoc(doc(d, 'conversas/antiga1'), { texto: 'sem participantes' });
    await setDoc(doc(d, 'config/estatisticas'), { totalUsuarios: 10 });
    await setDoc(doc(d, 'config/meu_negocio_contador'), { total: 3 });
  });
  // usuarios
  await t('A altera o próprio perfil', 'permite', () => updateDoc(doc(A, 'usuarios/A'), { nome: 'A2' }));
  await t('A altera perfil de B', 'bloqueia', () => updateDoc(doc(A, 'usuarios/B'), { nome: 'hack' }));
  // conversas / mensagens
  await t('C (não participante) lê mensagens de A_B', 'bloqueia', () => getDoc(doc(C, 'conversas/A_B/mensagens/m1')));
  await t('C envia mensagem em A_B', 'bloqueia', () => setDoc(doc(C, 'conversas/A_B/mensagens/x'), { de: 'C', texto: 'spam' }));
  await t('B envia mensagem com de falso (A)', 'bloqueia', () => setDoc(doc(B, 'conversas/A_B/mensagens/x2'), { de: 'A', texto: 'f' }));
  await t('B envia mensagem legítima', 'permite', () => setDoc(doc(B, 'conversas/A_B/mensagens/x3'), { de: 'B', texto: 'ok' }));
  await t('A lê mensagens da própria conversa', 'permite', () => getDoc(doc(A, 'conversas/A_B/mensagens/m1')));
  await t('C se inclui na conversa A_B', 'bloqueia', () => updateDoc(doc(C, 'conversas/A_B'), { participantes: ['A', 'B', 'C'] }));
  await t('A cria conversa A_C (legítima)', 'permite', () => setDoc(doc(A, 'conversas/A_C'), { participantes: ['A', 'C'] }, { merge: true }));
  await t('C cria conversa com id de A_B (id errado/sequestro)', 'bloqueia', () => setDoc(doc(C, 'conversas/Z_Y'), { participantes: ['C', 'B'] }));
  // vagas
  await t('B edita vaga de A', 'bloqueia', () => updateDoc(doc(B, 'vagas/v1'), { titulo: 'hack' }));
  await t('B exclui vaga de A', 'bloqueia', () => deleteDoc(doc(B, 'vagas/v1')));
  await t('B cria vaga em nome de A', 'bloqueia', () => setDoc(doc(B, 'vagas/v2'), { uid: 'A' }));
  await t('B cria vaga própria', 'permite', () => setDoc(doc(B, 'vagas/v3'), { uid: 'B' }));
  await t('A edita a própria vaga', 'permite', () => updateDoc(doc(A, 'vagas/v1'), { titulo: 'novo' }));
  await t('A troca o dono da própria vaga', 'bloqueia', () => updateDoc(doc(A, 'vagas/v1'), { uid: 'B' }));
  // agendamentos
  await t('C (sem cadastro acadêmico) lê pedido aberto', 'bloqueia', () => getDoc(doc(C, 'agendamentos/ag1')));
  await t('B (acadêmico) lê pedido aberto', 'permite', () => getDoc(doc(B, 'agendamentos/ag1')));
  await t('B (acadêmico) lista pedidos abertos', 'permite', () => getDocs(query(collection(B, 'agendamentos'), where('status', '==', 'aberto'))));
  await t('C aceita pedido', 'bloqueia', () => updateDoc(doc(C, 'agendamentos/ag1'), { status: 'aceito', profissionalUid: 'C', profissionalNome: 'C', aceitoEm: 1 }));
  await t('B aceita como outro profissional', 'bloqueia', () => updateDoc(doc(B, 'agendamentos/ag1'), { status: 'aceito', profissionalUid: 'X', profissionalNome: 'B', aceitoEm: 1 }));
  await t('B recusa (arrayUnion)', 'permite', () => updateDoc(doc(B, 'agendamentos/ag1'), { recusadoPor: arrayUnion('B') }));
  await t('B muda o cliente do pedido', 'bloqueia', () => updateDoc(doc(B, 'agendamentos/ag1'), { clienteUid: 'B' }));
  await t('A cria pedido em nome de B', 'bloqueia', () => addDoc(collection(A, 'agendamentos'), { clienteUid: 'B', status: 'aberto', profissionalUid: null }));
  await t('A cria pedido próprio', 'permite', () => addDoc(collection(A, 'agendamentos'), { clienteUid: 'A', clienteNome: 'A', tipoProfissional: 'x', status: 'aberto', profissionalUid: null, profissionalNome: null, recusadoPor: [], criadoEm: 1, expiraEm: 2, dataHora: '', local: '', descricao: '', tipoConsulta: '' }));
  await t('A expira o próprio pedido', 'permite', () => updateDoc(doc(A, 'agendamentos/ag1'), { status: 'expirado' }));
  // avaliações de pessoas
  await t('B avalia A (transação-equivalente: batch)', 'permite', async () => { const b = writeBatch(B); b.set(doc(B, 'avaliacoes_pessoas/A_B'), { uid: 'A', avaliador: 'B', estrelas: 5, ts: new Date() }); b.set(doc(B, 'usuarios/A'), { avaliacaoSoma: 5, avaliacaoCount: 1 }, { merge: true }); await b.commit(); });
  await t('B infla nota de A sem avaliação (soma direta)', 'bloqueia', () => updateDoc(doc(B, 'usuarios/A'), { avaliacaoSoma: 500, avaliacaoCount: 1 }));
  await t('B repete a mesma avaliação contando +1 (duplicar)', 'bloqueia', async () => { const b = writeBatch(B); b.set(doc(B, 'avaliacoes_pessoas/A_B'), { uid: 'A', avaliador: 'B', estrelas: 5, ts: new Date() }); b.set(doc(B, 'usuarios/A'), { avaliacaoSoma: 10, avaliacaoCount: 2 }, { merge: true }); await b.commit(); });
  await t('B edita a avaliação 5→2 corretamente', 'permite', async () => { const b = writeBatch(B); b.set(doc(B, 'avaliacoes_pessoas/A_B'), { uid: 'A', avaliador: 'B', estrelas: 2, ts: new Date() }); b.set(doc(B, 'usuarios/A'), { avaliacaoSoma: 2, avaliacaoCount: 1 }, { merge: true }); await b.commit(); });
  await t('B avalia como se fosse C (avaliador falso)', 'bloqueia', () => setDoc(doc(B, 'avaliacoes_pessoas/A_C'), { uid: 'A', avaliador: 'C', estrelas: 5, ts: new Date() }));
  await t('A avalia a si mesmo', 'bloqueia', () => setDoc(doc(A, 'avaliacoes_pessoas/A_A'), { uid: 'A', avaliador: 'A', estrelas: 5, ts: new Date() }));
  // lojas
  await t('B avalia loja de A (batch)', 'permite', async () => { const b = writeBatch(B); b.set(doc(B, 'avaliacoes_lojas/neg_A_B'), { negId: 'neg_A', uid: 'B', estrelas: 4, ts: new Date() }); b.set(doc(B, 'negocios/neg_A'), { avaliacaoSoma: 4, avaliacaoCount: 1 }, { merge: true }); await b.commit(); });
  await t('B infla loja sem avaliação', 'bloqueia', () => updateDoc(doc(B, 'negocios/neg_A'), { avaliacaoSoma: 900, avaliacaoCount: 1 }));
  await t('A (dono) avalia a própria loja', 'bloqueia', () => setDoc(doc(A, 'avaliacoes_lojas/neg_A_A'), { negId: 'neg_A', uid: 'A', estrelas: 5, ts: new Date() }));
  await t('B cria loja em nome de A', 'bloqueia', () => setDoc(doc(B, 'negocios/neg_X'), { uid: 'A' }));
  // verificação
  await t('A lê a própria verificação', 'permite', () => getDoc(doc(A, 'verificacoes/A')));
  await t('B lê verificação de A', 'bloqueia', () => getDoc(doc(B, 'verificacoes/A')));
  await t('A grava campo de aprovação na verificação', 'bloqueia', () => updateDoc(doc(A, 'verificacoes/A'), { aprovado: true }));
  await t('A reenvia verificação normal', 'permite', () => setDoc(doc(A, 'verificacoes/A'), { cpf: '1', cpfValido: true, selfie: 's', dataEnvio: 2 }));
  // assinatura / pagamentos
  await t('A lê a própria assinatura', 'permite', () => getDoc(doc(A, 'assinaturas/A')));
  await t('A altera a própria assinatura', 'bloqueia', () => setDoc(doc(A, 'assinaturas/A'), { status: 'ativa', ate: 9e12 }));
  await t('A cria registro em pagamentos', 'bloqueia', () => addDoc(collection(A, 'pagamentos'), { uid: 'A', valor: 1 }));
  // denúncias, emergência
  await t('A lê denúncias', 'bloqueia', () => getDoc(doc(A, 'denuncias/d1')));
  // (corrigido na v17: o payload antigo do teste não era o que o app envia — ver app: denuncianteUid, denunciadoUid, contexto, motivo, detalhes, status 'pendente', ts)
  await t('A envia denúncia (payload real do app)', 'permite', () => addDoc(collection(A, 'denuncias'), { denuncianteUid: 'A', denunciadoUid: 'B', contexto: 'perfil', motivo: 'x', detalhes: 'y', status: 'pendente', ts: new Date() }));
  await t('A envia denúncia em nome de outra pessoa', 'bloqueia', () => addDoc(collection(A, 'denuncias'), { denuncianteUid: 'B', denunciadoUid: 'C', motivo: 'x', status: 'pendente' }));
  await t('B lê emergência de A', 'bloqueia', () => getDoc(doc(B, 'emergencias/e1')));
  // config
  await t('anônimo lê estatisticas', 'permite', () => getDoc(doc(anon, 'config/estatisticas')));
  await t('A soma +1 em totalUsuarios', 'permite', () => updateDoc(doc(A, 'config/estatisticas'), { totalUsuarios: increment(1) }));
  await t('A zera totalUsuarios', 'bloqueia', () => updateDoc(doc(A, 'config/estatisticas'), { totalUsuarios: 0 }));
  await t('A soma +1 no contador de lojas', 'permite', () => updateDoc(doc(A, 'config/meu_negocio_contador'), { total: increment(1) }));
  await t('A grava config qualquer', 'bloqueia', () => setDoc(doc(A, 'config/outro'), { x: 1 }));
  await t('A usa cupons_usados', 'bloqueia', () => setDoc(doc(A, 'cupons_usados/c'), { x: 1 }));
  await t('dono lê denúncias', 'permite', () => getDoc(doc(dono, 'denuncias/d1')));
  // ---- v15: dados privados
  await t('A lê o próprio CPF/contato (usuarios_privado/A)', 'permite', () => getDoc(doc(A, 'usuarios_privado/A')));
  await t('B lê o CPF de A', 'bloqueia', () => getDoc(doc(B, 'usuarios_privado/A')));
  await t('anônimo lê usuarios_privado', 'bloqueia', () => getDoc(doc(anon, 'usuarios_privado/A')));
  await t('B grava em usuarios_privado/A', 'bloqueia', () => setDoc(doc(B, 'usuarios_privado/A'), { cpf: '1' }, { merge: true }));
  await t('A atualiza o próprio CPF (como o app faz, com merge)', 'permite', () => setDoc(doc(A, 'usuarios_privado/A'), { cpf: '11144477735', atualizadoEm: 1 }, { merge: true }));
  await t('A grava campo estranho no privado', 'bloqueia', () => setDoc(doc(A, 'usuarios_privado/A'), { verificado: true }, { merge: true }));
  await t('A cria o próprio privado do zero (usuário novo)', 'permite', () => setDoc(doc(env.authenticatedContext('N').firestore(), 'usuarios_privado/N'), { cpf: '1', contatoEmergencia: '2', atualizadoEm: 1 }, { merge: true }));
  await t('listar usuarios_privado inteiro (A)', 'bloqueia', () => getDocs(collection(A, 'usuarios_privado')));
  await t('dono do app lê privado de A', 'permite', () => getDoc(doc(dono, 'usuarios_privado/A')));
  await t('A lê o CPF da própria loja', 'permite', () => getDoc(doc(A, 'negocios_privado/neg_A')));
  await t('B lê o CPF da loja de A', 'bloqueia', () => getDoc(doc(B, 'negocios_privado/neg_A')));
  await t('A grava CPF da própria loja (neg_A)', 'permite', () => setDoc(doc(A, 'negocios_privado/neg_A'), { uid: 'A', cpf: '11144477735', atualizadoEm: 2 }, { merge: true }));
  await t('B grava CPF em negocios_privado/neg_A', 'bloqueia', () => setDoc(doc(B, 'negocios_privado/neg_A'), { uid: 'B', cpf: '1' }, { merge: true }));
  await t('B grava negocios_privado com id de outro, uid próprio', 'bloqueia', () => setDoc(doc(B, 'negocios_privado/neg_A2'), { uid: 'B', cpf: '1' }));
  // ---- documentos antigos
  await t('conversa antiga sem "participantes": usuário comum NÃO lê', 'bloqueia', () => getDoc(doc(A, 'conversas/antiga1')));
  await t('usuarios (perfil público) continua legível por logado', 'permite', () => getDoc(doc(C, 'usuarios/A')));
  // ---- v16: chaves de segurança (config/seguranca). Primeiro SEM a chave: comportamento igual ao da v15.
  await t('[v18, SEM chave] A grava trial_fim no próprio perfil (v18: sempre bloqueado; na v17 sem chave era permitido — mudança deliberada)', 'bloqueia', () => updateDoc(doc(A, 'usuarios/A'), { trial_fim: 1 }));
  await t('[v18, SEM chave] A grava master_ativo:true (v18: sempre bloqueado; na v17 sem chave era permitido — mudança deliberada)', 'bloqueia', () => updateDoc(doc(A, 'usuarios/A'), { master_ativo: true }));
  await env.withSecurityRulesDisabled(async ctx => {
    const d = ctx.firestore();
    await setDoc(doc(d, 'config/seguranca'), { protegerCampos: true, exigirAcesso: true });
    await setDoc(doc(d, 'usuarios/A'), { nome: 'A', tipo: 'trabalhador' });
    await setDoc(doc(d, 'usuarios/P'), { nome: 'P', tipo: 'prestador' });
    await setDoc(doc(d, 'usuarios/Q'), { nome: 'Q', tipo: 'prestador' });
    await setDoc(doc(d, 'usuarios/R'), { nome: 'R', tipo: 'prestador' });
    await setDoc(doc(d, 'assinaturas/P'), { acessoValidoAte: Date.now() + 86400000 * 10 });
    await setDoc(doc(d, 'assinaturas/Q'), { acessoValidoAte: Date.now() - 86400000 * 30 });
  });
  const P = env.authenticatedContext('P').firestore(), Q = env.authenticatedContext('Q').firestore(), Rr = env.authenticatedContext('R').firestore();
  await t('[chave ligada] A atualiza o próprio nome (uso normal)', 'permite', () => updateDoc(doc(A, 'usuarios/A'), { nome: 'A2' }));
  await t('[chave ligada] A grava trial_fim', 'bloqueia', () => updateDoc(doc(A, 'usuarios/A'), { trial_fim: 9e12 }));
  await t('[chave ligada] A grava trial_cod/trial_inicio', 'bloqueia', () => updateDoc(doc(A, 'usuarios/A'), { trial_cod: 'X', trial_inicio: 1 }));
  await t('[chave ligada] A se dá o selo verificado', 'bloqueia', () => updateDoc(doc(A, 'usuarios/A'), { verificado: true }));
  await t('[chave ligada] A liga master_ativo', 'bloqueia', () => updateDoc(doc(A, 'usuarios/A'), { master_ativo: true }));
  await t('[chave ligada] A desliga master_ativo (permitido)', 'permite', () => updateDoc(doc(A, 'usuarios/A'), { master_ativo: false, master_modo: 'prestador' }));
  await t('[chave ligada] A muda plano para pago', 'bloqueia', () => updateDoc(doc(A, 'usuarios/A'), { plano: 'master' }));
  await t('[chave ligada] A grava a própria nota', 'bloqueia', () => updateDoc(doc(A, 'usuarios/A'), { avaliacaoSoma: 500, avaliacaoCount: 1 }));
  await t('[chave ligada] cadastro novo normal (plano free, xp)', 'permite', () => setDoc(doc(env.authenticatedContext('N2').firestore(), 'usuarios/N2'), { nome: 'N', plano: 'free', xp: 0, tipo: '' }, { merge: true }));
  await t('[chave ligada] cadastro novo já verificado', 'bloqueia', () => setDoc(doc(env.authenticatedContext('N3').firestore(), 'usuarios/N3'), { nome: 'N', verificado: true }));
  await t('[chave ligada] usuário escreve a própria assinatura/acesso', 'bloqueia', () => setDoc(doc(P, 'assinaturas/P'), { acessoValidoAte: 9e12 }));
  await t('[chave ligada] usuário lê a própria assinatura', 'permite', () => getDoc(doc(P, 'assinaturas/P')));
  await t('[acesso] Prestador COM acesso válido publica vaga', 'permite', () => setDoc(doc(P, 'vagas/vp'), { uid: 'P', titulo: 'x' }));
  await t('[acesso] Prestador com acesso VENCIDO publica vaga', 'bloqueia', () => setDoc(doc(Q, 'vagas/vq'), { uid: 'Q', titulo: 'x' }));
  await t('[acesso] Prestador SEM registro de acesso publica vaga', 'bloqueia', () => setDoc(doc(Rr, 'vagas/vr'), { uid: 'R', titulo: 'x' }));
  await t('[acesso] Pessoa Física (sem plano) continua livre para o que já fazia (vaga)', 'permite', () => setDoc(doc(A, 'vagas/va'), { uid: 'A', titulo: 'x' }));
  await t('[acesso] Prestador com acesso vencido fica disponível (disponiveis)', 'bloqueia', () => setDoc(doc(Q, 'disponiveis/Q'), { uid: 'Q', online: true }));
  await t('[acesso] Prestador com acesso válido fica disponível', 'permite', () => setDoc(doc(P, 'disponiveis/P'), { uid: 'P', online: true }));
  await t('[acesso] Prestador com acesso vencido consegue sair do ar (delete)', 'permite', () => deleteDoc(doc(Q, 'disponiveis/Q')));
  await t('[acesso] Prestador com acesso vencido cria loja', 'bloqueia', () => setDoc(doc(Q, 'negocios/neg_Q'), { uid: 'Q', nome: 'L' }));
  await t('[acesso] Prestador com acesso válido cria loja', 'permite', () => setDoc(doc(P, 'negocios/neg_P'), { uid: 'P', nome: 'L' }));
  // ---- administração
  const adminClaim = env.authenticatedContext('ADM', { admin: true }).firestore();
  const donoNaoVerif = env.authenticatedContext('D2', { email: 'frilaoneapp@gmail.com', email_verified: false }).firestore();
  await t('[admin] custom claim admin lê denúncias', 'permite', () => getDoc(doc(adminClaim, 'denuncias/d1')));
  await t('[admin] usuário comum lê denúncias', 'bloqueia', () => getDoc(doc(A, 'denuncias/d1')));
  await t('[admin] v17: e-mail do dono SEM verificação NÃO dá acesso de administrador', 'bloqueia', () => getDoc(doc(donoNaoVerif, 'denuncias/d1')));
  await t('[admin] e-mail diferente com claim falsa "admin:false"', 'bloqueia', () => getDoc(doc(env.authenticatedContext('X', { admin: false, email: 'outro@x.com' }).firestore(), 'denuncias/d1')));
  // ---- aceites_termos (etapa LGPD) — NOVOS, também PENDENTES de execução no Emulador
  await t('[aceite] A lê o próprio registro de aceite', 'permite', () => getDoc(doc(A, 'aceites_termos/A')));
  await t('[aceite] A lê o aceite de outra conta', 'bloqueia', () => getDoc(doc(A, 'aceites_termos/B')));
  await t('[aceite] A grava o próprio aceite direto no banco', 'bloqueia', () => setDoc(doc(A, 'aceites_termos/A'), { termosVersao: '1.1' }));
  await t('[aceite] A grava aceite em nome de outra conta', 'bloqueia', () => setDoc(doc(A, 'aceites_termos/B'), { termosVersao: '1.1' }));
  await t('[aceite] A grava evento no próprio histórico', 'bloqueia', () => setDoc(doc(A, 'aceites_termos/A/eventos/e1'), { termosVersao: '1.1' }));
  await t('[aceite] A apaga o próprio registro', 'bloqueia', () => deleteDoc(doc(A, 'aceites_termos/A')));
  await t('[aceite] dono (claim admin) lê aceite de qualquer conta', 'permite', () => getDoc(doc(adminClaim, 'aceites_termos/A')));

  // ════════════════ v17 — NOVOS TESTES (auditoria 12/10/2026) ════════════════
  // Estado limpo: pessoas novas para não depender dos testes anteriores.
  const fx = (uid, claims) => env.authenticatedContext(uid, claims).firestore();
  const U1 = fx('U1'), U2 = fx('U2'), PRO = fx('PRO'), FAKE = fx('FAKE'), OFF = fx('OFF'), NOVO = fx('NOVO');
  await env.withSecurityRulesDisabled(async ctx => {
    const d = ctx.firestore();
    await setDoc(doc(d, 'usuarios/U1'), { nome: 'U1', tipo: 'trabalhador', plano: 'free' });
    await setDoc(doc(d, 'usuarios/U2'), { nome: 'U2', tipo: 'trabalhador', plano: 'free', cpf: '00011122233', contatoEmergencia: '31999990000' }); // legado: CPF ainda no perfil público
    await setDoc(doc(d, 'usuarios/PRO'), { nome: 'PRO', tipo: 'academico', cadMaster: { nome: 'PRO' } });
    await setDoc(doc(d, 'profissionais_aprovados/PRO'), { ativo: true });
    await setDoc(doc(d, 'profissionais_aprovados/OFF'), { ativo: false });
    await setDoc(doc(d, 'usuarios/FAKE'), { nome: 'FAKE', tipo: 'academico', cadMaster: { nome: 'Falso', registro: 'CRP 00/0000' } }); // auto-declarado, NÃO aprovado
    await setDoc(doc(d, 'usuarios/OFF'), { nome: 'OFF', cadMaster: { nome: 'Off' } });
    await setDoc(doc(d, 'agendamentos/ag9'), { clienteUid: 'U1', status: 'aberto', profissionalUid: null, recusadoPor: [], tipoProfissional: 'psicologo', descricao: 'texto que pode ter dado de saúde' });
    await setDoc(doc(d, 'agendamentos/ag10'), { clienteUid: 'U2', status: 'aceito', profissionalUid: 'PRO', recusadoPor: [], tipoProfissional: 'psicologo', descricao: 'outro texto sensível' });
    await setDoc(doc(d, 'verificacoes/U1'), { cpf: '1', cpfValido: true, selfie: 'x', dataEnvio: 1 });
    await setDoc(doc(d, 'negocios/neg_U1'), { uid: 'U1', nome: 'Loja' });
    await setDoc(doc(d, 'negocios_privado/neg_U1'), { uid: 'U1', cpf: '1' });
    await setDoc(doc(d, 'solicitacoes_exclusao/U1'), { uid: 'U1', status: 'erro', erro: 'x' });
    await setDoc(doc(d, 'denuncias/d9'), { denuncianteUid: 'U1' });
    await setDoc(doc(d, 'config/seguranca'), { protegerCampos: true, exigirAcesso: true });
  });
  // --- 1. Plano / teste grátis / selo / master / nota: o cliente não consegue conceder a si mesmo (com as chaves do Modo Servidor LIGADAS)
  await t('[v17 servidor ligado] U1 muda o próprio plano para golden', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { plano: 'golden' }));
  await t('[v17 servidor ligado] U1 muda o próprio plano para master/diamond', 'bloqueia', () => setDoc(doc(U1, 'usuarios/U1'), { plano: 'diamond' }, { merge: true }));
  await t('[v17 servidor ligado] U1 prolonga o próprio teste grátis (trial_fim)', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { trial_fim: 9e12 }));
  await t('[v17 servidor ligado] U1 cria teste grátis novo (trial_inicio/trial_dias)', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { trial_inicio: 1, trial_dias: 3650 }));
  await t('[v17 servidor ligado] U1 se dá o selo de verificado', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { verificado: true }));
  await t('[v17 servidor ligado] U1 liga master_ativo', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { master_ativo: true }));
  await t('[v17 servidor ligado] U1 fabrica acesso pago em assinaturas/U1', 'bloqueia', () => setDoc(doc(U1, 'assinaturas/U1'), { status: 'authorized', acessoValidoAte: 9e12 }));
  await t('[v17 servidor ligado] U1 fabrica pagamento aprovado', 'bloqueia', () => setDoc(doc(U1, 'pagamentos/pfake'), { uid: 'U1', status: 'approved', valor: 14.9 }));
  await t('[v17 servidor ligado] U1 muda plano de OUTRA pessoa', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U2'), { plano: 'golden' }));
  await t('[v17 servidor ligado] U1 atualiza dados normais do perfil (nome, plano free)', 'permite', () => updateDoc(doc(U1, 'usuarios/U1'), { nome: 'U1 novo', plano: 'free' }));
  // --- 1b. Sempre protegido, mesmo com as chaves DESLIGADAS (plano pago e nota própria)
  await env.withSecurityRulesDisabled(async ctx => { await deleteDoc(doc(ctx.firestore(), 'config/seguranca')); });
  await t('[v17 chaves desligadas] U1 muda o próprio plano para pago', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { plano: 'golden' }));
  await t('[v17 chaves desligadas] U1 grava a própria nota (avaliacaoSoma)', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { avaliacaoSoma: 999, avaliacaoCount: 1 }));
  await t('[v17 chaves desligadas] cadastro novo já com plano master', 'bloqueia', () => setDoc(doc(NOVO, 'usuarios/NOVO'), { nome: 'N', plano: 'master' }));
  await t('[v17 chaves desligadas] cadastro novo normal (como o app faz)', 'permite', () => setDoc(doc(NOVO, 'usuarios/NOVO'), { nome: 'N', email: 'n@x.com', tipo: '', tipo_label: '', tipo_icon: '👤', xp: 0, xp_total: 0, nivel: 'Iniciante', plano: 'free', pontos: 0, criadoEm: 1, ultimoLogin: 1 }));
  await t('[v18 sem chave] trial_fim continua bloqueado (a limitação da v17, que dependia da chave, foi eliminada na v18)', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { trial_fim: 1 }));
  await env.withSecurityRulesDisabled(async ctx => { await setDoc(doc(ctx.firestore(), 'config/seguranca'), { protegerCampos: true, exigirAcesso: true }); });
  // --- 3. Administrador
  const donoOk = fx('DONO', { email: 'frilaoneapp@gmail.com', email_verified: true });
  const donoNV = fx('DONO2', { email: 'frilaoneapp@gmail.com', email_verified: false });
  const donoSemFlag = fx('DONO3', { email: 'frilaoneapp@gmail.com' });
  const outroVerif = fx('OUTRO', { email: 'qualquer@outro.com', email_verified: true });
  const claimAdm = fx('ADM1', { admin: true });
  await t('[v17 admin] dono com e-mail VERIFICADO lê denúncias', 'permite', () => getDoc(doc(donoOk, 'denuncias/d9')));
  await t('[v17 admin] dono com e-mail verificado lê selfie/CPF (verificacoes)', 'permite', () => getDoc(doc(donoOk, 'verificacoes/U1')));
  await t('[v17 admin] custom claim admin lê verificações', 'permite', () => getDoc(doc(claimAdm, 'verificacoes/U1')));
  await t('[v17 admin] e-mail do dono NÃO verificado lê denúncias', 'bloqueia', () => getDoc(doc(donoNV, 'denuncias/d9')));
  await t('[v17 admin] e-mail do dono NÃO verificado lê selfie/CPF', 'bloqueia', () => getDoc(doc(donoNV, 'verificacoes/U1')));
  await t('[v17 admin] e-mail do dono sem a informação de verificação lê usuarios_privado', 'bloqueia', () => getDoc(doc(donoSemFlag, 'usuarios_privado/A')));
  await t('[v17 admin] outro e-mail verificado lê denúncias', 'bloqueia', () => getDoc(doc(outroVerif, 'denuncias/d9')));
  await t('[v17 admin] usuário comum grava "admin:true" no próprio perfil e continua sem acesso', 'permite', () => updateDoc(doc(U1, 'usuarios/U1'), { admin: true }));
  await t('[v17 admin] ...e mesmo assim não lê denúncias', 'bloqueia', () => getDoc(doc(U1, 'denuncias/d9')));
  await t('[v17 admin] usuário comum não se concede claim: não lê aceites de outra conta', 'bloqueia', () => getDoc(doc(U1, 'aceites_termos/U2')));
  await t('[v17 admin] dono verificado altera o perfil de outra pessoa (moderação)', 'permite', () => updateDoc(doc(donoOk, 'usuarios/U2'), { nome: 'moderado' }));
  await t('[v17 admin] dono verificado lê pedido de exclusão de qualquer conta', 'permite', () => getDoc(doc(donoOk, 'solicitacoes_exclusao/U1')));
  // --- 4. Dados privados
  await t('[v17 privados] U2 lê selfie/CPF de U1 (verificacoes)', 'bloqueia', () => getDoc(doc(U2, 'verificacoes/U1')));
  await t('[v17 privados] U2 lê CPF/contato de U1 (usuarios_privado)', 'bloqueia', () => getDoc(doc(U2, 'usuarios_privado/A')));
  await t('[v17 privados] U2 lê CPF da loja de U1 (negocios_privado)', 'bloqueia', () => getDoc(doc(U2, 'negocios_privado/neg_U1')));
  await t('[v17 privados] anônimo lê verificacoes', 'bloqueia', () => getDoc(doc(anon, 'verificacoes/U1')));
  await t('[v17 privados] U1 grava CPF no PERFIL PÚBLICO (usuarios)', 'bloqueia', () => updateDoc(doc(U1, 'usuarios/U1'), { cpf: '11144477735' }));
  await t('[v17 privados] U1 grava contato de emergência no perfil público', 'bloqueia', () => setDoc(doc(U1, 'usuarios/U1'), { contatoEmergencia: '31999990000' }, { merge: true }));
  await t('[v17 privados] cadastro novo já com CPF no perfil público', 'bloqueia', () => setDoc(doc(fx('N7'), 'usuarios/N7'), { nome: 'N', cpf: '11144477735' }));
  await t('[v17 privados] U2 (perfil legado com CPF) apaga o CPF do perfil público', 'permite', () => updateDoc(doc(U2, 'usuarios/U2'), { cpf: deleteField(), contatoEmergencia: deleteField() }));
  await env.withSecurityRulesDisabled(async ctx => { await setDoc(doc(ctx.firestore(), 'usuarios/U3'), { nome: 'U3', cpf: '00011122233' }); });
  await t('[v17 privados] perfil legado com CPF ainda consegue atualizar OUTROS campos (sem quebrar usuário antigo)', 'permite', () => updateDoc(doc(fx('U3'), 'usuarios/U3'), { nome: 'U3 novo' }));
  await t('[v17 privados] perfil legado não consegue ALTERAR o CPF que ficou no perfil público', 'bloqueia', () => updateDoc(doc(fx('U3'), 'usuarios/U3'), { cpf: '99999999999' }));
  // --- 5. Agendamentos: selo de profissional não é mais auto-declarado
  await t('[v17 agend] FAKE (escreveu cadMaster no próprio perfil) lê pedido aberto', 'bloqueia', () => getDoc(doc(FAKE, 'agendamentos/ag9')));
  await t('[v17 agend] FAKE lista pedidos abertos', 'bloqueia', () => getDocs(query(collection(FAKE, 'agendamentos'), where('status', '==', 'aberto'))));
  await t('[v17 agend] FAKE aceita pedido aberto', 'bloqueia', () => updateDoc(doc(FAKE, 'agendamentos/ag9'), { status: 'aceito', profissionalUid: 'FAKE', profissionalNome: 'F', aceitoEm: 1 }));
  await t('[v17 agend] FAKE recusa pedido aberto', 'bloqueia', () => updateDoc(doc(FAKE, 'agendamentos/ag9'), { recusadoPor: arrayUnion('FAKE') }));
  await t('[v17 agend] FAKE grava o próprio selo em profissionais_aprovados', 'bloqueia', () => setDoc(doc(FAKE, 'profissionais_aprovados/FAKE'), { ativo: true }));
  await t('[v17 agend] FAKE escreve profissionais_aprovados com merge', 'bloqueia', () => setDoc(doc(FAKE, 'profissionais_aprovados/FAKE'), { ativo: true }, { merge: true }));
  await t('[v17 agend] FAKE lê o pedido já aceito de outro cliente', 'bloqueia', () => getDoc(doc(FAKE, 'agendamentos/ag10')));
  await t('[v17 agend] profissional com selo desativado (ativo:false) lê pedido aberto', 'bloqueia', () => getDoc(doc(OFF, 'agendamentos/ag9')));
  await t('[v17 agend] PRO (aprovado) lê pedido aberto', 'permite', () => getDoc(doc(PRO, 'agendamentos/ag9')));
  await t('[v17 agend] PRO (aprovado) lista pedidos abertos', 'permite', () => getDocs(query(collection(PRO, 'agendamentos'), where('status', '==', 'aberto'))));
  await t('[v17 agend] PRO aceita pedido aberto', 'permite', () => updateDoc(doc(PRO, 'agendamentos/ag9'), { status: 'aceito', profissionalUid: 'PRO', profissionalNome: 'PRO', aceitoEm: 1 }));
  await t('[v17 agend] PRO lê o pedido que ele aceitou', 'permite', () => getDoc(doc(PRO, 'agendamentos/ag10')));
  await t('[v17 agend] cliente lê o próprio pedido', 'permite', () => getDoc(doc(U1, 'agendamentos/ag9')));
  await t('[v17 agend] outro cliente (U2) lê pedido de U1 já aceito por PRO', 'bloqueia', () => getDoc(doc(U2, 'agendamentos/ag9')));
  await t('[v17 agend] PRO lê o próprio selo', 'permite', () => getDoc(doc(PRO, 'profissionais_aprovados/PRO')));
  await t('[v17 agend] FAKE lê o selo de PRO', 'bloqueia', () => getDoc(doc(FAKE, 'profissionais_aprovados/PRO')));
  await t('[v17 agend] dono verificado lê qualquer pedido', 'permite', () => getDoc(doc(donoOk, 'agendamentos/ag10')));
  // --- 7. Cadastro, login, recuperação de senha e exclusão de conta continuam funcionando
  await t('[v17 cadastro] anônimo vê o contador da tela de cadastro', 'permite', () => getDoc(doc(anon, 'config/estatisticas')));
  await t('[v17 cadastro] anônimo consulta quarentena de e-mail excluído (get)', 'permite', () => getDoc(doc(anon, 'exclusoes_bloqueadas/abc')));
  await t('[v17 cadastro] anônimo NÃO lista a quarentena', 'bloqueia', () => getDocs(collection(anon, 'exclusoes_bloqueadas')));
  await t('[v17 cadastro] login: o usuário lê o próprio perfil', 'permite', () => getDoc(doc(U1, 'usuarios/U1')));
  await t('[v17 cadastro] login: atualiza ultimoLogin', 'permite', () => updateDoc(doc(U1, 'usuarios/U1'), { ultimoLogin: 2 }));
  await t('[v17 aceite] usuário lê o próprio registro de aceite (se existir)', 'permite', () => getDoc(doc(U1, 'aceites_termos/U1')));
  await t('[v17 exclusão] pedir exclusão (payload real do app)', 'permite', () => setDoc(doc(fx('X1'), 'solicitacoes_exclusao/X1'), { uid: 'X1', email: 'x@x.com', tipo: 'prestador', status: 'pendente', criadoEm: new Date() }));
  await t('[v17 exclusão] pedir de novo depois de um erro (regrava pendente)', 'permite', () => setDoc(doc(U1, 'solicitacoes_exclusao/U1'), { uid: 'U1', email: 'u1@x.com', tipo: '', status: 'pendente', criadoEm: new Date() }));
  await t('[v17 exclusão] cliente se declara "concluida"', 'bloqueia', () => setDoc(doc(U1, 'solicitacoes_exclusao/U1'), { uid: 'U1', status: 'concluida' }));
  await t('[v17 exclusão] cliente grava campo extra no pedido', 'bloqueia', () => setDoc(doc(U1, 'solicitacoes_exclusao/U1'), { uid: 'U1', status: 'pendente', admin: true }));
  await t('[v17 exclusão] pedido em nome de outra conta', 'bloqueia', () => setDoc(doc(U1, 'solicitacoes_exclusao/U2'), { uid: 'U2', status: 'pendente' }));
  await t('[v17 exclusão] U2 lê o pedido de exclusão de U1', 'bloqueia', () => getDoc(doc(U2, 'solicitacoes_exclusao/U1')));
  await t('[v17 exclusão] U1 apaga o próprio perfil (fluxo legado do app)', 'permite', () => deleteDoc(doc(fx('U9'), 'usuarios/U9')).catch(() => { throw new Error('x'); }).then(() => undefined));
  // --- 8. Vagas, lojas, disponibilidade, conversas, emergência — recursos legítimos preservados
  await env.withSecurityRulesDisabled(async ctx => { await setDoc(doc(ctx.firestore(), 'assinaturas/LJ'), { acessoRegraAte: Date.now() + 10 * 86400000 }); }); // v18: criar loja exige acesso do servidor (seed novo; a intenção do teste — id neg_+uid — não mudou)
  await t('[v17 loja] usuário cria a própria loja (neg_ + uid)', 'permite', () => setDoc(doc(fx('LJ'), 'negocios/neg_LJ'), { uid: 'LJ', nome: 'Minha Loja' }));
  await t('[v17 loja] usuário cria loja com id de OUTRA pessoa (ocupar neg_U2)', 'bloqueia', () => setDoc(doc(U1, 'negocios/neg_U2'), { uid: 'U1', nome: 'Falsa' }));
  await t('[v17 loja] usuário cria loja com id livre (neg_123)', 'bloqueia', () => setDoc(doc(U1, 'negocios/neg_123'), { uid: 'U1', nome: 'x' }));
  await t('[v17 loja] dono atualiza a própria loja', 'permite', () => updateDoc(doc(U1, 'negocios/neg_U1'), { nome: 'Loja nova' }));
  await t('[v17 loja] dono transfere a loja trocando o campo uid', 'bloqueia', () => updateDoc(doc(U1, 'negocios/neg_U1'), { uid: 'U2' }));
  await t('[v17 loja] outra pessoa edita a loja', 'bloqueia', () => updateDoc(doc(U2, 'negocios/neg_U1'), { nome: 'invadida' }));
  await t('[v17 loja] outra pessoa apaga a loja', 'bloqueia', () => deleteDoc(doc(U2, 'negocios/neg_U1')));
  await env.withSecurityRulesDisabled(async ctx => { await deleteDoc(doc(ctx.firestore(), 'config/seguranca')); });
  await t('[v17 disponível] prestador fica disponível (sem as chaves)', 'permite', () => setDoc(doc(U1, 'disponiveis/U1'), { uid: 'U1', online: true }));
  await t('[v17 disponível] alguém grava a disponibilidade de outra pessoa', 'bloqueia', () => setDoc(doc(U2, 'disponiveis/U1'), { uid: 'U1', online: false }));
  await t('[v17 vaga] usuário publica vaga própria (sem as chaves)', 'permite', () => setDoc(doc(U1, 'vagas/vn1'), { uid: 'U1', titulo: 'x' }));
  await t('[v17 conversa] participante envia mensagem', 'permite', () => setDoc(doc(A, 'conversas/A_B/mensagens/m77'), { de: 'A', texto: 'oi' }));
  await t('[v17 conversa] não participante lê a conversa', 'bloqueia', () => getDoc(doc(U1, 'conversas/A_B')));
  await t('[v17 emergência] usuário registra pânico (payload real)', 'permite', () => addDoc(collection(U1, 'emergencias'), { uid: 'U1', nome: 'U1', tipo: 'panico', coords: '-19.4,-44.2', ts: new Date(), expiraEm: 9e12 }));
  await t('[v17 emergência] registra "avisar que estou indo" (checkin) sem coordenadas', 'permite', () => addDoc(collection(U1, 'emergencias'), { uid: 'U1', nome: 'U1', tipo: 'checkin', coords: null, ts: new Date(), expiraEm: 9e12 }));
  await t('[v17 emergência] registro em nome de outra pessoa', 'bloqueia', () => addDoc(collection(U1, 'emergencias'), { uid: 'U2', nome: 'x', tipo: 'panico', coords: null, ts: new Date(), expiraEm: 1 }));
  await t('[v17 emergência] campo extra no registro', 'bloqueia', () => addDoc(collection(U1, 'emergencias'), { uid: 'U1', nome: 'x', tipo: 'panico', coords: null, ts: new Date(), expiraEm: 1, extra: 'x' }));
  await t('[v17 emergência] tipo inválido', 'bloqueia', () => addDoc(collection(U1, 'emergencias'), { uid: 'U1', nome: 'x', tipo: 'outro', coords: null, ts: new Date(), expiraEm: 1 }));
  await t('[v17 emergência] usuário apaga o próprio registro (só o servidor apaga)', 'bloqueia', () => deleteDoc(doc(U1, 'emergencias/e1')));
  await t('[v17 emergência] usuário lista emergências de todos', 'bloqueia', () => getDocs(collection(U1, 'emergencias')));

  // ════════════════ v18 — NOVOS TESTES (etapa final) ════════════════
  const DIA = 86400000, LIMITE = Date.UTC(2026, 11, 1, 3); // 01/12/2026 00:00 em Brasília
  const relogio = (iso) => { if (globalThis.__EH_SIMULADO) globalThis.__RELOGIO_SIMULADO = iso ? Date.parse(iso) : 0; };
  const now = Date.now();
  await env.withSecurityRulesDisabled(async ctx => {
    const d = ctx.firestore();
    await setDoc(doc(d, 'config/seguranca'), { exigirAcesso: true });   // só para forçar "cobrança ativa" em qualquer data
    // T1: prestador com plano de UMA ÁREA válido
    await setDoc(doc(d, 'usuarios/T1'), { nome: 'T1', tipo: 'prestador' });
    await setDoc(doc(d, 'assinaturas/T1'), { precisaPlano: true, acessoValidoAte: now + 10 * DIA, acessoRegraAte: now + 13 * DIA, acessoPlano: 'golden' });
    // T2: teve plano, acesso VENCIDO, e depois trocou o tipo para Pessoa Física (tentativa de escapar)
    await setDoc(doc(d, 'usuarios/T2'), { nome: 'T2', tipo: 'trabalhador' });
    await setDoc(doc(d, 'assinaturas/T2'), { precisaPlano: true, acessoValidoAte: now - 30 * DIA, acessoRegraAte: now - 27 * DIA, acessoPlano: '' });
    // T3: Pessoa Física de verdade, nunca teve plano
    await setDoc(doc(d, 'usuarios/T3'), { nome: 'T3', tipo: 'trabalhador' });
    // T4: em carência (servidor gravou acessoValidoAte 0 e acessoRegraAte no futuro)
    await setDoc(doc(d, 'usuarios/T4'), { nome: 'T4', tipo: 'prestador' });
    await setDoc(doc(d, 'assinaturas/T4'), { precisaPlano: true, acessoValidoAte: 0, acessoRegraAte: now + DIA, acessoPlano: '' });
    // T5: master_ativo gravado no perfil, tipo Pessoa Física, sem assinatura
    await setDoc(doc(d, 'usuarios/T5'), { nome: 'T5', tipo: 'trabalhador', master_ativo: true });
    // T6/T6b: registro antigo (sem acessoRegraAte): vale a conta antiga validoAte + 3 dias
    await setDoc(doc(d, 'usuarios/T6'), { nome: 'T6', tipo: 'prestador' });
    await setDoc(doc(d, 'assinaturas/T6'), { acessoValidoAte: now - 2 * DIA });
    await setDoc(doc(d, 'usuarios/T6b'), { nome: 'T6b', tipo: 'prestador' });
    await setDoc(doc(d, 'assinaturas/T6b'), { acessoValidoAte: now - 4 * DIA });
    // T8 (Minha Loja) e T9 (teste grátis: plano "todos")
    await setDoc(doc(d, 'usuarios/T8'), { nome: 'T8', tipo: 'negocio' });
    await setDoc(doc(d, 'assinaturas/T8'), { precisaPlano: true, acessoValidoAte: 9999999999999, acessoRegraAte: 9999999999999, acessoPlano: 'diamond' });
    await setDoc(doc(d, 'usuarios/T9'), { nome: 'T9', tipo: 'negocio' });
    await setDoc(doc(d, 'assinaturas/T9'), { precisaPlano: true, acessoValidoAte: now + 5 * DIA, acessoRegraAte: now + 8 * DIA, acessoPlano: 'todos' });
  });
  const T1 = fx('T1'), T2 = fx('T2'), T3 = fx('T3'), T4 = fx('T4'), T5 = fx('T5'), T6 = fx('T6'), T6b = fx('T6b'), T8 = fx('T8'), T9 = fx('T9');
  const vg = (c, u) => addDoc(collection(c, 'vagas'), { uid: u, titulo: 'x' });
  // --- tipo NÃO é mais o único critério
  await t('[v18 tipo] T2 trocou o tipo para Pessoa Física com o acesso VENCIDO: publicar vaga continua bloqueado (o servidor marcou precisaPlano)', 'bloqueia', () => vg(T2, 'T2'));
  await t('[v18 tipo] T2 (tipo Pessoa Física, acesso vencido) tenta ficar disponível', 'bloqueia', () => setDoc(doc(T2, 'disponiveis/T2'), { uid: 'T2', online: true }));
  await t('[v18 tipo] Pessoa Física que nunca teve plano publica vaga comum', 'permite', () => vg(T3, 'T3'));
  await t('[v18 tipo] Pessoa Física muda o tipo para prestador: pode (tipo é livre), mas passa a precisar de acesso', 'permite', () => updateDoc(doc(T3, 'usuarios/T3'), { tipo: 'prestador' }));
  await t('[v18 tipo] ...e agora, sem acesso do servidor, não publica vaga', 'bloqueia', () => vg(T3, 'T3'));
  await t('[v18 tipo] ...nem fica disponível', 'bloqueia', () => setDoc(doc(T3, 'disponiveis/T3'), { uid: 'T3', categoria: 'prestador', online: true }));
  await t('[v18 tipo] T5 (master_ativo no perfil, sem assinatura) não publica vaga', 'bloqueia', () => vg(T5, 'T5'));
  await t('[v18 tipo] cliente grava precisaPlano=false para escapar', 'bloqueia', () => setDoc(doc(T2, 'assinaturas/T2'), { precisaPlano: false }, { merge: true }));
  await t('[v18 tipo] cliente grava acessoRegraAte/acessoPlano em assinaturas', 'bloqueia', () => setDoc(doc(T3, 'assinaturas/T3'), { acessoRegraAte: 9e12, acessoPlano: 'todos', precisaPlano: true }));
  // --- acesso legítimo continua funcionando
  await t('[v18 acesso] T1 (uma área, válido) publica vaga', 'permite', () => vg(T1, 'T1'));
  await t('[v18 acesso] T1 fica disponível', 'permite', () => setDoc(doc(T1, 'disponiveis/T1'), { uid: 'T1', online: true }));
  await t('[v18 acesso] LIMITAÇÃO CONHECIDA: T1 (plano de uma área, acesso válido) cria loja — as regras ainda não exigem o plano Minha Loja (ver acessoLoja)', 'permite', () => setDoc(doc(T1, 'negocios/neg_T1'), { uid: 'T1', nome: 'L' }));
  await t('[v18 acesso] T8 (Minha Loja) cria a loja', 'permite', () => setDoc(doc(T8, 'negocios/neg_T8'), { uid: 'T8', nome: 'L' }));
  await t('[v18 acesso] T9 (teste grátis: plano "todos") cria a loja', 'permite', () => setDoc(doc(T9, 'negocios/neg_T9'), { uid: 'T9', nome: 'L' }));
  await t('[v18 acesso] T4 em carência ainda publica vaga e fica disponível', 'permite', () => vg(T4, 'T4').then(() => setDoc(doc(T4, 'disponiveis/T4'), { uid: 'T4', online: true })));
  await t('[v18 acesso] registro antigo (sem acessoRegraAte) dentro dos 3 dias de carência', 'permite', () => vg(T6, 'T6'));
  await t('[v18 acesso] registro antigo vencido há mais de 3 dias', 'bloqueia', () => vg(T6b, 'T6b'));
  await t('[v18 acesso] Pessoa Física (estagiário) fica disponível sem plano', 'permite', () => setDoc(doc(fx('T10'), 'disponiveis/T10'), { uid: 'T10', categoria: 'estagiario', online: true }));
  await t('[v18 acesso] quem tem plano vencido tenta passar por "estagiario" para ficar disponível (aparece só como estagiário)', 'permite', () => setDoc(doc(T2, 'disponiveis/T2'), { uid: 'T2', categoria: 'estagiario', online: true }));
  // --- campos protegidos: o que o app novo envia passa; o que o app antigo enviava (master_ativo:true) não
  await t('[v18 perfil] salvar perfil como o app novo (sem master_ativo:true, sem email, sem cpf)', 'permite', () => setDoc(doc(T3, 'usuarios/T3'), { nome: 'T3', bio: 'x', wa: '31999990000', cidade: 'Sete Lagoas', bairro: 'Centro', atendimento: 'fisico', master_ativo: false, area: 'Eletricista' }, { merge: true }));
  await t('[v18 perfil] salvar perfil como o app ANTIGO fazia com Master ligado (master_ativo:true): bloqueado — por isso o app novo não envia', 'bloqueia', () => setDoc(doc(T3, 'usuarios/T3'), { nome: 'T3', master_ativo: true }, { merge: true }));
  await t('[v18 perfil] cliente grava verificado:false (permitido) e verificado:true (bloqueado)', 'permite', () => setDoc(doc(T3, 'usuarios/T3'), { verificado: false }, { merge: true }));
  await t('[v18 perfil] verificado:true', 'bloqueia', () => setDoc(doc(T3, 'usuarios/T3'), { verificado: true }, { merge: true }));
  // --- e-mails no documento privado
  await t('[v18 privado] dono grava e-mails em usuarios_privado', 'permite', () => setDoc(doc(T3, 'usuarios_privado/T3'), { email: 't3@x.com', emailContato: 't3@x.com', atualizadoEm: 1 }, { merge: true }));
  await t('[v18 privado] outra pessoa lê os e-mails de T3', 'bloqueia', () => getDoc(doc(T1, 'usuarios_privado/T3')));
  await t('[v18 privado] campo fora da lista em usuarios_privado (plano)', 'bloqueia', () => setDoc(doc(T3, 'usuarios_privado/T3'), { plano: 'master' }, { merge: true }));
  // --- exigência por DATA (sem a chave). Simulador: testa antes e depois de 01/12/2026. Emulador oficial: testa a data real de hoje.
  await env.withSecurityRulesDisabled(async ctx => {
    const d = ctx.firestore();
    await deleteDoc(doc(d, 'config/seguranca'));
    await setDoc(doc(d, 'usuarios/DX0'), { nome: 'DX0', tipo: 'prestador' });                                       // plano, sem registro de acesso
    await setDoc(doc(d, 'usuarios/DXV'), { nome: 'DXV', tipo: 'prestador' });
    await setDoc(doc(d, 'assinaturas/DXV'), { precisaPlano: true, acessoValidoAte: Date.UTC(2027, 0, 15), acessoRegraAte: Date.UTC(2027, 0, 18), acessoPlano: 'golden' });
    await setDoc(doc(d, 'usuarios/DXF'), { nome: 'DXF', tipo: 'trabalhador' });
  });
  const cenarios = globalThis.__EH_SIMULADO ? ['2026-11-15T12:00:00Z', '2026-11-30T23:30:00-03:00', '2026-12-01T00:30:00-03:00', '2026-12-02T12:00:00Z'] : [null];
  for (const iso of cenarios) {
    relogio(iso);
    await env.withSecurityRulesDisabled(async ctx => { await deleteDoc(doc(ctx.firestore(), 'negocios/neg_DX0')); await deleteDoc(doc(ctx.firestore(), 'disponiveis/DX0')); });
    const agoraC = iso ? Date.parse(iso) : Date.now();
    const depois = agoraC >= LIMITE;
    const rot = '[v18 data ' + (iso || 'real ' + new Date().toISOString().slice(0, 10)) + (depois ? ', cobrança ATIVA' : ', campanha') + ']';
    await t(rot + ' prestador sem registro de acesso publica vaga', depois ? 'bloqueia' : 'permite', () => vg(fx('DX0'), 'DX0'));
    await t(rot + ' prestador com acesso válido publica vaga', 'permite', () => vg(fx('DXV'), 'DXV'));
    await t(rot + ' Pessoa Física publica vaga comum', 'permite', () => vg(fx('DXF'), 'DXF'));
    await t(rot + ' prestador sem registro fica disponível', depois ? 'bloqueia' : 'permite', () => setDoc(doc(fx('DX0'), 'disponiveis/DX0'), { uid: 'DX0', online: true }));
    await t(rot + ' prestador sem registro cria loja', depois ? 'bloqueia' : 'permite', () => setDoc(doc(fx('DX0'), 'negocios/neg_DX0'), { uid: 'DX0', nome: 'L' }));
  }
  relogio(null);

  // ════════════════ v18 — COBERTURA: leitura (get/list), criação, atualização e exclusão de CADA coleção ════════════════
  // (Prioridade 1 do pedido: os testes oficiais precisam cobrir as quatro operações. Casos: dono permitido; outra pessoa / sem login negado.)
  const AN = env.unauthenticatedContext().firestore(); const K1 = fx('K1'), K2 = fx('K2'), K3 = fx('K3'), KD = fx('KD', { admin: true });
  await env.withSecurityRulesDisabled(async ctx => {
    const d = ctx.firestore();
    await deleteDoc(doc(d, 'config/seguranca'));
    await setDoc(doc(d, 'usuarios/K1'), { nome: 'K1', tipo: 'trabalhador', plano: 'free' });
    await setDoc(doc(d, 'usuarios/K2'), { nome: 'K2', tipo: 'trabalhador', plano: 'free' });
    await setDoc(doc(d, 'usuarios_privado/K1'), { cpf: '1' });
    await setDoc(doc(d, 'negocios/neg_K1'), { uid: 'K1', nome: 'Loja K1', ativo: true });
    await setDoc(doc(d, 'negocios_privado/neg_K1'), { uid: 'K1', cpf: '1' });
    await setDoc(doc(d, 'disponiveis/K1'), { uid: 'K1', online: true });
    await setDoc(doc(d, 'vagas/vk1'), { uid: 'K1', titulo: 'x', ativa: true });
    await setDoc(doc(d, 'conversas/K1_K2'), { participantes: ['K1', 'K2'] });
    await setDoc(doc(d, 'conversas/K1_K2/mensagens/mk'), { de: 'K1', texto: 'oi' });
    await setDoc(doc(d, 'mensagens/mk1'), { de: 'K1', para: 'K2', texto: 'oi' });
    await setDoc(doc(d, 'candidaturas/ck1'), { candidatoUid: 'K1', empresaUid: 'K2' });
    await setDoc(doc(d, 'curriculos/K1'), { nome: 'K1' });
    await setDoc(doc(d, 'estagiarios/K1'), { nome: 'K1' });
    await setDoc(doc(d, 'indicacoes/K1'), { referredUid: 'K1', referrerUid: 'K2' });
    await setDoc(doc(d, 'avaliacoes_lojas/neg_K1_K2'), { negId: 'neg_K1', uid: 'K2', estrelas: 4, ts: 1 });
    await setDoc(doc(d, 'avaliacoes_pessoas/K1_K2'), { uid: 'K1', avaliador: 'K2', estrelas: 5, ts: 1 });
    await setDoc(doc(d, 'pagamentos/pk1'), { uid: 'K1', status: 'approved' });
    await setDoc(doc(d, 'exclusoes_bloqueadas/hashx'), { ate: 1 });
    await setDoc(doc(d, 'cupons_usados/cu1'), { uid: 'K1' });
    await setDoc(doc(d, 'assinaturas/K1'), { precisaPlano: true });
    await setDoc(doc(d, 'denuncias/dk1'), { denuncianteUid: 'K1' });
    await setDoc(doc(d, 'agendamentos/agk1'), { clienteUid: 'K1', status: 'aberto', profissionalUid: null, recusadoPor: [] });
    await setDoc(doc(d, 'emergencias/ek1'), { uid: 'K1', tipo: 'panico' });
    await setDoc(doc(d, 'profissionais_aprovados/K1'), { ativo: true });
    await setDoc(doc(d, 'verificacoes/K2'), { cpf: '1', cpfValido: true, selfie: 'x', dataEnvio: 1 });
    await setDoc(doc(d, 'solicitacoes_exclusao/K1'), { uid: 'K1', status: 'pendente' });
    await setDoc(doc(d, 'config/estatisticas'), { totalUsuarios: 5 });
    await setDoc(doc(d, 'config/meu_negocio_contador'), { total: 2 });
    await setDoc(doc(d, 'config/outro'), { x: 1 });
  });
  const lista = (c, col, ...w) => getDocs(w.length ? query(collection(c, col), ...w) : collection(c, col));
  // usuarios
  await t('[cobertura] usuarios: get — pessoa logada lê perfil público', 'permite', () => getDoc(doc(K2, 'usuarios/K1')));
  await t('[cobertura] usuarios: get — sem login', 'bloqueia', () => getDoc(doc(AN, 'usuarios/K1')));
  await t('[cobertura] usuarios: list — logado lista (Destaque/busca)', 'permite', () => lista(K2, 'usuarios'));
  await t('[cobertura] usuarios: list — sem login', 'bloqueia', () => lista(AN, 'usuarios'));
  await t('[cobertura] usuarios: create — o próprio perfil', 'permite', () => setDoc(doc(K3, 'usuarios/K3'), { nome: 'K3', plano: 'free' }));
  await t('[cobertura] usuarios: create — perfil de outra pessoa', 'bloqueia', () => setDoc(doc(K3, 'usuarios/K9'), { nome: 'falso', plano: 'free' }));
  await t('[cobertura] usuarios: update — outra pessoa muda o nome', 'bloqueia', () => updateDoc(doc(K2, 'usuarios/K1'), { nome: 'hack' }));
  await t('[cobertura] usuarios: delete — de outra pessoa', 'bloqueia', () => deleteDoc(doc(K2, 'usuarios/K1')));
  await t('[cobertura] usuarios: delete — o próprio', 'permite', () => deleteDoc(doc(K3, 'usuarios/K3')));
  await t('[cobertura] usuarios: delete — administrador', 'permite', () => deleteDoc(doc(KD, 'usuarios/K2')));
  await env.withSecurityRulesDisabled(async ctx => { await setDoc(doc(ctx.firestore(), 'usuarios/K2'), { nome: 'K2', tipo: 'trabalhador', plano: 'free' }); });
  // usuarios_privado
  await t('[cobertura] usuarios_privado: get — o dono', 'permite', () => getDoc(doc(K1, 'usuarios_privado/K1')));
  await t('[cobertura] usuarios_privado: get — outra pessoa', 'bloqueia', () => getDoc(doc(K2, 'usuarios_privado/K1')));
  await t('[cobertura] usuarios_privado: create — em nome de outra pessoa', 'bloqueia', () => setDoc(doc(K2, 'usuarios_privado/K9'), { cpf: '2' }));
  await t('[cobertura] usuarios_privado: update — outra pessoa muda o CPF', 'bloqueia', () => updateDoc(doc(K2, 'usuarios_privado/K1'), { cpf: '2' }));
  await t('[cobertura] usuarios_privado: delete — outra pessoa', 'bloqueia', () => deleteDoc(doc(K2, 'usuarios_privado/K1')));
  await t('[cobertura] usuarios_privado: delete — o dono', 'permite', () => deleteDoc(doc(K1, 'usuarios_privado/K1')));
  // negocios_privado
  await t('[cobertura] negocios_privado: delete — outra pessoa', 'bloqueia', () => deleteDoc(doc(K2, 'negocios_privado/neg_K1')));
  await t('[cobertura] negocios_privado: delete — o dono', 'permite', () => deleteDoc(doc(K1, 'negocios_privado/neg_K1')));
  // negocios
  await t('[cobertura] negocios: get — logado', 'permite', () => getDoc(doc(K2, 'negocios/neg_K1')));
  await t('[cobertura] negocios: get — sem login', 'bloqueia', () => getDoc(doc(AN, 'negocios/neg_K1')));
  await t('[cobertura] negocios: list — vitrine (ativo==true)', 'permite', () => lista(K2, 'negocios', where('ativo', '==', true)));
  await t('[cobertura] negocios: list — sem login', 'bloqueia', () => lista(AN, 'negocios', where('ativo', '==', true)));
  await t('[cobertura] negocios: delete — de outra pessoa', 'bloqueia', () => deleteDoc(doc(K2, 'negocios/neg_K1')));
  await t('[cobertura] negocios: delete — o dono', 'permite', () => deleteDoc(doc(K1, 'negocios/neg_K1')));
  // disponiveis
  await t('[cobertura] disponiveis: get — logado', 'permite', () => getDoc(doc(K2, 'disponiveis/K1')));
  await t('[cobertura] disponiveis: list — logado (Tô disponível)', 'permite', () => lista(K2, 'disponiveis'));
  await t('[cobertura] disponiveis: list — sem login', 'bloqueia', () => lista(AN, 'disponiveis'));
  await t('[cobertura] disponiveis: update — o dono (heartbeat)', 'permite', () => updateDoc(doc(K1, 'disponiveis/K1'), { ts: 2 }));
  await t('[cobertura] disponiveis: delete — outra pessoa', 'bloqueia', () => deleteDoc(doc(K2, 'disponiveis/K1')));
  await t('[cobertura] disponiveis: delete — o dono', 'permite', () => deleteDoc(doc(K1, 'disponiveis/K1')));
  // vagas
  await t('[cobertura] vagas: get — logado', 'permite', () => getDoc(doc(K2, 'vagas/vk1')));
  await t('[cobertura] vagas: list — logado (feed)', 'permite', () => lista(K2, 'vagas', where('ativa', '==', true)));
  await t('[cobertura] vagas: list — sem login', 'bloqueia', () => lista(AN, 'vagas', where('ativa', '==', true)));
  await t('[cobertura] vagas: update — o dono edita', 'permite', () => updateDoc(doc(K1, 'vagas/vk1'), { titulo: 'novo' }));
  await t('[cobertura] vagas: update — o dono tenta trocar o dono (uid)', 'bloqueia', () => updateDoc(doc(K1, 'vagas/vk1'), { uid: 'K2' }));
  await t('[cobertura] vagas: update — outra pessoa', 'bloqueia', () => updateDoc(doc(K2, 'vagas/vk1'), { titulo: 'hack' }));
  await t('[cobertura] vagas: delete — outra pessoa', 'bloqueia', () => deleteDoc(doc(K2, 'vagas/vk1')));
  await t('[cobertura] vagas: delete — o dono', 'permite', () => deleteDoc(doc(K1, 'vagas/vk1')));
  // conversas e mensagens
  await t('[cobertura] conversas: get — participante', 'permite', () => getDoc(doc(K1, 'conversas/K1_K2')));
  await t('[cobertura] conversas: update — participante (última mensagem)', 'permite', () => updateDoc(doc(K2, 'conversas/K1_K2'), { ultima: 'oi' }));
  await t('[cobertura] conversas: update — participante tenta incluir um terceiro', 'bloqueia', () => updateDoc(doc(K2, 'conversas/K1_K2'), { participantes: ['K1', 'K2', 'K3'] }));
  await t('[cobertura] conversas: update — quem não participa', 'bloqueia', () => updateDoc(doc(K3, 'conversas/K1_K2'), { ultima: 'x' }));
  await t('[cobertura] conversas: delete — quem não participa', 'bloqueia', () => deleteDoc(doc(K3, 'conversas/K1_K2')));
  await t('[cobertura] conversas: create — id errado', 'bloqueia', () => setDoc(doc(K1, 'conversas/qualquer'), { participantes: ['K1', 'K3'] }));
  await t('[cobertura] conversas: create — participantes certos', 'permite', () => setDoc(doc(K1, 'conversas/K1_K3'), { participantes: ['K1', 'K3'] }));
  await t('[cobertura] conversas: list — só as minhas (array-contains é aplicado pelo servidor; aqui sem restrição = negado)', 'bloqueia', () => lista(K3, 'conversas'));
  await t('[cobertura] conversas/mensagens: get — participante', 'permite', () => getDoc(doc(K2, 'conversas/K1_K2/mensagens/mk')));
  await t('[cobertura] conversas/mensagens: get — quem não participa', 'bloqueia', () => getDoc(doc(K3, 'conversas/K1_K2/mensagens/mk')));
  await t('[cobertura] conversas/mensagens: create — participante em nome próprio', 'permite', () => setDoc(doc(K2, 'conversas/K1_K2/mensagens/mk2'), { de: 'K2', texto: 'oi' }));
  await t('[cobertura] conversas/mensagens: create — em nome de outra pessoa', 'bloqueia', () => setDoc(doc(K2, 'conversas/K1_K2/mensagens/mk3'), { de: 'K1', texto: 'oi' }));
  await t('[cobertura] conversas/mensagens: update — ninguém edita mensagem', 'bloqueia', () => updateDoc(doc(K1, 'conversas/K1_K2/mensagens/mk'), { texto: 'editada' }));
  await t('[cobertura] conversas/mensagens: delete — ninguém apaga mensagem', 'bloqueia', () => deleteDoc(doc(K1, 'conversas/K1_K2/mensagens/mk')));
  await t('[cobertura] mensagens (coleção antiga): get — remetente', 'permite', () => getDoc(doc(K1, 'mensagens/mk1')));
  await t('[cobertura] mensagens (coleção antiga): get — terceiro', 'bloqueia', () => getDoc(doc(K3, 'mensagens/mk1')));
  await t('[cobertura] mensagens (coleção antiga): create — em nome próprio', 'permite', () => setDoc(doc(K1, 'mensagens/mk9'), { de: 'K1', para: 'K2' }));
  await t('[cobertura] mensagens (coleção antiga): create — em nome de outra pessoa', 'bloqueia', () => setDoc(doc(K1, 'mensagens/mk8'), { de: 'K2', para: 'K1' }));
  // candidaturas, currículos, estagiários, indicações
  await t('[cobertura] candidaturas: get — candidato', 'permite', () => getDoc(doc(K1, 'candidaturas/ck1')));
  await t('[cobertura] candidaturas: get — empresa', 'permite', () => getDoc(doc(K2, 'candidaturas/ck1')));
  await t('[cobertura] candidaturas: get — terceiro', 'bloqueia', () => getDoc(doc(K3, 'candidaturas/ck1')));
  await t('[cobertura] candidaturas: create — em nome próprio', 'permite', () => setDoc(doc(K3, 'candidaturas/ck2'), { candidatoUid: 'K3', empresaUid: 'K2' }));
  await t('[cobertura] candidaturas: create — em nome de outra pessoa', 'bloqueia', () => setDoc(doc(K3, 'candidaturas/ck3'), { candidatoUid: 'K1', empresaUid: 'K2' }));
  await t('[cobertura] candidaturas: update/delete — ninguém', 'bloqueia', () => deleteDoc(doc(K1, 'candidaturas/ck1')));
  await t('[cobertura] curriculos: get — logado', 'permite', () => getDoc(doc(K2, 'curriculos/K1')));
  await t('[cobertura] curriculos: list — logado (banco de currículos)', 'permite', () => lista(K2, 'curriculos'));
  await t('[cobertura] curriculos: create/update — o dono', 'permite', () => setDoc(doc(K1, 'curriculos/K1'), { nome: 'K1 novo' }));
  await t('[cobertura] curriculos: update — outra pessoa', 'bloqueia', () => setDoc(doc(K2, 'curriculos/K1'), { nome: 'hack' }));
  await t('[cobertura] curriculos: delete — outra pessoa', 'bloqueia', () => deleteDoc(doc(K2, 'curriculos/K1')));
  await t('[cobertura] curriculos: delete — o dono', 'permite', () => deleteDoc(doc(K1, 'curriculos/K1')));
  await t('[cobertura] estagiarios: get/list — logado', 'permite', () => lista(K2, 'estagiarios'));
  await t('[cobertura] estagiarios: create — o dono', 'permite', () => setDoc(doc(K2, 'estagiarios/K2'), { nome: 'K2' }));
  await t('[cobertura] estagiarios: update — outra pessoa', 'bloqueia', () => updateDoc(doc(K2, 'estagiarios/K1'), { nome: 'hack' }));
  await t('[cobertura] estagiarios: delete — o dono', 'permite', () => deleteDoc(doc(K1, 'estagiarios/K1')));
  await t('[cobertura] indicacoes: get — quem indicou', 'permite', () => getDoc(doc(K2, 'indicacoes/K1')));
  await t('[cobertura] indicacoes: get — terceiro', 'bloqueia', () => getDoc(doc(K3, 'indicacoes/K1')));
  await t('[cobertura] indicacoes: create — o convidado, em nome próprio', 'permite', () => setDoc(doc(K3, 'indicacoes/K3'), { referredUid: 'K3', referrerUid: 'K2' }));
  await t('[cobertura] indicacoes: create — autoindicação', 'bloqueia', () => setDoc(doc(K2, 'indicacoes/K2'), { referredUid: 'K2', referrerUid: 'K2' }));
  await t('[cobertura] indicacoes: update/delete — ninguém', 'bloqueia', () => deleteDoc(doc(K3, 'indicacoes/K3')));
  // avaliações (a loja K1 foi apagada acima; recria para o teste — as regras de avaliação consultam a loja)
  await env.withSecurityRulesDisabled(async ctx => { await setDoc(doc(ctx.firestore(), 'negocios/neg_K1'), { uid: 'K1', nome: 'Loja K1', ativo: true }); });
  await t('[cobertura] avaliacoes_lojas: get — logado', 'permite', () => getDoc(doc(K3, 'avaliacoes_lojas/neg_K1_K2')));
  await t('[cobertura] avaliacoes_lojas: update — o avaliador muda as estrelas', 'permite', () => setDoc(doc(K2, 'avaliacoes_lojas/neg_K1_K2'), { negId: 'neg_K1', uid: 'K2', estrelas: 5, ts: 2 }));
  await t('[cobertura] avaliacoes_lojas: delete — ninguém', 'bloqueia', () => deleteDoc(doc(K2, 'avaliacoes_lojas/neg_K1_K2')));
  await t('[cobertura] avaliacoes_pessoas: get — o avaliador (id termina com o uid dele)', 'permite', () => getDoc(doc(K2, 'avaliacoes_pessoas/K1_K2')));
  await t('[cobertura] avaliacoes_pessoas: get — terceiro', 'bloqueia', () => getDoc(doc(K3, 'avaliacoes_pessoas/K1_K2')));
  await t('[cobertura] avaliacoes_pessoas: delete — ninguém', 'bloqueia', () => deleteDoc(doc(K2, 'avaliacoes_pessoas/K1_K2')));
  // pagamentos, cupons, bloqueios
  await t('[cobertura] pagamentos: get — o dono', 'permite', () => getDoc(doc(K1, 'pagamentos/pk1')));
  await t('[cobertura] pagamentos: get — outra pessoa', 'bloqueia', () => getDoc(doc(K2, 'pagamentos/pk1')));
  await t('[cobertura] pagamentos: update/delete — ninguém', 'bloqueia', () => deleteDoc(doc(K1, 'pagamentos/pk1')));
  await t('[cobertura] cupons_usados (legado): get — administrador', 'permite', () => getDoc(doc(KD, 'cupons_usados/cu1')));
  await t('[cobertura] cupons_usados (legado): get — usuário comum', 'bloqueia', () => getDoc(doc(K1, 'cupons_usados/cu1')));
  await t('[cobertura] exclusoes_bloqueadas: get — qualquer pessoa consulta um código', 'permite', () => getDoc(doc(AN, 'exclusoes_bloqueadas/hashx')));
  await t('[cobertura] exclusoes_bloqueadas: create/update/delete — ninguém', 'bloqueia', () => setDoc(doc(KD, 'exclusoes_bloqueadas/hashy'), { ate: 1 }));
  // assinaturas, denúncias, agendamentos, emergências, profissionais, verificações, exclusão
  await t('[cobertura] assinaturas: get — o dono', 'permite', () => getDoc(doc(K1, 'assinaturas/K1')));
  await t('[cobertura] assinaturas: get — outra pessoa', 'bloqueia', () => getDoc(doc(K2, 'assinaturas/K1')));
  await t('[cobertura] assinaturas: list — ninguém lista todas', 'bloqueia', () => lista(K1, 'assinaturas'));
  await t('[cobertura] assinaturas: delete — o próprio dono', 'bloqueia', () => deleteDoc(doc(K1, 'assinaturas/K1')));
  await t('[cobertura] denuncias: list — administrador', 'permite', () => lista(KD, 'denuncias'));
  await t('[cobertura] denuncias: list — usuário comum', 'bloqueia', () => lista(K1, 'denuncias'));
  await t('[cobertura] denuncias: update/delete — autor da denúncia', 'bloqueia', () => deleteDoc(doc(K1, 'denuncias/dk1')));
  await t('[cobertura] agendamentos: delete — o cliente', 'bloqueia', () => deleteDoc(doc(K1, 'agendamentos/agk1')));
  await t('[cobertura] agendamentos: list — o cliente vê os próprios', 'permite', () => lista(K1, 'agendamentos', where('clienteUid', '==', 'K1')));
  await t('[cobertura] agendamentos: list — pedir todos sem filtro', 'bloqueia', () => lista(K3, 'agendamentos'));
  await t('[cobertura] emergencias: get — o dono', 'permite', () => getDoc(doc(K1, 'emergencias/ek1')));
  await t('[cobertura] emergencias: get — outra pessoa', 'bloqueia', () => getDoc(doc(K2, 'emergencias/ek1')));
  await t('[cobertura] emergencias: update — o dono (não edita registro)', 'bloqueia', () => updateDoc(doc(K1, 'emergencias/ek1'), { tipo: 'checkin' }));
  await t('[cobertura] profissionais_aprovados: list — ninguém', 'bloqueia', () => lista(K1, 'profissionais_aprovados'));
  await t('[cobertura] profissionais_aprovados: delete — o próprio profissional', 'bloqueia', () => deleteDoc(doc(K1, 'profissionais_aprovados/K1')));
  await t('[cobertura] verificacoes: create — o dono envia', 'permite', () => setDoc(doc(K3, 'verificacoes/K3'), { cpf: '1', cpfValido: true, selfie: 'x', dataEnvio: 1 }));
  await t('[cobertura] verificacoes: create — em nome de outra pessoa', 'bloqueia', () => setDoc(doc(K3, 'verificacoes/K1'), { cpf: '1', cpfValido: true, selfie: 'x', dataEnvio: 1 }));
  await t('[cobertura] verificacoes: update — o dono atualiza', 'permite', () => setDoc(doc(K2, 'verificacoes/K2'), { cpf: '2', cpfValido: true, selfie: 'y', dataEnvio: 2 }));
  await t('[cobertura] verificacoes: update — acrescenta campo de aprovação', 'bloqueia', () => setDoc(doc(K2, 'verificacoes/K2'), { aprovado: true }, { merge: true }));
  await t('[cobertura] verificacoes: delete — o dono', 'permite', () => deleteDoc(doc(K2, 'verificacoes/K2')));
  await t('[cobertura] verificacoes: delete — outra pessoa', 'bloqueia', () => deleteDoc(doc(K3, 'verificacoes/K1')));
  await t('[cobertura] solicitacoes_exclusao: delete — o dono não apaga o pedido', 'bloqueia', () => deleteDoc(doc(K1, 'solicitacoes_exclusao/K1')));
  await t('[cobertura] solicitacoes_exclusao: list — administrador', 'permite', () => lista(KD, 'solicitacoes_exclusao'));
  // config
  await t('[cobertura] config/estatisticas: get — sem login (tela de cadastro)', 'permite', () => getDoc(doc(AN, 'config/estatisticas')));
  await t('[cobertura] config/estatisticas: update — +1 por vez', 'permite', () => updateDoc(doc(K1, 'config/estatisticas'), { totalUsuarios: 6 }));
  await t('[cobertura] config/estatisticas: update — saltar para valor alto', 'bloqueia', () => updateDoc(doc(K1, 'config/estatisticas'), { totalUsuarios: 999 }));
  await t('[cobertura] config/estatisticas: delete — usuário comum', 'bloqueia', () => deleteDoc(doc(K1, 'config/estatisticas')));
  await t('[cobertura] config/meu_negocio_contador: get — logado', 'permite', () => getDoc(doc(K1, 'config/meu_negocio_contador')));
  await t('[cobertura] config/meu_negocio_contador: update — +1', 'permite', () => updateDoc(doc(K1, 'config/meu_negocio_contador'), { total: 3 }));
  await t('[cobertura] config/meu_negocio_contador: update — zerar', 'bloqueia', () => updateDoc(doc(K1, 'config/meu_negocio_contador'), { total: 0 }));
  await t('[cobertura] config/{outro}: get — usuário comum', 'bloqueia', () => getDoc(doc(K1, 'config/outro')));
  await t('[cobertura] config/{outro}: get/write — administrador', 'permite', () => setDoc(doc(KD, 'config/outro'), { x: 2 }));
  await t('[cobertura] config/seguranca: usuário comum não liga a chave', 'bloqueia', () => setDoc(doc(K1, 'config/seguranca'), { exigirAcesso: true }));
  await env.cleanup();
  const f = res.filter(x => !x).length; console.log('\n' + (res.length - f) + '/' + res.length + ' conforme o esperado'); process.exit(f ? 1 : 0);
})();
