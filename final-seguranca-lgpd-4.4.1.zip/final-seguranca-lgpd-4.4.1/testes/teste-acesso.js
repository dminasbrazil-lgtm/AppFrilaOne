// Acesso pago decidido pelo servidor — Firebase e Mercado Pago FALSOS (sem rede). Rodar: node teste-acesso.js
const Module=require('module'),assert=require('assert'),path=require('path');
const D=path.join(__dirname,'../functions/'); const L=require(D+'assinatura-lib.js');
let n=0,f=0; const ok=(nome,fn)=>{ try{ fn(); n++; console.log('OK     | '+nome);}catch(e){ f++; console.log('FALHOU | '+nome+' -> '+e.message.split('\n')[0]); } };
const okA=async(nome,fn)=>{ try{ await fn(); n++; console.log('OK     | '+nome);}catch(e){ f++; console.log('FALHOU | '+nome+' -> '+e.message.split('\n')[0]); } };
const T=(s)=>Date.parse(s);
// ───────── funções puras
ok('teste: quem entra em outubro vale até 30/11/2026',()=>{ const t=L.inicioTeste(T('2026-10-20T12:00:00-03:00')); assert.equal(t.fim,L.CAMPANHA_ATE); });
ok('teste: quem entra em 01/12/2026 ganha 7 dias',()=>{ const a=T('2026-12-01T12:00:00-03:00'); assert.equal(L.inicioTeste(a).fim,a+7*86400e3); });
const AG=T('2026-12-10T12:00:00-03:00');
ok('acesso: teste válido',()=>{ const r=L.calcularAcesso({trialFim:AG+1000},AG); assert(r.temAcesso&&r.fonte==='teste'&&r.permiteMaster); });
ok('acesso: teste vencido → carência de 3 dias → nenhum',()=>{ assert(L.calcularAcesso({trialFim:AG-86400e3},AG).emCarencia); assert(!L.calcularAcesso({trialFim:AG-86400e3},AG).temAcesso); const r=L.calcularAcesso({trialFim:AG-5*86400e3},AG); assert(!r.emCarencia&&!r.temAcesso&&r.fonte==='nenhuma'); });
ok('acesso: assinatura autorizada concede; pendente NÃO concede',()=>{ assert(L.calcularAcesso({status:'authorized',plano:'golden'},AG).temAcesso); assert(!L.calcularAcesso({status:'pending'},AG).temAcesso); assert(!L.calcularAcesso({status:'paused'},AG).temAcesso); });
ok('acesso: cancelada vale só até o fim do período pago',()=>{ assert(L.calcularAcesso({status:'cancelled',acessoAte:AG+1},AG).temAcesso); assert(!L.calcularAcesso({status:'cancelled',acessoAte:AG-1},AG).temAcesso); });
ok('acesso: pagamento recusado mantém 3 dias e depois suspende',()=>{ assert(L.calcularAcesso({status:'authorized',pagamentoRecusado:true,recusadoEm:AG-86400e3},AG).temAcesso); assert(!L.calcularAcesso({status:'authorized',pagamentoRecusado:true,recusadoEm:AG-4*86400e3},AG).temAcesso); });
ok('acesso: assinatura de UMA área não libera Master',()=>{ const r=L.calcularAcesso({status:'authorized',plano:'golden'},AG); assert(!r.permiteMaster); assert(L.calcularAcesso({status:'authorized',plano:'master'},AG).permiteMaster); });
ok('acesso: código e concessão manual',()=>{ assert(L.calcularAcesso({codigoFim:AG+5},AG).fonte==='codigo'); assert(L.calcularAcesso({manualAte:AG+5,manualPlano:'golden'},AG).plano==='golden'); });
ok('códigos: o módulo NÃO tem mais resgate, validação, geração nem autoindicação por código',()=>{ for(const k of ['avaliarResgate','normalizarCodigo','meuCodigoCV']) assert.equal(L[k],undefined,k); });
ok('benefício legado já concedido: vale até a data, depois só 3 dias de carência (nada novo é criado)',()=>{ const a={codigoFim:AG+10*86400e3}; assert(L.calcularAcesso(a,AG).temAcesso); const dep=L.calcularAcesso(a,AG+11*86400e3); assert(!dep.temAcesso&&dep.emCarencia); assert(!L.calcularAcesso(a,AG+14*86400e3).emCarencia); });
// ───────── handlers (Firebase falso)
const S={}; const FV={delete:()=>({__del:true})};
const ref=(c,i)=>({get:async()=>({exists:S[c+'/'+i]!==undefined,data:()=>S[c+'/'+i]}),set:async(v,o)=>{const cur=(o&&o.merge&&S[c+'/'+i])||{};const m={...cur};for(const k in v){ if(v[k]&&v[k].__del)delete m[k]; else m[k]=v[k]; } S[c+'/'+i]=m;}});
const admin={initializeApp(){},auth:()=>({verifyIdToken:async t=>{ if(/^ok:/.test(t)) return {uid:t.slice(3)}; throw new Error('x'); }}),firestore:Object.assign(()=>({collection:c=>({doc:i=>ref(c,i)}),runTransaction:async(fn)=>fn({get:r=>r.get(),set:(r,v,o)=>r.set(v,o)})}),{FieldValue:FV})};
const fns={runWith:()=>({region:()=>({https:{onRequest:h=>h}})})};
const orig=Module._load; Module._load=function(r,...a){ if(r==='firebase-functions/v1')return fns; if(r==='firebase-admin')return admin; return orig.call(this,r,...a); };
const mpCalls=[]; const preState={};
global.fetch=async(url,o)=>{ const m=o.method,p=url.replace('https://api.mercadopago.com',''); mpCalls.push(m+' '+p); const R=(b,okk=true,st=200)=>({ok:okk,status:st,json:async()=>b});
  if(m==='POST'&&p==='/preapproval'){ const b=JSON.parse(o.body); const id='PRE'+mpCalls.length; preState[id]={id,status:'pending',external_reference:b.external_reference}; return R({id,init_point:'https://mp.test/'+id}); }
  if(m==='GET'&&p.startsWith('/preapproval/')) return R(preState[p.split('/')[2]]);
  if(m==='PUT'&&p.startsWith('/preapproval/')){ Object.assign(preState[p.split('/')[2]],JSON.parse(o.body)); return R({}); } return R({},false,404); };
process.env.MP_ACCESS_TOKEN='T'; process.env.MP_WEBHOOK_SECRET='seg'; const crypto=require('crypto');
const A=require(D+'assinatura.js');
const mkres=()=>{const r={code:200,body:null,hdr:{}};r.status=c=>{r.code=c;return r};r.json=b=>{r.body=b;return r};r.send=b=>{r.body=b;return r};r.set=(k,v)=>{r.hdr[k]=v};return r;};
const call=async(h,uid,body={})=>{ const rs=mkres(); await h({method:'POST',headers:{authorization:'Bearer ok:'+uid,origin:'https://frilaone.com.br'},body,query:{}},rs); return rs; };
const hook=async(id)=>{ const rid='r'+Math.random(), ts='1704908010'; const sig='ts='+ts+',v1='+crypto.createHmac('sha256','seg').update('id:'+id.toLowerCase()+';request-id:'+rid+';ts:'+ts+';').digest('hex'); const w=mkres(); await A.webhookMercadoPago({method:'POST',headers:{'x-request-id':rid,'x-signature':sig},body:{},query:{'data.id':id,type:'subscription_preapproval'}},w); return w; };
const realNow=Date.now; const setNow=(t)=>{ Date.now=()=>t; };
(async()=>{
  setNow(T('2026-10-20T12:00:00-03:00'));
  S['usuarios/p1']={tipo:'prestador'}; S['usuarios/pf']={tipo:'trabalhador'}; S['usuarios/ac']={tipo:'academico'};
  await okA('statusAcesso: sem login → 401',async()=>{ const rs=mkres(); await A.statusAcesso({method:'POST',headers:{},body:{},query:{}},rs); assert.equal(rs.code,401); });
  await okA('statusAcesso: Prestador novo ganha teste até 30/11 e acesso',async()=>{ const r=await call(A.statusAcesso,'p1'); assert(r.body.ok&&r.body.acesso.temAcesso&&r.body.acesso.fonte==='teste'); assert.equal(S['assinaturas/p1'].trialFim,L.CAMPANHA_ATE); assert(S['assinaturas/p1'].acessoValidoAte>0); });
  await okA('statusAcesso: Pessoa Física NÃO recebe teste nem plano (continua grátis)',async()=>{ const r=await call(A.statusAcesso,'pf'); assert(r.body.ok&&!r.body.acesso.temAcesso); assert(!S['assinaturas/pf']||!S['assinaturas/pf'].trialInicio); });
  await okA('precisaPlano: o servidor marca a conta de plano (e só ela)',async()=>{ assert.strictEqual(S['assinaturas/p1'].precisaPlano,true); assert(!S['assinaturas/pf']||S['assinaturas/pf'].precisaPlano!==true); });
  await okA('precisaPlano é permanente: trocar o tipo para Pessoa Física não desmarca nem renova o teste',async()=>{ const fim=S['assinaturas/p1'].trialFim; S['usuarios/p1'].tipo='trabalhador'; const r=await call(A.statusAcesso,'p1'); assert(r.body.ok); assert.strictEqual(S['assinaturas/p1'].precisaPlano,true); assert.equal(S['assinaturas/p1'].trialFim,fim); S['usuarios/p1'].tipo='prestador'; });
  await okA('campos para as regras: acessoRegraAte e acessoPlano gravados com o acesso',async()=>{ const d=S['assinaturas/p1']; assert.equal(d.acessoRegraAte,L.CAMPANHA_ATE+3*86400e3); assert.equal(d.acessoPlano,'todos'); });
  await okA('teste NÃO é renovado ao entrar de novo depois de vencer',async()=>{ const ini=S['assinaturas/p1'].trialInicio, fim=S['assinaturas/p1'].trialFim; setNow(T('2026-12-20T12:00:00-03:00')); const r=await call(A.statusAcesso,'p1'); assert.equal(S['assinaturas/p1'].trialInicio,ini); assert.equal(S['assinaturas/p1'].trialFim,fim); assert(!r.body.acesso.temAcesso); assert.equal(S['assinaturas/p1'].acessoValidoAte,0); });
  await okA('quem entra em 05/12 ganha 7 dias (uma vez)',async()=>{ setNow(T('2026-12-05T12:00:00-03:00')); const r=await call(A.statusAcesso,'ac'); assert.equal(S['assinaturas/ac'].trialFim,T('2026-12-05T12:00:00-03:00')+7*86400e3); const f1=S['assinaturas/ac'].trialFim; setNow(T('2026-12-30T12:00:00-03:00')); await call(A.statusAcesso,'ac'); assert.equal(S['assinaturas/ac'].trialFim,f1); });
  await okA('Master: Prestador vencido e sem pagamento NÃO consegue ligar (403)',async()=>{ setNow(T('2026-12-20T12:00:00-03:00')); const r=await call(A.definirModoMaster,'p1',{ativo:true}); assert.equal(r.code,403); assert(!S['usuarios/p1'].master_ativo); });
  await okA('Master: Pessoa Física não liga (400)',async()=>{ const r=await call(A.definirModoMaster,'pf',{ativo:true}); assert.equal(r.code,400); });
  await okA('Master: em teste válido liga; ao vencer o servidor desliga sozinho',async()=>{ setNow(T('2026-11-01T12:00:00-03:00')); S['usuarios/m1']={tipo:'prestador'}; await call(A.statusAcesso,'m1'); const r=await call(A.definirModoMaster,'m1',{ativo:true}); assert(r.body.ok&&S['usuarios/m1'].master_ativo===true); setNow(T('2026-12-20T12:00:00-03:00')); await call(A.statusAcesso,'m1'); assert.equal(S['usuarios/m1'].master_ativo,false); });
  // assinatura
  await okA('assinatura: criar (pendente) NÃO concede acesso; autorizar concede; recusar mantém 3 dias; depois suspende; cancelar',async()=>{
    setNow(T('2026-12-20T12:00:00-03:00')); S['usuarios/s1']={tipo:'prestador'}; S['usuarios/s1'].master_ativo=false;
    let r=await call(A.criarAssinatura,'s1',{emailMP:'a@b.com'}); assert(r.body.ok); const id=S['assinaturas/s1'].preapprovalId; assert.equal(S['assinaturas/s1'].status,'pending'); await call(A.statusAcesso,'s1'); S['assinaturas/s1'].trialFim=0; await A.sincronizarAssinatura({method:'POST',headers:{authorization:'Bearer ok:s1'},body:{},query:{}},mkres()); assert.equal(S['assinaturas/s1'].acessoValidoAte,0,'pendente não concede');
    preState[id].status='authorized'; preState[id].next_payment_date='2027-01-01T12:00:00.000-03:00'; await hook(id); assert.equal(S['assinaturas/s1'].acessoValidoAte,L.ILIMITADO);
    S['assinaturas/s1'].pagamentoRecusado=true; S['assinaturas/s1'].recusadoEm=Date.now()-86400e3; const ac1=L.calcularAcesso(S['assinaturas/s1'],Date.now()); assert(ac1.temAcesso);
    const ac2=L.calcularAcesso(S['assinaturas/s1'],Date.now()+4*86400e3); assert(!ac2.temAcesso);
    r=await call(A.cancelarAssinatura,'s1'); assert(r.body.ok); assert.equal(S['assinaturas/s1'].status,'cancelled'); assert(S['assinaturas/s1'].acessoValidoAte>=0); });
  await okA('assinatura Master paga: servidor liga o modo Master',async()=>{ setNow(T('2026-12-20T12:00:00-03:00')); S['usuarios/s2']={tipo:'academico'}; let r=await call(A.criarAssinatura,'s2',{emailMP:'a@b.com',plano:'master'}); assert(r.body.ok); assert.equal(S['assinaturas/s2'].plano,'master'); assert.equal(S['assinaturas/s2'].valor,34.9); const id=S['assinaturas/s2'].preapprovalId; preState[id].status='authorized'; await hook(id); assert.equal(S['usuarios/s2'].master_ativo,true); });
  await okA('plano "master" pedido por Pessoa Física é ignorado',async()=>{ S['usuarios/pf2']={tipo:'trabalhador'}; const r=await call(A.criarAssinatura,'pf2',{emailMP:'a@b.com',plano:'master'}); assert.equal(r.body.erro,'plano_indisponivel'); });
  // códigos retirados / benefício legado
  await okA('função resgatarCodigo NÃO existe mais no servidor (nem coleção codigos é lida)',async()=>{ assert.equal(A.resgatarCodigo,undefined); const src=require('fs').readFileSync(require('path').join(__dirname,'../functions/assinatura.js'),'utf8'); assert(!/resgatarCodigo|collection\('codigos'\)|avaliarResgate/.test(src)); });
  await okA('benefício legado (codigoFim gravado) continua dando acesso pelo statusAcesso; usuário não consegue criar um',async()=>{ setNow(T('2026-12-10T12:00:00-03:00')); S['usuarios/l1']={tipo:'prestador'}; S['assinaturas/l1']={trialInicio:T('2026-10-01T00:00:00-03:00'),trialFim:T('2026-11-30T23:59:59-03:00'),codigoFim:T('2026-12-28T12:00:00-03:00')}; let r=await call(A.statusAcesso,'l1'); assert(r.body.ok&&r.body.acesso.temAcesso&&r.body.acesso.fonte==='codigo'); setNow(T('2027-01-05T12:00:00-03:00')); r=await call(A.statusAcesso,'l1'); assert(!r.body.acesso.temAcesso); });
  // verificação
  await okA('verificação: sem dados → 400; CPF inválido → 400; completa → selo; usuário não se dá o selo',async()=>{ S['usuarios/v1']={tipo:'prestador'}; let r=await call(A.confirmarVerificacao,'v1'); assert.equal(r.code,400); S['verificacoes/v1']={cpf:'11111111111',selfie:'x'.repeat(300)}; r=await call(A.confirmarVerificacao,'v1'); assert.equal(r.code,400); S['verificacoes/v1']={cpf:'11144477735',selfie:'x'.repeat(300)}; r=await call(A.confirmarVerificacao,'v1'); assert(r.body.ok); assert.equal(S['usuarios/v1'].verificado,true); });
  Date.now=realNow; console.log('\n'+n+' OK, '+f+' falharam'); process.exit(f?1:0);
})();
