const fs=require('fs'),assert=require('assert');
const h=fs.readFileSync(__dirname+'/../app/teste-final.html','utf8');
const i=h.indexOf('function _jaAssineiPrestador'),j=h.indexOf('// Foto da outra pessoa no cabeçalho do chat');
const src=h.slice(i,j);
async function run(cfg,sync){
  const log=[],ls={};
  const ctx={closeSheet(){},showToast:(m,t)=>log.push('toast:'+m),_assinaturaConfigurada:()=>cfg,_sincronizarAssinatura:sync,_abrirConversaReal:()=>log.push('abrirConversa'),_mostrarUpsellPrestador:()=>log.push('upsell'),_ativarPlano:()=>log.push('ATIVOU_LOCAL'),localStorage:{setItem:(k,v)=>ls[k]=v},setTimeout:(f)=>f()};
  new Function(...Object.keys(ctx),src+';ctx.f=_jaAssineiPrestador;'.replace('ctx.f','this.f')).call(ctx,...Object.values(ctx));
  ctx.f('u','N','c'); await new Promise(r=>setImmediate(r)); await new Promise(r=>setImmediate(r)); return {log,ls};
}
(async()=>{
 let r=await run(false,()=>Promise.reject()); assert(r.log.some(x=>/em breve/.test(x))&&!r.log.includes('ATIVOU_LOCAL')&&!r.log.includes('abrirConversa')&&!Object.keys(r.ls).length,'1');
 r=await run(true,()=>Promise.resolve({status:'authorized'})); assert(r.log.includes('abrirConversa')&&!r.log.includes('ATIVOU_LOCAL')&&!Object.keys(r.ls).length,'2');
 r=await run(true,()=>Promise.resolve({status:'pending'})); assert(r.log.includes('upsell')&&!r.log.includes('abrirConversa')&&!r.log.includes('ATIVOU_LOCAL'),'3');
 r=await run(true,()=>Promise.resolve({status:'none'})); assert(r.log.includes('upsell')&&!r.log.includes('abrirConversa'),'4');
 r=await run(true,()=>Promise.reject({codigo:'x'})); assert(r.log.some(x=>/Não foi possível/.test(x))&&r.log.includes('upsell')&&!r.log.includes('ATIVOU_LOCAL'),'5');
 console.log('JA-ASSINEI: 5/5 cenários OK');
})().catch(e=>{console.error('FALHOU',e.message);process.exit(1)});
