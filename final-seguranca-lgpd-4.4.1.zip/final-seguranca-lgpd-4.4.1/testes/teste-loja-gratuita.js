// 4.4 — gratuidade PERMANENTE das duas lojas anteriores à cobrança (SIMULADO: banco falso do servidor + regras v18.4 no avaliador local).
// Os negIds abaixo são FICTÍCIOS de teste (não são os UIDs reais; o administrador informa os reais ao script em produção).
const assert = require('assert'), fs = require('fs'), path = require('path');
const { rulesUnitTesting, firestoreMod } = require('./regras/avaliador-local/firebase-falso.js');
const { doc, setDoc, updateDoc } = firestoreMod;
const L = require('../functions/loja-lib.js'), MG = require('../migracao/marcar-loja-gratuita.js'), DL = require('../migracao/decidir-loja.js'), AL = require('../migracao/autorizar-loja.js');
let n = 0, f = 0; const ok = async (nome, fn) => { try { await fn(); n++; console.log('OK     | ' + nome); } catch (e) { f++; console.log('FALHOU | ' + nome + ' -> ' + (e.message || e).split('\n')[0]); } };
const T = (s) => Date.parse(s);
const S = {}; let audit = 0;
const fdb = { collection: (c) => ({
  doc: (i) => ({ id: i, get: async () => ({ exists: S[c + '/' + i] !== undefined, data: () => S[c + '/' + i], id: i }), set: async (v, o) => { S[c + '/' + i] = Object.assign((o && o.merge && S[c + '/' + i]) || {}, v); } }),
  add: async (v) => { audit++; S[c + '/auto' + audit] = v; return { id: 'auto' + audit }; },
  get: async () => { const docs = Object.keys(S).filter((k) => k.startsWith(c + '/')).map((k) => ({ id: k.split('/')[1], data: () => S[k] })); return { docs, forEach: (g) => docs.forEach(g) }; } }) };
const vitrine = (negId, agora) => (S['negocios/' + negId].publicaAte || 0) > agora && S['negocios/' + negId].ativo !== false;
const A = 'AntigaTenis01', B = 'AntigaFrila02', N = 'NovaLoja0003', NB = 'neg_' + B, NN = 'neg_' + N;
const ANTES_A = { uid: A, nome: 'Tênis Life', servicos: ['Tênis R$199'], fotos: ['f1'], avaliacao: 4.8, avaliacoes: 12, desc: 'x' };
const ANTES_B = { uid: B, nome: 'Loja FrilaOne', servicos: ['Camiseta R$49'], fotos: ['f2'], avaliacao: 5, avaliacoes: 3, desc: 'y' };
const reset = () => { Object.keys(S).forEach((k) => delete S[k]); audit = 0; S['usuarios/' + N] = { nome: 'Novo' }; S['negocios/neg_' + A] = JSON.parse(JSON.stringify(ANTES_A)); S['negocios/' + NB] = JSON.parse(JSON.stringify(ANTES_B)); };
const AG1 = T('2026-10-20T12:00:00-03:00'), DEPOIS = T('2026-12-15T12:00:00-03:00'), MUITO_DEPOIS = T('2035-01-10T12:00:00-03:00');
const aprova = (negId, agora) => L.decidir({ db: fdb, negId, decisao: 'aprovar', adminUid: 'ADM', agora });
const NA2 = 'neg_' + A;

(async () => {
  const env = await rulesUnitTesting.initializeTestEnvironment({ projectId: 'x', firestore: { rules: fs.readFileSync(path.join(__dirname, '../firestore-regras-v18.4.txt'), 'utf8') } });
  const tenta = (fn) => fn().then(() => true, (e) => { if (e.code === 'permission-denied') return false; throw e; });
  const cli = (u, claims) => env.authenticatedContext(u, claims || {}).firestore();

  await ok('1a. as duas lojas antigas, marcadas e aprovadas, ficam visíveis HOJE, após 01/12/2026 e em 2035 SEM nenhum pagamento', async () => {
    reset(); const r = await MG.executar({ db: fdb, negIds: [NA2, NB], exec: true, confirmo: true, agora: AG1 }); assert(!r.erro, r.erro);
    await aprova(NA2, AG1); await aprova(NB, AG1);
    for (const g of [AG1, DEPOIS, MUITO_DEPOIS]) { assert(vitrine(NA2, g) && vitrine(NB, g), 'sumiu da vitrine em ' + new Date(g).toISOString()); }
    assert.equal(S['negocios/' + NB].publicaAte, L.PERMANENTE); assert(!S['lojas_autorizadas/' + A], 'a gratuidade não pode fingir pagamento');
  });
  await ok('1b. dados e estado preservados (nome, serviços, fotos, avaliação); só campos de aprovação/publicação são acrescentados', async () => {
    reset(); await MG.executar({ db: fdb, negIds: [NA2, NB], exec: true, confirmo: true, agora: AG1 }); await aprova(NA2, AG1);
    for (const k of Object.keys(ANTES_A)) assert.deepEqual(S['negocios/' + NA2][k], ANTES_A[k], 'alterou ' + k);
    assert.deepEqual(Object.keys(S['negocios/' + NA2]).filter((k) => !(k in ANTES_A)).sort(), ['aprovacaoEm', 'aprovacaoMotivo', 'aprovacaoPor', 'aprovacaoStatus', 'publicaAte']);
    assert.equal(S['lojas_gratuitas/' + A].negId, NA2);
  });
  await ok('1c. a ordem não importa: aprovar primeiro e marcar depois também publica sem fim (marcar recalcula a loja já aprovada)', async () => {
    reset(); await aprova(NB, AG1); assert.equal(S['negocios/' + NB].publicaAte, T('2026-11-30T23:59:59-03:00'));
    const r = await MG.executar({ db: fdb, negIds: [NB], exec: true, confirmo: true, agora: AG1 }); assert(!r.erro);
    assert.equal(S['negocios/' + NB].publicaAte, L.PERMANENTE); assert(vitrine(NB, MUITO_DEPOIS));
  });
  await ok('1d. gratuidade NÃO é aprovação: loja gratuita sem aprovação (ou recusada/pendência) não aparece', async () => {
    reset(); await MG.executar({ db: fdb, negIds: [NA2, NB], exec: true, confirmo: true, agora: AG1 });
    assert(!vitrine(NA2, AG1), 'loja antiga sem status apareceu'); const r = await L.decidir({ db: fdb, negId: NA2, decisao: 'recusar', motivo: 'm', adminUid: 'ADM', agora: AG1 });
    assert.equal(r.publicaAte, 0); assert(!vitrine(NA2, AG1)); const p = await L.decidir({ db: fdb, negId: NB, decisao: 'pendencia', motivo: 'm', adminUid: 'ADM', agora: AG1 }); assert.equal(p.publicaAte, 0);
  });
  await ok('2. loja NOVA nasce pendente: não aparece, não abre pelo cliente, e não se aprova sozinha (regras v18.4)', async () => {
    reset(); await env.withSecurityRulesDisabled(async (ctx) => { await setDoc(doc(ctx.firestore(), 'usuarios/' + N), { nome: 'Novo', tipo: 'negocio' }); });
    assert.equal(await tenta(() => setDoc(doc(cli(N), 'negocios/' + NN), { uid: N, nome: 'Tênis Life', aprovacaoStatus: 'aprovada', publicaAte: L.PERMANENTE })), false, 'criou já aprovada');
    assert.equal(await tenta(() => setDoc(doc(cli(N), 'negocios/' + NN), { uid: N, nome: 'Tênis Life', servicos: ['x'], aprovacaoStatus: 'pendente' })), true);
    S['negocios/' + NN] = { uid: N, nome: 'Tênis Life', aprovacaoStatus: 'pendente' }; assert(!vitrine(NN, AG1));
    assert.equal(await tenta(() => updateDoc(doc(cli(N), 'negocios/' + NN), { aprovacaoStatus: 'aprovada' })), false);
    assert.equal(await tenta(() => setDoc(doc(cli(N), 'disponiveis/' + N), { uid: N, nome: 'L', categoria: 'negocio', ts: new Date() })), false);
  });
  await ok('3a. loja nova NÃO recebe gratuidade: usuário e administrador pelo cliente não escrevem lojas_gratuitas (nem a própria)', async () => {
    reset();
    assert.equal(await tenta(() => setDoc(doc(cli(N), 'lojas_gratuitas/' + N), { negId: NN, permanente: true })), false);
    assert.equal(await tenta(() => setDoc(doc(cli(N, { admin: true }), 'lojas_gratuitas/' + N), { negId: NN, permanente: true })), false);
    assert.equal(await tenta(() => setDoc(doc(cli(A), 'lojas_gratuitas/' + A), { negId: NA2, permanente: false })), false, 'dono antigo mexeu na própria gratuidade');
    assert.equal(await tenta(() => updateDoc(doc(cli(A), 'negocios/' + NA2), { publicaAte: L.PERMANENTE })), false);
  });
  await ok('3b. mesmo nome/dados das lojas antigas não dão gratuidade; aprovada e sem pagamento some após a campanha; com pagamento vale só até a data paga', async () => {
    reset(); S['negocios/' + NN] = { uid: N, nome: 'Tênis Life', servicos: ['x'], aprovacaoStatus: 'pendente', criado: 1 };
    await MG.executar({ db: fdb, negIds: [NA2, NB], exec: true, confirmo: true, agora: AG1 });
    const r = await aprova(NN, AG1); assert.equal(r.gratuita, false); assert.equal(S['negocios/' + NN].publicaAte, T('2026-11-30T23:59:59-03:00'));
    assert(vitrine(NN, AG1) && !vitrine(NN, DEPOIS), 'loja nova ficou grátis para sempre');
    await AL.executar({ db: fdb, uid: N, ate: '2027-06-30', exec: true, agora: DEPOIS }); assert(vitrine(NN, T('2027-06-01T12:00:00-03:00'))); assert(!vitrine(NN, T('2027-07-02T12:00:00-03:00')));
  });
  await ok('3c. gratuidade só vale para o negId gravado, permanente e não revogada (registro adulterado/outro negId/revogado é ignorado)', async () => {
    reset(); S['negocios/' + NN] = { uid: N, nome: 'X', aprovacaoStatus: 'pendente' };
    S['lojas_gratuitas/' + N] = { negId: 'neg_Outro123456', permanente: true }; assert.equal(await L.lojaGratuita(fdb, NN), false);
    S['lojas_gratuitas/' + N] = { negId: NN, permanente: false }; assert.equal(await L.lojaGratuita(fdb, NN), false);
    S['lojas_gratuitas/' + N] = { negId: NN, permanente: true, revogadaEm: 5 }; assert.equal(await L.lojaGratuita(fdb, NN), false);
    delete S['lojas_gratuitas/' + N]; assert.equal(await L.lojaGratuita(fdb, NN), false);
  });
  await ok('3d. script: simulação não grava; exige confirmação; recusa id inexistente/inconsistente; teto de 2 lojas (uma terceira é barrada)', async () => {
    reset(); S['negocios/' + NN] = { uid: N, nome: 'X', aprovacaoStatus: 'pendente' };
    let r = await MG.executar({ db: fdb, negIds: [NA2, NB], exec: false }); assert(r.simulacao && !r.erro && r.lojas.length === 2 && r.lojas[0].nome === 'Tênis Life'); assert(!S['lojas_gratuitas/' + A]);
    assert.equal((await MG.executar({ db: fdb, negIds: [NA2], exec: true })).erro, 'falta_confirmacao'); assert(!S['lojas_gratuitas/' + A]);
    assert(/loja_inexistente/.test((await MG.executar({ db: fdb, negIds: ['neg_Inexistente1'], exec: false })).erro));
    S['negocios/neg_Errada123456'] = { uid: 'OutroUid', nome: 'Z' }; assert(/loja_inconsistente/.test((await MG.executar({ db: fdb, negIds: ['neg_Errada123456'], exec: false })).erro));
    assert.equal((await MG.executar({ db: fdb, negIds: [], exec: true, confirmo: true })).erro, 'informe_os_negIds');
    await MG.executar({ db: fdb, negIds: [NA2, NB], exec: true, confirmo: true, agora: AG1 });
    r = await MG.executar({ db: fdb, negIds: [NN], exec: true, confirmo: true, agora: AG1 }); assert(/limite_excedido/.test(r.erro)); assert(!S['lojas_gratuitas/' + N], 'terceira loja ficou gratuita');
    await MG.executar({ db: fdb, negIds: [NA2], exec: true, confirmo: true, agora: AG1 });  // repetir é seguro
  });
  await ok('3e. revogar devolve a loja à regra normal (aprovação + cobrança) e recalcula; os dados continuam intactos', async () => {
    reset(); await MG.executar({ db: fdb, negIds: [NB], exec: true, confirmo: true, agora: AG1 }); await aprova(NB, AG1); assert(vitrine(NB, DEPOIS));
    const r = await MG.executar({ db: fdb, negIds: [NB], revogar: true, exec: true, confirmo: true, agora: AG1 }); assert(!r.erro);
    assert.equal(S['negocios/' + NB].publicaAte, T('2026-11-30T23:59:59-03:00')); assert(!vitrine(NB, DEPOIS)); assert.equal(S['negocios/' + NB].nome, 'Loja FrilaOne');
    await MG.executar({ db: fdb, negIds: [NB], exec: true, confirmo: true, agora: AG1 }); assert(vitrine(NB, DEPOIS), 'concessão após revogação não voltou a valer');
  });
  await ok('4. cobrança e aprovação são controles SEPARADOS (matriz): só aprovada+(gratuita|campanha|paga) publica', async () => {
    const C = T('2026-11-30T23:59:59-03:00'), P = T('2027-03-01T00:00:00-03:00');
    const caso = (st, pago, grat) => L.publicaAteDaLoja(st, pago, C, grat);
    assert.equal(caso('pendente', P, false), 0, 'paga mas não aprovada'); assert.equal(caso('recusada', P, true), 0, 'gratuita mas recusada');
    assert.equal(caso('pendencia', 0, true), 0); assert.equal(caso(undefined, P, true), 0, 'gratuita sem status');
    assert.equal(caso('aprovada', 0, false), C, 'aprovada sem pagar: só até o fim da campanha'); assert.equal(caso('aprovada', P, false), P);
    assert.equal(caso('aprovada', 0, true), L.PERMANENTE);
    // pelo fluxo real: pagar não aprova; aprovar não paga
    reset(); S['negocios/' + NN] = { uid: N, nome: 'N', aprovacaoStatus: 'pendente' }; await AL.executar({ db: fdb, uid: N, ate: '2027-06-30', exec: true, agora: DEPOIS });
    assert(!vitrine(NN, DEPOIS), 'pagamento aprovou a loja'); assert.equal(S['negocios/' + NN].aprovacaoStatus, 'pendente');
    await aprova(NN, DEPOIS); assert(vitrine(NN, DEPOIS));
  });
  console.log('\nLOJAS GRATUITAS 4.4 (simulado): ' + n + ' OK, ' + f + ' falharam'); process.exit(f ? 1 : 0);
})();
