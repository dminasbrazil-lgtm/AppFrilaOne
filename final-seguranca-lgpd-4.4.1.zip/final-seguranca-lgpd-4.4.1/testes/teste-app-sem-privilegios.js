// Verificação ESTÁTICA do app (rede de segurança além do teste no Chromium): nenhum ponto do código grava, no perfil público, campos que só o servidor decide.
// E: toda função chamada pelo app (_fnPost) existe no servidor, e toda função exportada que o app deveria usar é usada.
const fs = require('fs'), assert = require('assert'), path = require('path');
const h = fs.readFileSync(process.env.APP_HTML || path.join(__dirname, '../app/teste-final.html'), 'utf8');
let n = 0, f = 0; const t = (nome, fn) => { try { fn(); n++; console.log('OK     | ' + nome); } catch (e) { f++; console.log('FALHOU | ' + nome + ' -> ' + e.message.split('\n')[0]); } };
const linhas = h.split('\n');
const acha = (re) => linhas.map((l, i) => [i + 1, l]).filter(([, l]) => re.test(l) && !/^\s*(\/\/|\*)/.test(l));
t('nenhuma gravação de trial_fim/trial_inicio/trial_cod/trial_dias pelo app', () => { const a = acha(/\btrial_(fim|inicio|cod|dias)\s*:/); assert.equal(a.length, 0, JSON.stringify(a.slice(0, 3))); });
t('nenhuma gravação de verificado:true em usuarios pelo app', () => { const a = acha(/verificado\s*:\s*true/); assert.equal(a.length, 0, JSON.stringify(a.slice(0, 3))); });
t('nenhuma gravação de master_ativo:true em usuarios pelo app', () => { const a = acha(/master_ativo\s*:\s*true/); assert.equal(a.length, 0, JSON.stringify(a.slice(0, 3))); });
t('nenhuma gravação de nota própria (avaliacaoSoma/avaliacaoCount) em usuarios fora da transação de avaliação de outra pessoa', () => {
  const trechos = acha(/avaliacaoSoma\s*:/).map(([i]) => i); trechos.forEach((i) => { const ctx = linhas.slice(Math.max(0, i - 25), i + 3).join('\n'); assert(/tx\.set|transaction|avaliacoes_/i.test(ctx), 'linha ' + i + ' grava nota fora da avaliação'); }); });
t('o perfil público nunca recebe e-mail/CPF/contato de emergência (salvarPerfil/cadastro/Google)', () => {
  const bloco = (ini, fim) => { const a = h.indexOf(ini), b = h.indexOf(fim, a); assert(a > 0 && b > a, 'trecho não encontrado: ' + ini); return h.slice(a, b); };
  const cad = bloco("window._fb.salvarPerfil(user.uid,{", '}).catch(function(){});'); assert(!/email\s*:/.test(cad), 'cadastro grava email');
  const goo = bloco('var dadosGoogle = {', '};'); assert(!/email\s*:/.test(goo), 'Google grava email');
  const sp = bloco('function salvarPerfil(){', 'function '.concat('_').slice(0, 0) + 'var atendSel'); assert(!/dadosParaSalvar\.(email|emailContato|cpf|contatoEmergencia)\s*=/.test(sp), 'salvarPerfil grava dado privado no perfil'); });
const srv = fs.readFileSync(path.join(__dirname, '../functions/assinatura.js'), 'utf8');
const chamadas = [...new Set([...h.matchAll(/_fnPost\('([A-Za-z]+)'/g)].map((m) => m[1]))];
t('toda função chamada pelo app existe no servidor (' + chamadas.join(', ') + ')', () => { chamadas.forEach((c) => assert(new RegExp('exports\\.' + c + '\\s*=').test(srv), 'falta no servidor: ' + c)); assert(chamadas.length >= 7, 'esperava ao menos 7 chamadas'); });
t('o app não chama função inexistente nem usa links antigos de pagamento', () => { assert(!/mpago\.la/.test(h)); });
t('estágio é SEPARADO do "Tô disponível": nenhuma função de estágio toca em "disponiveis" e nenhuma gravação usa categoria "estagiario"', () => {
  assert.equal(acha(/categoria\s*:\s*['"]estagiario['"]/).length, 0, 'o app grava categoria estagiario');
  ['toggleEstOnline', 'cadastrarEstagiario', 'excluirCadastroEstagiario', '_estIniciarHeartbeat', '_iniciarListenerEstagiarios'].forEach((fn) => {
    const a = h.indexOf('function ' + fn + '('); assert(a > 0, 'não achei ' + fn); const corpo = h.slice(a, h.indexOf('\nfunction ', a + 10)).replace(/\/\/.*$/gm, '');   // sem comentários
    assert(!/disponiveis|_disponiveisUids|_pararHeartbeatPresenca|_iniciarHeartbeatPresenca/.test(corpo), fn + ' usa disponiveis/heartbeat do Tô disponível');
  });
});
t('o estágio não consulta a trava de assinatura (é gratuito e separado dos planos)', () => { const a = h.indexOf('function toggleEstOnline('); const corpo = h.slice(a, h.indexOf('\nfunction ', a + 10)).replace(/\/\/.*$/gm, ''); assert(!/_permitirAcaoPaga|_statusAssinaturaGeral/.test(corpo)); });
t('o app nunca grava aprovação/publicação de loja (aprovada, publicaAte, aprovacaoPor/Em/Motivo) — só o servidor decide', () => {
  assert.equal(acha(/(publicaAte|aprovacaoPor|aprovacaoEm|aprovacaoMotivo)\s*:/).length, 0, JSON.stringify(acha(/(publicaAte|aprovacaoPor|aprovacaoEm|aprovacaoMotivo)\s*:/).slice(0, 3)));
  assert.equal(acha(/aprovacaoStatus\s*[:=]\s*['"](aprovada|recusada|pendencia)['"]/).length, 0, 'o app grava status decidido pelo servidor');
});
t('a vitrine de lojas não usa mais ativo==true: filtra por publicaAte', () => { assert(/collection\('negocios'\)\.where\('publicaAte','>'/.test(h)); assert(!/collection\('negocios'\)\.where\('ativo'/.test(h)); });
t('nenhuma tela administrativa de aprovação de loja dentro da área do usuário', () => { assert(!/decidirLoja|aprovarLoja|painel-admin|lojas_decisoes/i.test(h), 'achei referência a aprovação administrativa no app'); });
console.log('\nAPP SEM PRIVILÉGIOS (estático): ' + n + ' OK, ' + f + ' falharam'); process.exit(f ? 1 : 0);
