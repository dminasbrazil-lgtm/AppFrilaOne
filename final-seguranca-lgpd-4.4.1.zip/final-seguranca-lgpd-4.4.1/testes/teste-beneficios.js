// Testa preservar-beneficios-codigos.js e conceder-acesso-manual.js com firebase-admin FALSO (nenhum dado real). Rodar: node teste-beneficios.js
const Module=require('module'),assert=require('assert'),path=require('path'),fs0=require('fs'),os=require('os');
const T=(s)=>Date.parse(s);
function rodar(arquivo,args,S){
  const mkRef=(col,id)=>({id,get:async()=>({exists:S[col+'/'+id]!==undefined,data:()=>S[col+'/'+id]}),set:async(v,o)=>{S[col+'/'+id]=Object.assign((o&&o.merge&&S[col+'/'+id])||{},v)}});
  const fs={collection:(col)=>({doc:(id)=>mkRef(col,id),get:async()=>{ const docs=Object.keys(S).filter(k=>k.startsWith(col+'/')).map(k=>({id:k.split('/')[1],data:()=>S[k]})); return {forEach:(f)=>docs.forEach(f),docs}; }, where:(f,o,v)=>({get:async()=>{ const docs=Object.keys(S).filter(k=>k.startsWith(col+'/')&&S[k][f]===v).map(k=>({id:k.split('/')[1],data:()=>S[k]})); return {forEach:(fn)=>docs.forEach(fn),docs,size:docs.length}; }})})};
  const admin={initializeApp(){},firestore:Object.assign(()=>fs,{})};
  const orig=Module._load; Module._load=function(r,...a){ if(r==='firebase-admin') return admin; return orig.call(this,r,...a)};
  const out=[]; const ol=console.log; console.log=(...x)=>out.push(x.join(' '));
  const oe=process.exit; let code=0; process.exit=(c)=>{code=c||0};
  process.argv=['node',arquivo,...args];
  delete require.cache[require.resolve(arquivo)]; Module._load(arquivo,null,true);
  return new Promise(r=>setTimeout(()=>{console.log=ol;process.exit=oe;Module._load=orig;r({out:out.join('\n'),code})},300));
}
const banco=()=>({
  'usuarios/u1':{trial_cod:'MN-AAAAAA',trial_fim:T('2026-12-20T12:00:00-03:00')},
  'usuarios/u2':{trial_cod:'AUTO',trial_fim:T('2026-12-30T12:00:00-03:00')},
  'usuarios/u3':{trial_cod:'GP-BBBBBB',trial_fim:T('2026-11-10T12:00:00-03:00')},
  'usuarios/u4':{trial_cod:'CV-00001',trial_fim:T('2026-01-10T12:00:00-03:00')},
  'usuarios/u5':{nome:'sem trial'},
  'assinaturas/u1':{codigoFim:T('2027-01-15T12:00:00-03:00')}
});
(async()=>{
  const P=path.join(__dirname,'../migracao/preservar-beneficios-codigos.js'), M=path.join(__dirname,'../migracao/conceder-acesso-manual.js');
  let S=banco(); let r=await rodar(P,[],S);
  assert(/benefícios por código ainda válidos: 1/.test(r.out)&&/u1/.test(r.out)&&!/u2|u3|u4|u5/.test(r.out)); assert.equal(S['assinaturas/u1'].codigoFim,T('2027-01-15T12:00:00-03:00')); assert(!S['assinaturas/u2']); console.log('OK | simulação lista só quem tem código válido além de 30/11/2026 e não grava nada');
  S=banco(); r=await rodar(P,['--todos'],S); assert(/: 2/.test(r.out)&&/u3/.test(r.out)); console.log('OK | --todos inclui também o que termina antes de 30/11 (u3), mas ignora AUTO e vencidos');
  S=banco(); S['usuarios/u6']={trial_cod:'MN-CCCCCC',trial_fim:T('2026-12-22T12:00:00-03:00')}; r=await rodar(P,['--executar'],S);
  assert.equal(S['assinaturas/u1'].codigoFim,T('2027-01-15T12:00:00-03:00'),'não diminui o que já existe'); assert.equal(S['assinaturas/u6'].codigoFim,T('2026-12-22T12:00:00-03:00')); assert(S['assinaturas/u6'].acessoValidoAte>0); assert(!S['assinaturas/u2']&&!S['assinaturas/u4']); assert.equal(S['usuarios/u1'].trial_cod,'MN-AAAAAA','não altera usuarios'); console.log('OK | --executar grava codigoFim sem diminuir, não mexe em usuarios e não cria acesso para AUTO/vencidos');
  // acesso manual: exige número do pagamento
  const f=path.join(os.tmpdir(),'pag-teste.json');
  fs0.writeFileSync(f,JSON.stringify([{uid:'p1',plano:'master',ate:'2027-01-31',idPagamentoMP:'123456789',motivo:'link antigo'},{uid:'p2',plano:'master',ate:'2027-01-31',motivo:'só disse que pagou'},{uid:'p3',plano:'ouro',ate:'2027-01-31',idPagamentoMP:'1'}]));
  S={}; r=await rodar(M,[f],S); assert(/validos: 1|"validos":1|validos.*1/i.test(r.out)||/1/.test(r.out)); assert(!S['assinaturas/p1']); console.log('OK | simulação não grava');
  S={}; r=await rodar(M,[f,'--executar','--sem-verificar-mp'],S); assert.equal(S['assinaturas/p1'].manualPlano,'master'); assert.equal(S['assinaturas/p1'].manualRefPagamento,'123456789'); assert(!S['assinaturas/p2'],'sem número do pagamento NÃO concede'); assert(!S['assinaturas/p3'],'plano inválido não concede'); console.log('OK | só concede com número do pagamento e plano válido');
  console.log('\nBENEFÍCIOS: 5/5 OK');
})().catch(e=>{console.error('FALHOU',e.message);process.exit(1)});
