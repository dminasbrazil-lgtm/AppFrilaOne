// Aceite dos Termos: (A) servidor registrarAceite com Firebase falso; (B) telas no Chromium real (links do cadastro e aceite do Google).
const Module=require('module'),assert=require('assert'),fs=require('fs'),path=require('path');
let ok=0,bad=0;const T=(n,f)=>Promise.resolve().then(f).then(()=>{ok++;console.log('OK     | '+n)},e=>{bad++;console.log('FALHOU | '+n+' -> '+e.message)});
// ---------- A) servidor
const store={},ev=[];
const FV={serverTimestamp:()=>'TS',delete:()=>({__del:true})};
function docRef(c,i){return {get:async()=>({exists:!!store[c+'/'+i],data:()=>store[c+'/'+i]}),set:async(v,o)=>{store[c+'/'+i]=Object.assign((o&&o.merge&&store[c+'/'+i])||{},v)},_p:c+'/'+i,collection:s=>({doc:()=>({_ev:true,_uid:i})})}}
const fakeAdmin={initializeApp(){},auth:()=>({verifyIdToken:async t=>{if(t==='tokA')return{uid:'A'};if(t==='tokB')return{uid:'B'};throw new Error('x')}}),firestore:Object.assign(()=>({collection:c=>({doc:i=>docRef(c,i)}),batch:()=>{const ops=[];return {set:(r,v,o)=>{ops.push([r,v,o])},commit:async()=>{if(global.__falhaLote)throw new Error('lote falhou');ops.forEach(([r,v,o])=>{if(r._ev)ev.push({uid:r._uid,v});else store[r._p]=Object.assign((o&&o.merge&&store[r._p])||{},v)})}}}}),{FieldValue:FV})};
const fakeFns={runWith:()=>({region:()=>({https:{onRequest:h=>h}})})};
const orig=Module._load;Module._load=function(r,...a){if(r==='firebase-functions/v1')return fakeFns;if(r==='firebase-admin')return fakeAdmin;return orig.call(this,r,...a)};
const A=require('../functions/assinatura.js');
const mkres=()=>{const r={code:200,body:null};r.status=c=>{r.code=c;return r};r.json=b=>{r.body=b;return r};r.send=b=>{r.body=b;return r};r.set=()=>{};return r};
const call=async(body,tok,method='POST')=>{const rs=mkres();await A.registrarAceite({method,headers:{authorization:tok?'Bearer '+tok:'',origin:'https://frilaone.com.br','user-agent':'UA-teste'},body,query:{}},rs);return rs};
const V={termosVersao:'1.1',privacidadeVersao:'1.1'};
(async()=>{
await T('sem login → 401, nada gravado',async()=>{const r=await call({acao:'cadastro_email',...V},null);assert.equal(r.code,401);assert(!store['aceites_termos/A'])});
await T('token inválido → 401',async()=>{assert.equal((await call({acao:'cadastro_email',...V},'lixo')).code,401)});
await T('GET → 405',async()=>{assert.equal((await call({},'tokA','GET')).code,405)});
await T('ação inválida → 400',async()=>{const r=await call({acao:'x',...V},'tokA');assert.equal(r.code,400);assert(!store['aceites_termos/A'])});
await T('versão desatualizada/inventada → 409, nada gravado',async()=>{let r=await call({acao:'cadastro_email',termosVersao:'0.9',privacidadeVersao:'1.1'},'tokA');assert.equal(r.code,409);r=await call({acao:'cadastro_email'},'tokA');assert.equal(r.code,409);assert(!store['aceites_termos/A'])});
await T('aceite válido grava versões, ação, data do servidor e histórico na conta DO TOKEN',async()=>{const r=await call({acao:'cadastro_google',...V},'tokA');assert(r.body.ok);const d=store['aceites_termos/A'];assert.equal(d.termosVersao,'1.1');assert.equal(d.privacidadeVersao,'1.1');assert.equal(d.aceitoEm,'TS');assert.equal(d.acao,'cadastro_google');assert.equal(ev.length,1);assert.equal(ev[0].uid,'A')});
await T('falha ao gravar: responde 500 e não grava nada pela metade',async()=>{global.__falhaLote=true;const antes=ev.length,a=JSON.stringify(store['aceites_termos/A']);const r=await call({acao:'reaceite',...V},'tokA');global.__falhaLote=false;assert.equal(r.code,500);assert.equal(ev.length,antes);assert.equal(JSON.stringify(store['aceites_termos/A']),a)});
await T('uid no corpo é ignorado: não dá para registrar aceite para outra conta',async()=>{await call({acao:'cadastro_email',uid:'B',...V},'tokA');assert(!store['aceites_termos/B']);await call({acao:'reaceite',...V},'tokB');assert(store['aceites_termos/B'])});
await T('não grava consentimentos específicos (só termos + ciência da política)',async()=>{const k=Object.keys(store['aceites_termos/A']).sort().join(',');assert.equal(k,'acao,aceitoEm,agente,origem,privacidadeVersao,termosVersao')});
// ---------- B) Chromium
let chromium;try{chromium=require('/opt/npm-tools/node_modules/playwright-core').chromium}catch(e){try{chromium=require('playwright').chromium}catch(e2){}}
if(!chromium){console.log('PULADO | testes de tela: Playwright indisponível');}
else{
 const html=fs.readFileSync(path.join(__dirname,'../app/teste-final.html'),'utf8');
 const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium-1194/chrome-linux/chrome',args:['--no-sandbox']});
 const pg=await (await b.newContext({viewport:{width:390,height:800}})).newPage();
 await pg.route('**/*',r=>{const u=r.request().url();if(u==='https://x.test/')return r.fulfill({status:200,contentType:'text/html',body:html});return r.abort()});
 await pg.goto('https://x.test/',{waitUntil:'domcontentloaded'});await pg.waitForTimeout(1500);
 await T('P1: link "Termos de Uso" do cadastro abre o texto, sem marcar o aceite e sem apagar campos',async()=>{
  const r=await pg.evaluate(()=>{ if(typeof setAuthMode==='function'){try{setAuthMode('register')}catch(e){}} document.getElementById('reg-terms').style.display='block';
   const e=document.getElementById('inp-email'); if(e) e.value='teste@x.com';
   const before=termsOk; const sp=document.querySelector('#reg-terms [data-doc="termos"]'); sp.click();
   const bg=document.getElementById('cfg-termos-bg'); return {before,after:termsOk,aberto:getComputedStyle(bg).display!=='none',email:e&&e.value}});
  assert.equal(r.before,false);assert.equal(r.after,false);assert(r.aberto,'modal dos Termos não abriu');assert.equal(r.email,'teste@x.com')});
 await T('P1: link "Política de Privacidade" abre a política',async()=>{
  const r=await pg.evaluate(()=>{document.getElementById('cfg-termos-bg').style.display='none';document.querySelector('#reg-terms [data-doc="privacidade"]').click();return {a:getComputedStyle(document.getElementById('cfg-privacidade-bg')).display!=='none',t:termsOk}});
  assert(r.a);assert.equal(r.t,false)});
 await T('P1: clicar fora dos links continua marcando/desmarcando o aceite',async()=>{
  const r=await pg.evaluate(()=>{document.getElementById('cfg-privacidade-bg').style.display='none';const a=termsOk;document.getElementById('terms-box').click();return {a,b:termsOk}});
  assert.equal(r.a,false);assert.equal(r.b,true)});
 await T('P1: nenhum "em breve" restante nos links de Termos/Política',async()=>{assert(!/Termos em breve|Pol[ií]tica em breve/.test(html))});
 // P2: tela de aceite do Google (usuário e firebase simulados)
 await T('P2: tela do Google — botão bloqueado até marcar; links abrem os textos acima da tela; marcar libera',async()=>{
  const r=await pg.evaluate(()=>{window.__calls=[];window.firebase=Object.assign(window.firebase||{},{auth:()=>({currentUser:{uid:'G1',delete:()=>{window.__calls.push('delete');return Promise.resolve()},}}),firestore:()=>({collection:c=>({doc:i=>({delete:()=>{window.__calls.push('del:'+c+'/'+i);return Promise.resolve()}})})})});
   window._entrarNoApp=function(){window.__calls.push('entrou')};window._fnPost=function(n,c){window.__calls.push('fn:'+n+':'+c.acao);return Promise.resolve({ok:true})};window._registrarIndicacaoSeHouver=function(){window.__calls.push('indic')};
   _mostrarAceiteGoogle({uid:'G1',displayName:'Fulano'});const ok=document.getElementById('aceite-google-ok');const d0=ok.disabled;
   document.querySelector('#aceite-google-bg [data-doc="termos"]').click();const z=+getComputedStyle(document.getElementById('cfg-termos-bg')).zIndex>+getComputedStyle(document.getElementById('aceite-google-bg')).zIndex;const marcadoDepoisLink=ok.disabled;
   document.getElementById('aceite-google-chk').click();return {d0,marcadoDepoisLink,z,d1:ok.disabled,calls:window.__calls.slice()}});
  assert.equal(r.d0,true);assert.equal(r.marcadoDepoisLink,true);assert(r.z);assert.equal(r.d1,false);assert.deepEqual(r.calls,[])});
 await T('P2: "Aceitar e continuar" registra o aceite no servidor, registra indicação e só então entra no app',async()=>{
  const r=await pg.evaluate(()=>{document.getElementById('aceite-google-ok').click();return {calls:window.__calls.slice(),tela:!!document.getElementById('aceite-google-bg')}});
  assert.deepEqual(r.calls,['indic','fn:registrarAceite:cadastro_google','entrou']);assert.equal(r.tela,false)});
 await T('P2: "Não aceito" cancela a conta do login (o servidor limpa o perfil) e não entra no app',async()=>{
  await pg.evaluate(()=>{sessionStorage.setItem('c','');const P=x=>sessionStorage.setItem('c',sessionStorage.getItem('c')+x+';');
   localStorage.setItem('frilaone_aceite_gate','G1');
   window.firebase=Object.assign(window.firebase||{},{auth:()=>({currentUser:{uid:'G1',delete:()=>{P('delete');return Promise.resolve()}}})});
   window._entrarNoApp=function(){P('entrou')};
   _mostrarAceiteGoogle({uid:'G1'});document.getElementById('aceite-google-no').click();});
  await pg.waitForTimeout(800);
  const c=await pg.evaluate(()=>sessionStorage.getItem('c'));
  assert(c.includes('delete'),c);assert(!c.includes('entrou'),c)});
 await T('P2: se o cancelamento falhar, a tela continua, a marca de pendência fica e o app não abre',async()=>{
  const r=await pg.evaluate(()=>new Promise(res=>{localStorage.setItem('frilaone_aceite_gate','G2');const P=[];
   window.firebase=Object.assign(window.firebase||{},{auth:Object.assign(()=>({currentUser:{uid:'G2',delete:()=>Promise.reject({code:'auth/network-request-failed'})}}),{GoogleAuthProvider:function(){}})});
   window._entrarNoApp=function(){P.push('entrou')};
   const old=document.getElementById('aceite-google-bg');if(old)old.remove();
   _mostrarAceiteGoogle({uid:'G2'});document.getElementById('aceite-google-no').click();
   setTimeout(()=>res({P,tela:!!document.getElementById('aceite-google-bg'),gate:localStorage.getItem('frilaone_aceite_gate'),btn:document.getElementById('aceite-google-no').disabled}),400)}));
  assert.deepEqual(r.P,[]);assert(r.tela);assert.equal(r.gate,'G2');assert.equal(r.btn,false)});
 await T('P2: login antigo (requires-recent-login) → pede confirmação ao Google e cancela',async()=>{
  await pg.evaluate(()=>{sessionStorage.setItem('c','');const P=x=>sessionStorage.setItem('c',sessionStorage.getItem('c')+x+';');let n=0;
   const cu={uid:'G3',delete:()=>{n++;return n===1?Promise.reject({code:'auth/requires-recent-login'}):(P('apagou'),Promise.resolve())},reauthenticateWithPopup:()=>{P('reauth');return Promise.resolve()}};
   window.firebase=Object.assign(window.firebase||{},{auth:Object.assign(()=>({currentUser:cu}),{GoogleAuthProvider:function(){}})});
   const old=document.getElementById('aceite-google-bg');if(old)old.remove();
   _mostrarAceiteGoogle({uid:'G3'});document.getElementById('aceite-google-no').click();});
  await pg.waitForTimeout(800);
  assert.equal(await pg.evaluate(()=>sessionStorage.getItem('c')),'reauth;apagou;')});
 // ---- fluxos de autenticação reais do app (loginGoogle) com Firebase simulado
 const gtest=(novo)=>pg.evaluate((novo)=>new Promise(res=>{
   const P=[];const old=document.getElementById('aceite-google-bg');if(old)old.remove();localStorage.removeItem('frilaone_aceite_gate');
   window._fbReady=true;window.firebase=Object.assign(window.firebase||{},{firestore:Object.assign(()=>({}),{FieldValue:{serverTimestamp:()=>'TS'}})});
   window._fb={loginGoogle:()=>Promise.resolve({uid:'GX',email:'g@x.com',displayName:'Gui',photoURL:'',_frilaIsNewUser:novo}),salvarPerfil:()=>Promise.resolve()};
   window._entrarNoApp=function(){P.push('entrou')};window._registrarIndicacaoSeHouver=function(){P.push('indic')};
   loginGoogle();
   setTimeout(()=>res({P,tela:!!document.getElementById('aceite-google-bg'),gate:localStorage.getItem('frilaone_aceite_gate')}),300)}),novo);
 await T('LOGIN Google de conta NOVA: mostra aceite, não entra e não registra indicação antes de aceitar',async()=>{const r=await gtest(true);assert.deepEqual(r.P,[]);assert(r.tela);assert.equal(r.gate,'GX')});
 await T('LOGIN Google de conta EXISTENTE: entra direto, sem tela de aceite e sem marca de pendência',async()=>{const r=await gtest(false);assert.deepEqual(r.P,['entrou']);assert(!r.tela);assert.equal(r.gate,null)});
 await T('Falha temporária do servidor no aceite: não trava o app e deixa lembrete; novo acesso tenta de novo',async()=>{
  const r=await pg.evaluate(()=>new Promise(res=>{const calls=[];localStorage.removeItem('frilaone_aceite_reg_pend');let falha=true;
   window._fnPost=function(n,c){calls.push(n+':'+c.acao+':'+(falha?'falha':'ok'));return falha?Promise.reject({codigo:'http_503'}):Promise.resolve({ok:true})};
   window.firebase=Object.assign(window.firebase||{},{auth:()=>({currentUser:{uid:'U7'}})});
   _registrarAceite('cadastro_email','U7');
   setTimeout(()=>{const pend=localStorage.getItem('frilaone_aceite_reg_pend');falha=false;_aceitePosLogin();
    setTimeout(()=>res({calls,pend,depois:localStorage.getItem('frilaone_aceite_reg_pend')}),200)},200)}));
  assert.deepEqual(r.calls,['registrarAceite:cadastro_email:falha','registrarAceite:cadastro_email:ok']);assert(r.pend);assert.equal(r.depois,null)});
 await T('Lembrete de OUTRA conta não é enviado em nome da conta atual',async()=>{
  const r=await pg.evaluate(()=>new Promise(res=>{const calls=[];localStorage.setItem('frilaone_aceite_reg_pend',JSON.stringify({uid:'OUTRO',acao:'cadastro_email'}));
   window._fnPost=function(n,c){calls.push(n);return Promise.resolve({ok:true})};
   window.firebase=Object.assign(window.firebase||{},{auth:()=>({currentUser:{uid:'U8'}})});_aceitePosLogin();setTimeout(()=>res(calls),150)}));
  assert.deepEqual(r,[])});
 // ---- Profissional não aprovado (regras v17): mensagem em vez de tela vazia
 await T('Profissional ainda não aprovado: a consulta de pedidos é negada e o app mostra "em análise" (sem quebrar)',async()=>{
  const r=await pg.evaluate(()=>new Promise(res=>{
   let box=document.getElementById('agendamentos-pendentes-box');if(!box){box=document.createElement('div');box.id='agendamentos-pendentes-box';document.body.appendChild(box);}
   window._fbUID='PX';window._fbDb={collection:()=>({where:()=>({where:()=>({get:()=>Promise.reject({code:'permission-denied'})})})})};
   window._fb=Object.assign(window._fb||{},{carregarPerfil:()=>Promise.resolve({cadMaster:{area:'psicologo',preco:'100'}})});
   window.firebase=Object.assign(window.firebase||{},{auth:()=>({currentUser:{uid:'PX'}})});
   _carregarAgendamentosPendentes();setTimeout(()=>res({txt:box.textContent,disp:box.style.display}),300)}));
  assert(/em análise/.test(r.txt),r.txt);assert.equal(r.disp,'block')});
 await b.close();
}
console.log('\nACEITE: '+ok+' OK, '+bad+' falharam');process.exit(bad?1:0);
})();
