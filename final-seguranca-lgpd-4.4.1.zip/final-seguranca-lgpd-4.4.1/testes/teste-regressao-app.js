// Regressão do APP no Chromium real, nos DOIS modos (servidor desligado = hoje; servidor ligado = _ASSINATURA_ATIVA=true).
// Um banco FALSO registra tudo que o app tenta gravar; as funções do servidor também são falsas. Nada de rede, nada de produção.
// Confere: (1) o cliente nunca grava trial_*, verificado:true, master_ativo:true, plano pago, e-mail/CPF no perfil público;
//          (2) com o servidor ligado, os fluxos chamam as funções certas; (3) cadastro/recuperar senha/perfil continuam funcionando.
const assert = require('assert'), fs = require('fs'), path = require('path');
let ok = 0, bad = 0;
const T = (n, f) => Promise.resolve().then(f).then(() => { ok++; console.log('OK     | ' + n); }, (e) => { bad++; console.log('FALHOU | ' + n + ' -> ' + e.message.split('\n')[0]); });
let chromium; try { chromium = require('/opt/npm-tools/node_modules/playwright-core').chromium; } catch (e) { try { chromium = require('playwright').chromium; } catch (e2) {} }
if (!chromium) { console.log('PULADO | Playwright indisponível neste computador'); process.exit(0); }
const HTML0 = fs.readFileSync(process.env.APP_HTML || path.join(__dirname, '../app/teste-final.html'), 'utf8');
const PROIBIDO = ['trial_fim', 'trial_inicio', 'trial_cod', 'trial_dias', 'avaliacaoSoma', 'avaliacaoCount'];

async function abrir(browser, servidorLigado) {
  const html = servidorLigado ? HTML0.replace('var _ASSINATURA_ATIVA = false;', 'var _ASSINATURA_ATIVA = true;') : HTML0;
  assert(servidorLigado ? /var _ASSINATURA_ATIVA = true;/.test(html) : /var _ASSINATURA_ATIVA = false;/.test(html), 'não achei a chave do app');
  const pg = await (await browser.newContext({ viewport: { width: 390, height: 800 } })).newPage();
  await pg.route('**/*', (r) => { const u = r.request().url(); if (u === 'https://x.test/') return r.fulfill({ status: 200, contentType: 'text/html', body: html }); return r.abort(); });
  await pg.goto('https://x.test/', { waitUntil: 'domcontentloaded' }); await pg.waitForTimeout(1200);
  await pg.evaluate(() => {
    window.__w = []; window.__fn = []; window.__toast = [];
    const FV = { serverTimestamp: () => 'TS', increment: (n) => ({ inc: n }), delete: () => ({ __del: true }), arrayUnion: (...a) => ({ union: a }) };
    const snap = () => Promise.resolve({ exists: false, data: () => ({}), forEach() {}, empty: true, docs: [] });
    function dref(p) { return { id: p.split('/').pop(), set: (d, o) => { __w.push({ op: 'set', path: p, data: d, merge: !!(o && o.merge) }); if (window.__negarDisp && /^disponiveis\//.test(p)) return Promise.reject(new Error('permission-denied')); return Promise.resolve(); }, update: (d) => { __w.push({ op: 'update', path: p, data: d }); return Promise.resolve(); },
      delete: () => { __w.push({ op: 'delete', path: p }); return Promise.resolve(); }, get: snap, onSnapshot: () => () => {}, collection: (c) => cref(p + '/' + c) }; }
    function cref(p) { const q = { doc: (id) => dref(p + '/' + (id || 'auto')), add: (d) => { __w.push({ op: 'add', path: p, data: d }); return Promise.resolve({ id: 'auto' }); }, get: snap, onSnapshot: () => () => {} };
      ['where', 'orderBy', 'limit'].forEach((m) => { q[m] = (...a) => { if (m === 'where') (window.__where = window.__where || []).push([p].concat(a)); return q; }; }); return q; }
    const cu = { uid: 'U1', email: 'u1@x.com', getIdToken: () => Promise.resolve('tok'), displayName: 'U1' };
    window.firebase = Object.assign(window.firebase || {}, { auth: () => ({ currentUser: cu }), firestore: Object.assign(() => ({ collection: (c) => cref(c) }), { FieldValue: FV }) });
    window._fbDb = firebase.firestore(); window._fbUID = 'U1'; window._fbReady = true;
    window._fb = Object.assign(window._fb || {}, {
      salvarPerfil: (uid, d) => { __w.push({ op: 'set', path: 'usuarios/' + uid, data: d, via: '_fb.salvarPerfil' }); return Promise.resolve(); },
      atualizarPerfil: (uid, d) => { __w.push({ op: 'update', path: 'usuarios/' + uid, data: d }); return Promise.resolve(); },
      cadastrar: (e, s) => Promise.resolve({ uid: 'N1', email: e }),
      recuperarSenha: (e) => { __w.push({ op: 'reset', path: e }); return Promise.resolve(); } });
    window.fetch = (url, o) => { const nome = String(url).split('/').pop(); __fn.push({ nome, corpo: JSON.parse((o && o.body) || '{}') });
      const r = { ok: true, acesso: { temAcesso: true, fonte: 'teste', plano: 'todos', permiteMaster: true, trialInicio: 1, trialFim: Date.now() + 86400000 * 5 }, status: 'authorized', master: true };
      return Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(r) }); };
    window.showToast = (m) => { __toast.push(String(m)); };
  });
  return pg;
}
const CAPTURADAS = []; const LOJAW = {};
const escritas = async (pg) => { const w = await pg.evaluate(() => window.__w.slice()); w.forEach((x) => CAPTURADAS.push(x)); return w; };
const limpar = (pg) => pg.evaluate(() => { window.__w.length = 0; window.__fn.length = 0; window.__toast.length = 0; });
const valores = (o) => JSON.stringify(o || {});
function semProibidos(w, rotulo) {
  w.forEach((x) => { const d = x.data || {}; const pub = /^usuarios\/[^/]+$/.test(x.path);
    if (!pub) return;
    PROIBIDO.forEach((k) => assert(!(k in d), rotulo + ': gravou ' + k + ' em ' + x.path));
    assert(d.master_ativo !== true, rotulo + ': gravou master_ativo:true');
    assert(d.verificado !== true, rotulo + ': gravou verificado:true');
    assert(!d.plano || d.plano === 'free', rotulo + ': gravou plano ' + d.plano);
    ['cpf', 'contatoEmergencia', 'email', 'emailContato'].forEach((k) => assert(!(k in d), rotulo + ': gravou ' + k + ' no perfil público'));
  });
}

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--no-sandbox'] });
  for (const servidor of [false, true]) {
    const M = servidor ? '[servidor LIGADO] ' : '[servidor desligado] ';
    const pg = await abrir(browser, servidor);
    await T(M + 'teste grátis: nada de trial_* é gravado na conta pelo aparelho' + (servidor ? '; o app pede statusAcesso ao servidor' : ''), async () => {
      await limpar(pg);
      await pg.evaluate(() => { _ativarTrial('AUTO', 60); }); await pg.waitForTimeout(300);
      const w = await escritas(pg); semProibidos(w, 'trial'); assert.equal(w.filter((x) => valores(x.data).includes('trial_')).length, 0);
      const fn = await pg.evaluate(() => window.__fn.map((x) => x.nome));
      if (servidor) assert(fn.includes('statusAcesso'), 'não chamou statusAcesso: ' + fn); else assert.equal(fn.length, 0, 'chamou servidor com o modo desligado');
    });
    await T(M + 'verificação: CPF/selfie vão só para verificacoes/{uid}; o selo nunca é gravado pelo aparelho' + (servidor ? '; confirmarVerificacao é chamada' : ''), async () => {
      await limpar(pg);
      await pg.evaluate(() => { const set = (id, v, tag) => { let e = document.getElementById(id); if (!e) { document.body.insertAdjacentHTML('beforeend', '<' + (tag || 'input') + ' id="' + id + '"></' + (tag || 'input') + '>'); e = document.getElementById(id); } e.value = v; }; set('verif-cpf', '111.444.777-35'); set('verif-cpf-status', '', 'div'); window._verifSelfieTmp = 'data:image/jpeg;base64,' + 'A'.repeat(300); _salvarVerificacaoSeguranca(); }); await pg.waitForTimeout(400);
      const w = await escritas(pg); semProibidos(w, 'verificação');
      assert(w.some((x) => x.path === 'verificacoes/U1'), 'não gravou verificacoes/U1');
      assert(!w.some((x) => /^usuarios\/U1$/.test(x.path) && ('verificado' in (x.data || {}))), 'gravou verificado em usuarios');
      const fn = await pg.evaluate(() => window.__fn.map((x) => x.nome));
      if (servidor) assert(fn.includes('confirmarVerificacao'), 'não chamou confirmarVerificacao'); else assert(!fn.includes('confirmarVerificacao'));
    });
    await T(M + 'salvar perfil com Master ligado: master_ativo:true NÃO vai no salvamento' + (servidor ? '; definirModoMaster é chamada' : ' (fica só no aparelho)'), async () => {
      await limpar(pg);
      await pg.evaluate(() => {
        const set = (id, v) => { let e = document.getElementById(id); if (!e) { document.body.insertAdjacentHTML('beforeend', '<input id="' + id + '">'); e = document.getElementById(id); } e.value = v; };
        set('edit-nome', 'Fulano de Tal'); set('edit-bio', 'Eletricista'); set('edit-wa', '31999990000'); set('edit-email', 'contato@x.com'); set('edit-cidade', 'Sete Lagoas'); set('edit-bairro', 'Centro'); set('edit-cpf', '111.444.777-35');
        set('edit-prest-val', 'Eletricista'); set('edit-master-busca', 'Psicologia'); localStorage.setItem('frilaone_foto', 'data:image/png;base64,AAAA'); localStorage.setItem('frilaone_tipo', 'prestador');
        window._editMasterAtivo = true; salvarPerfil(); }); await pg.waitForTimeout(500);
      const w = await escritas(pg); semProibidos(w, 'salvar perfil');
      const perfil = w.find((x) => x.path === 'usuarios/U1' && x.data && x.data.nome === 'Fulano de Tal');
      assert(perfil, 'perfil não foi salvo: ' + JSON.stringify(w).slice(0, 300));
      assert.equal(perfil.data.wa, '31999990000'); assert.equal(perfil.data.cidade, 'Sete Lagoas');
      const priv = w.filter((x) => x.path === 'usuarios_privado/U1').map((x) => x.data);
      assert(priv.some((d) => d.cpf === '11144477735'), 'CPF não foi para o documento privado');
      assert(priv.some((d) => d.emailContato === 'contato@x.com'), 'e-mail de contato não foi para o documento privado');
      const fn = await pg.evaluate(() => window.__fn.map((x) => x.nome));
      if (servidor) assert(fn.includes('definirModoMaster'), 'não chamou definirModoMaster: ' + fn); else assert(!fn.includes('definirModoMaster'));
    });
    await T(M + 'salvar perfil SEM Master: master_ativo:false pode ser enviado (desligar é livre)', async () => {
      await limpar(pg);
      await pg.evaluate(() => { window._editMasterAtivo = false; salvarPerfil(); }); await pg.waitForTimeout(400);
      const w = await escritas(pg); semProibidos(w, 'perfil sem master');
      const perfil = w.find((x) => x.path === 'usuarios/U1' && x.data && x.data.nome); assert(perfil && perfil.data.master_ativo === false);
    });
    await T(M + 'cadastro por e-mail: perfil novo sem e-mail/plano pago; e-mail vai para o documento privado; aceite é registrado', async () => {
      await limpar(pg);
      await pg.evaluate(() => { authMode = 'register'; termsOk = true;
        const set = (id, v) => { let e = document.getElementById(id); if (!e) { document.body.insertAdjacentHTML('beforeend', '<input id="' + id + '">'); e = document.getElementById(id); } e.value = v; };
        set('inp-email', 'novo@x.com'); set('inp-senha', '123456'); set('inp-nome-cad', 'Novo Nome'); window._entrarNoApp = () => {}; window._registrarIndicacaoSeHouver = () => {}; doLogin(); }); await pg.waitForTimeout(700);
      const w = await escritas(pg); semProibidos(w, 'cadastro');
      const novo = w.find((x) => x.path === 'usuarios/N1'); assert(novo, 'perfil novo não gravado: ' + JSON.stringify(w).slice(0, 300)); assert.equal(novo.data.plano, 'free'); assert.equal(novo.data.nome, 'Novo Nome');
      assert(w.some((x) => x.path === 'usuarios_privado/N1' && x.data.email === 'novo@x.com'), 'e-mail não foi para usuarios_privado');
      const fn = await pg.evaluate(() => window.__fn.map((x) => x.nome + ':' + (x.corpo.acao || ''))); assert(fn.includes('registrarAceite:cadastro_email'), 'sem aceite: ' + fn);
    });
    await T(M + 'recuperar senha continua funcionando', async () => {
      await limpar(pg);
      await pg.evaluate(() => { const e = document.getElementById('inp-email'); e.value = 'esqueci@x.com'; recuperarSenha(); }); await pg.waitForTimeout(300);
      const w = await escritas(pg); assert(w.some((x) => x.op === 'reset' && x.path === 'esqueci@x.com'), 'não pediu e-mail de recuperação');
    });
    await T(M + 'Master legado no seletor de planos não grava master_ativo:true na conta', async () => {
      await limpar(pg);
      await pg.evaluate(() => { localStorage.setItem('frilaone_master_ativo', '1'); try { _escolherTipoPlanos('prestador', 'Prestador de Serviço', '🔧'); } catch (e) {} }); await pg.waitForTimeout(300);
      semProibidos(await escritas(pg), 'planos');
    });
    await T(M + 'ESTÁGIO separado do "Tô disponível": ficar online/offline grava só em estagiarios/{uid}; nunca em disponiveis; sem trava de assinatura', async () => {
      await limpar(pg);
      await pg.evaluate(() => { window.confirm = () => true; window._permitirAcaoPaga = () => { window.__trava = true; return false; };   // se o estágio ainda consultasse a assinatura, travaria
        localStorage.setItem('frilaone_est_perfil', JSON.stringify({ nome: 'Est', area: 'Direito', periodo: '5º', facul: 'UFSJ', online: false })); _estOnline = false;
        toggleEstOnline(); }); await pg.waitForTimeout(250);
      let w = await escritas(pg);
      assert(w.some((x) => x.path === 'estagiarios/U1' && x.data && x.data.online === true && x.data.onlineTs), 'não gravou online em estagiarios/U1: ' + JSON.stringify(w).slice(0, 300));
      assert(!(await pg.evaluate(() => !!window.__trava)), 'estágio consultou a trava de assinatura');
      await limpar(pg); await pg.evaluate(() => { toggleEstOnline(); }); await pg.waitForTimeout(250);
      w = (await escritas(pg)); assert(w.some((x) => x.path === 'estagiarios/U1' && x.data && x.data.online === false), 'não gravou offline');
      await limpar(pg); await pg.evaluate(() => { excluirCadastroEstagiario(); }); await pg.waitForTimeout(250);
      w = w.concat(await escritas(pg)); assert(w.some((x) => x.op === 'delete' && x.path === 'estagiarios/U1'), 'não excluiu o cadastro');
      assert(!w.some((x) => /^disponiveis\//.test(x.path)), 'estágio mexeu em disponiveis: ' + JSON.stringify(w.filter((x) => /^disponiveis\//.test(x.path))));
      assert(!w.some((x) => x.data && x.data.categoria === 'estagiario'), 'categoria "estagiario" gravada');
      const rs = await pg.evaluate(() => [_estEstaOnline({ online: true, onlineTs: Date.now() }), _estEstaOnline({ online: true, onlineTs: Date.now() - 3 * 3600e3 }), _estEstaOnline({ online: false }), _estEstaOnline({})]);
      assert.deepEqual(rs, [true, false, false, false]);
    });
    await T(M + 'MINHA LOJA: cadastro vira PENDENTE (nunca publica sozinho), sem campos de aprovação, com merge; edição de loja aprovada/pendência não manda status errado', async () => {
      const preenche = () => pg.evaluate(() => { const set = (id, v) => { let e = document.getElementById(id); if (!e) { document.body.insertAdjacentHTML('beforeend', '<input id="' + id + '">'); e = document.getElementById(id); } e.value = v; };
        set('neg-cad-nome', 'Padaria Teste'); set('neg-cad-tipo', 'Padaria'); set('neg-cad-bairro', 'Centro'); set('neg-cad-wa', '31999999999'); set('neg-cad-desc', 'Pães'); window.__toast.length = 0; window.__negarDisp = true; });
      const salva = async (localStorageNeg) => { await limpar(pg); await preenche();
        await pg.evaluate((ln) => { localStorage.removeItem('frilaone_mn_contado'); if (ln) localStorage.setItem('frilaone_meu_negocio', JSON.stringify(ln)); else localStorage.removeItem('frilaone_meu_negocio'); _salvarCadastroNegocio(); }, localStorageNeg || null);
        await pg.waitForTimeout(350); return (await escritas(pg)).filter((x) => x.path === 'negocios/neg_U1'); };
      const SRV = ['publicaAte', 'aprovacaoEm', 'aprovacaoPor', 'aprovacaoMotivo'];
      // 1) loja nova
      let w = await salva(null); assert.equal(w.length, 1, 'não gravou a loja'); LOJAW.novo = w[0];
      assert.equal(w[0].data.aprovacaoStatus, 'pendente'); SRV.forEach((k) => assert(!(k in w[0].data), 'enviou ' + k)); assert.equal(w[0].merge, true, 'sem merge');
      const toasts = await pg.evaluate(() => window.__toast.join('|')); assert(/aprova/i.test(toasts) && !/publicado/i.test(toasts), 'aviso errado: ' + toasts);
      // 2) loja já aprovada (cópia local veio do servidor com os campos de aprovação)
      w = await salva({ uid: 'U1', nome: 'x', aprovacaoStatus: 'aprovada', publicaAte: 9999999999999, aprovacaoEm: 1, aprovacaoPor: 'ADM', aprovacaoMotivo: '' }); LOJAW.aprovada = w[0];
      assert(!('aprovacaoStatus' in w[0].data), 'mandou status por cima de loja aprovada'); SRV.forEach((k) => assert(!(k in w[0].data), 'enviou ' + k)); assert.equal(w[0].merge, true);
      const loc = await pg.evaluate(() => JSON.parse(localStorage.getItem('frilaone_meu_negocio'))); assert.equal(loc.aprovacaoStatus, 'aprovada', 'perdeu o status na cópia local');
      // 3) loja com pendências: reenviar
      w = await salva({ uid: 'U1', nome: 'x', aprovacaoStatus: 'pendencia', aprovacaoMotivo: 'faltam fotos' }); LOJAW.pendencia = w[0];
      assert.equal(w[0].data.aprovacaoStatus, 'pendente'); SRV.forEach((k) => assert(!(k in w[0].data), 'enviou ' + k));
      // 4) a loja não "abre" sozinha: presença recusada pelas regras não deixa o heartbeat do Tô disponível rodando
      await pg.evaluate(() => { try { _pararHeartbeatPresenca(); } catch (e) {} window._fbUID = 'U1'; window._lojaAutoOnlineAtiva = false; if (typeof disponivel !== 'undefined') disponivel = false; _ativarLojaAutoOnline(); }); await pg.waitForTimeout(300);
      assert(!(await pg.evaluate(() => !!_heartbeatDisponivelInt)), 'heartbeat ligado com a loja não publicada');
      await pg.evaluate(() => { window.__negarDisp = false; });
    });
    await T(M + 'MINHA LOJA: a vitrine lista só lojas PUBLICADAS (publicaAte futuro), não mais ativo==true', async () => {
      await pg.evaluate(() => { window.__where = []; _negociosDrawerListener = null; _carregarNegociosDrawer(); });
      const wh = await pg.evaluate(() => (window.__where || []).filter((x) => x[0] === 'negocios'));
      assert(wh.some((x) => x[1] === 'publicaAte' && x[2] === '>' && typeof x[3] === 'number' && x[3] > 1e12), 'consulta da vitrine: ' + JSON.stringify(wh));
      assert(!wh.some((x) => x[1] === 'ativo'), 'ainda filtra por ativo');
    });
    await pg.context().close();
  }
  await browser.close();
  // ── Repete, nas REGRAS v18 (avaliador local SIMULADO), tudo o que o app tentou gravar nos perfis/documentos privados.
  //    Se o app novo mandasse algo que as regras recusam, o salvamento INTEIRO falharia — este teste pega isso.
  const { rulesUnitTesting, firestoreMod } = require('./regras/avaliador-local/firebase-falso.js');
  const { doc, setDoc, deleteField } = firestoreMod;
  const env = await rulesUnitTesting.initializeTestEnvironment({ projectId: 'x', firestore: { rules: fs.readFileSync(path.join(__dirname, '../firestore-regras-v18.4.txt'), 'utf8') } });
  await env.withSecurityRulesDisabled(async (ctx) => { await setDoc(doc(ctx.firestore(), 'usuarios/U1'), { nome: 'U1', tipo: 'prestador', plano: 'free', xp: 0 }); });
  const alvo = CAPTURADAS.filter((x) => (x.op === 'set' || x.op === 'update') && /^(usuarios|usuarios_privado|verificacoes|estagiarios)\/[^/]+$/.test(x.path) && x.data);
  const vistos = new Set();
  for (const x of alvo) {
    const chave = x.path + JSON.stringify(x.data, (k, v) => (k === 'atualizadoEm' || k === 'dataEnvio' || k === 'ultimoLogin' || k === 'criadoEm' ? 0 : v)); if (vistos.has(chave)) continue; vistos.add(chave);
    const uid = x.path.split('/')[1]; const dados = JSON.parse(JSON.stringify(x.data));
    for (const k of Object.keys(dados)) if (dados[k] && dados[k].__del) dados[k] = deleteField(); else if (dados[k] && dados[k].inc !== undefined) delete dados[k];
    await T('regras v18 aceitam o que o app gravou em ' + x.path + ' (' + Object.keys(dados).slice(0, 6).join(',') + ')', async () => {
      await setDoc(doc(env.authenticatedContext(uid).firestore(), x.path), dados, { merge: true }); });
  }
  // ── Minha Loja: o que o app gravou (cadastro novo, edição de loja aprovada, reenvio após pendência) é aceito pelas regras v18.3
  {
    const { updateDoc } = firestoreMod; const FAR = 9999999999999;
    const casos = [['cadastro novo', LOJAW.novo, null], ['edição de loja APROVADA (merge, sem status)', LOJAW.aprovada, { aprovacaoStatus: 'aprovada', publicaAte: FAR, aprovacaoEm: 1, aprovacaoPor: 'ADM', aprovacaoMotivo: '' }], ['reenvio após pendência', LOJAW.pendencia, { aprovacaoStatus: 'pendencia', publicaAte: 0, aprovacaoEm: 1, aprovacaoPor: 'ADM', aprovacaoMotivo: 'faltam fotos' }]];
    for (const [rot, w, seed] of casos) {
      await T('regras v18.3 aceitam a gravação da loja do app: ' + rot, async () => {
        assert(w, 'sem captura'); const e2 = await rulesUnitTesting.initializeTestEnvironment({ projectId: 'y', firestore: { rules: fs.readFileSync(path.join(__dirname, '../firestore-regras-v18.4.txt'), 'utf8') } });
        if (seed) await e2.withSecurityRulesDisabled(async (ctx) => { await setDoc(doc(ctx.firestore(), 'negocios/neg_U1'), Object.assign({ uid: 'U1', nome: 'antiga' }, seed)); });
        await setDoc(doc(e2.authenticatedContext('U1').firestore(), 'negocios/neg_U1'), JSON.parse(JSON.stringify(w.data)), { merge: true });
      });
    }
  }
  console.log('\nREGRESSÃO DO APP (Chromium, servidor falso): ' + ok + ' OK, ' + bad + ' falharam'); process.exit(bad ? 1 : 0);
})();
