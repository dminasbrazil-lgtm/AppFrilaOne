// Duplicidade, avisos repetidos, assinatura órfã e limite de consultas — Firebase e Mercado Pago FALSOS. Rodar: node teste-assinatura-duplicidade.js
const Module = require('module'), assert = require('assert'), crypto = require('crypto');
const store = {}; const FV = { delete: () => ({ __del: true }), serverTimestamp: () => 'TS' };
const docRef = (c, i) => ({ get: async () => ({ exists: !!store[c + '/' + i], data: () => store[c + '/' + i] }), set: async (v, o) => { const cur = (o && o.merge && store[c + '/' + i]) || {}; const n = { ...cur }; for (const k in v) { if (v[k] && v[k].__del) delete n[k]; else n[k] = v[k]; } store[c + '/' + i] = n; } });
const fakeAdmin = { initializeApp() {}, auth: () => ({ verifyIdToken: async (t) => { if (t === 'ok') return { uid: 'u1' }; throw new Error('x'); } }), firestore: Object.assign(() => ({ collection: (c) => ({ doc: (i) => docRef(c, i) }), runTransaction: async (f) => f({ get: async (r) => r.get(), set: (r, v, o) => r.set(v, o) }) }), { FieldValue: FV }) };
const fakeFns = { runWith: () => ({ region: () => ({ https: { onRequest: (h) => h } }) }) };
const orig = Module._load; Module._load = function (r, ...a) { if (r === 'firebase-functions/v1') return fakeFns; if (r === 'firebase-admin') return fakeAdmin; return orig.call(this, r, ...a); };
const mpCalls = []; const pre = {}; let seq = 0;
global.fetch = async (url, o) => { const m = o.method, p = url.replace('https://api.mercadopago.com', ''); mpCalls.push(m + ' ' + p); const R = (b, ok = true, st = 200) => ({ ok, status: st, json: async () => b });
  if (m === 'POST' && p === '/preapproval') { const b = JSON.parse(o.body); const id = 'PRE' + (++seq); pre[id] = { id, status: 'pending', external_reference: b.external_reference, auto_recurring: b.auto_recurring }; return R({ id, init_point: 'https://mp/ckout/' + id }); }
  if (m === 'GET' && p.startsWith('/preapproval/')) return R(pre[p.split('/')[2]]);
  if (m === 'PUT' && p.startsWith('/preapproval/')) { Object.assign(pre[p.split('/')[2]], JSON.parse(o.body)); return R(pre[p.split('/')[2]]); }
  return R({}, false, 404); };
process.env.MP_ACCESS_TOKEN = 'TEST'; process.env.MP_WEBHOOK_SECRET = 'seg';
const A = require('../functions/assinatura.js');
const mkres = () => { const r = { code: 200, body: null, hdr: {} }; r.status = (c) => { r.code = c; return r; }; r.json = (b) => { r.body = b; return r; }; r.send = (b) => { r.body = b; return r; }; r.set = (k, v) => { r.hdr[k] = v; }; return r; };
const call = async (h, body) => { const rs = mkres(); await h({ method: 'POST', headers: { authorization: 'Bearer ok', origin: 'https://frilaone.com.br' }, body, query: {} }, rs); return rs; };
const sign = (id, rid, ts) => 'ts=' + ts + ',v1=' + crypto.createHmac('sha256', 'seg').update('id:' + String(id).toLowerCase() + ';request-id:' + rid + ';ts:' + ts + ';').digest('hex');
const hook = async (id) => { const w = mkres(); const rid = 'r' + Math.random(); await A.webhookMercadoPago({ method: 'POST', headers: { 'x-request-id': rid, 'x-signature': sign(id, rid, '1704908010') }, body: {}, query: { 'data.id': id, type: 'subscription_preapproval' } }, w); return w; };
let n = 0; const t = async (nome, f) => { try { await f(); n++; console.log('OK     | ' + nome); } catch (e) { console.log('FALHOU | ' + nome + ' -> ' + e.message); process.exitCode = 1; } };
(async () => {
  store['usuarios/u1'] = { tipo: 'prestador' };
  await t('clique duplo em "assinar": segundo pedido reaproveita o mesmo link (1 única assinatura criada no MP)', async () => {
    const r1 = await call(A.criarAssinatura, { emailMP: 'a@b.com' }); const r2 = await call(A.criarAssinatura, { emailMP: 'a@b.com' });
    assert(r1.body.ok && r2.body.ok); assert.equal(r1.body.url, r2.body.url); assert(r2.body.reaproveitado); assert.equal(mpCalls.filter((c) => c === 'POST /preapproval').length, 1); });
  await t('link pendente de OUTRO e-mail: cancela o anterior no MP antes de criar o novo', async () => {
    const velho = store['assinaturas/u1'].preapprovalId; const r = await call(A.criarAssinatura, { emailMP: 'outro@b.com' });
    assert(r.body.ok && !r.body.reaproveitado); assert.equal(pre[velho].status, 'cancelled'); assert.notEqual(store['assinaturas/u1'].preapprovalId, velho); });
  await t('link pendente com mais de 30 min: não reaproveita; cancela o antigo e cria novo', async () => {
    const velho = store['assinaturas/u1'].preapprovalId; store['assinaturas/u1'].criadoEm = Date.now() - 31 * 60e3; const r = await call(A.criarAssinatura, { emailMP: 'outro@b.com' });
    assert(!r.body.reaproveitado); assert.equal(pre[velho].status, 'cancelled'); });
  await t('assinatura ÓRFÃ autorizada depois (link antigo): o aviso cancela no MP e NÃO concede acesso', async () => {
    const atual = store['assinaturas/u1'].preapprovalId; const orfa = 'PRE_ORFA'; pre[orfa] = { id: orfa, status: 'authorized', external_reference: 'u1' };
    const antes = JSON.stringify(store['assinaturas/u1']); const w = await hook(orfa);
    assert.equal(w.code, 200); assert.equal(pre[orfa].status, 'cancelled'); assert.equal(store['assinaturas/u1'].preapprovalId, atual); assert.notEqual(store['assinaturas/u1'].status, 'authorized'); });
  await t('aviso de autorização repetido 3x: mesmo resultado, sem duplicar', async () => {
    const id = store['assinaturas/u1'].preapprovalId; pre[id].status = 'authorized'; pre[id].next_payment_date = '2026-12-01T09:00:00.000-03:00';
    await hook(id); const um = JSON.stringify({ ...store['assinaturas/u1'], atualizadoEm: 0, acessoCalculadoEm: 0 }); await hook(id); await hook(id);
    assert.equal(JSON.stringify({ ...store['assinaturas/u1'], atualizadoEm: 0, acessoCalculadoEm: 0 }), um); assert.equal(store['assinaturas/u1'].status, 'authorized'); });
  await t('assinatura ativa: tentar assinar de novo → recusado (ja_ativa), nada criado', async () => { const c0 = mpCalls.length; const r = await call(A.criarAssinatura, { emailMP: 'a@b.com' }); assert.equal(r.body.erro, 'ja_ativa'); assert.equal(mpCalls.length, c0); });
  await t('"Já assinei" repetido: só a primeira consulta vai ao Mercado Pago em 15 s', async () => {
    delete store['assinaturas/u1'].sincronizadoEm; const c0 = mpCalls.filter((c) => c.startsWith('GET')).length; await call(A.sincronizarAssinatura, {}); const r2 = await call(A.sincronizarAssinatura, {});
    assert.equal(mpCalls.filter((c) => c.startsWith('GET')).length - c0, 1); assert(r2.body.limitado); });
  await t('"Já assinei" lê o estado do MP (não o que o cliente diz): MP pausado → status pausado', async () => {
    const id = store['assinaturas/u1'].preapprovalId; pre[id].status = 'paused'; delete store['assinaturas/u1'].sincronizadoEm; const r = await call(A.sincronizarAssinatura, { status: 'authorized', ativo: true });
    assert.equal(r.body.status, 'paused'); assert.equal(store['assinaturas/u1'].status, 'paused'); });
  await t('cancelada não é "revivida" por aviso atrasado de autorização', async () => {
    const id = store['assinaturas/u1'].preapprovalId; pre[id].status = 'authorized'; await call(A.cancelarAssinatura, {}); assert.equal(store['assinaturas/u1'].status, 'cancelled'); pre[id].status = 'authorized'; await hook(id); assert.equal(store['assinaturas/u1'].status, 'cancelled'); });
  await t('preço enviado pelo cliente é ignorado: o servidor usa o preço oficial do plano', async () => {
    store['usuarios/u1'] = { tipo: 'prestador' }; delete store['assinaturas/u1']; const r = await call(A.criarAssinatura, { emailMP: 'a@b.com', valor: 0.01, plano: 'diamond', transaction_amount: 1 });
    const p = pre[store['assinaturas/u1'].preapprovalId]; assert.equal(p.auto_recurring.transaction_amount, 14.9); assert.equal(store['assinaturas/u1'].plano, 'golden'); });
  console.log('ASSINATURA-DUPLICIDADE: ' + n + '/10 OK');
})();
