// Testes do código do app (nova cópia) com Firebase/navegador FALSOS. Rodar: node teste-app.js
const fs=require('fs'),assert=require('assert'),path=require('path');
const h=fs.readFileSync(path.join(__dirname,'../app/teste-final.html'),'utf8');
function fn(nome){ const i=h.indexOf('function '+nome+'('); assert(i>=0,nome); let d=0,j=h.indexOf('{',i); for(let k=j;k<h.length;k++){ if(h[k]=='{')d++; else if(h[k]=='}'){ d--; if(d==0) return h.slice(i,k+1);} } }
function mk(extra){
  const ls={}, log=[], writes=[];
  const doc=(col,id)=>({set:(v,o)=>{writes.push({col,id,v,merge:!!(o&&o.merge)});return Promise.resolve()}});
  const db={collection:c=>({doc:i=>doc(c,i)})};
  const ctx=Object.assign({console,Promise,Date,JSON,
    localStorage:{getItem:k=>(k in ls?ls[k]:null),setItem:(k,v)=>{ls[k]=String(v)},removeItem:k=>{delete ls[k]}},
    showToast:(m)=>log.push('toast:'+m), window:{_fbDb:db,_fbUID:'U1',open:(u)=>log.push('OPEN:'+u)}, _fbDb:db, firebase:{}, document:{getElementById:()=>null},
    _PLANOS:{master:{nome:'Todas',dias:30},prestador:{nome:'P',dias:30}}, _modalPagPlano:'master', _modalPagCadastro:{nome:'x'},
    _fecharModalPag(){log.push('fechou')}, _finalizarCadastroAposPagamento(){log.push('cadastro-final')}, setTimeout:(f)=>f(),
    _validarCPF:()=>true, _assinaturaConfigurada:()=>false, _acessoDoServidor(){}, abrirMinhaAssinatura(){log.push('abriu-assinatura')}, closeSheet(){} },extra||{});
  return {ctx,ls,log,writes};
}
function load(ctx,nomes){ const src=nomes.map(fn).join('\n'); return new Function(...Object.keys(ctx),src+';return {'+nomes.join(',')+'}')(...Object.values(ctx)); }
const res=[]; function t(n,f){ try{ f(); res.push(1); console.log('OK     | '+n);}catch(e){ res.push(0); console.log('FALHOU | '+n+' -> '+e.message);} }

// 1 plano pago local bloqueado / teste liberado
{ const m=mk(); const F=load(m.ctx,['_ativarPlano']);
  t('_ativarPlano(pago) não grava nada no aparelho',()=>{ F._ativarPlano('master',false); assert.deepEqual(m.ls,{}); });
  t('_ativarPlano(teste) continua funcionando',()=>{ F._ativarPlano('master',true); assert(m.ls['frilaone_assin_master']); assert.equal(JSON.parse(m.ls['frilaone_assin_master']).status,'trial'); }); }
// 2 "Assinar agora"
for(const cfg of [false,true]){ const m=mk({_assinaturaConfigurada:()=>cfg}); m.ctx._ativarPlano=function(t,tr){m.log.push('ATIVOU_LOCAL')}; const F=load(m.ctx,['_confirmarPagamentoModal']);
  t('"Assinar agora" com integração '+(cfg?'ligada':'desligada')+': não ativa plano e não abre link antigo',()=>{ F._confirmarPagamentoModal(); assert(!m.log.includes('ATIVOU_LOCAL')); assert(!m.log.some(x=>x.startsWith('OPEN:'))); assert.deepEqual(Object.keys(m.ls),[]); assert(m.log.includes('cadastro-final')); assert(cfg? m.log.includes('abriu-assinatura') : m.log.some(x=>/em breve/.test(x))); }); }
// 3 dados privados
{ const m=mk(); const F=load(m.ctx,['_privDb','_privSalvarUsuario','_privSalvarLoja','_negSemCpf']);
  t('_privSalvarUsuario grava em usuarios_privado/{uid} com merge',()=>{ F._privSalvarUsuario('U1',{cpf:'123'}); const w=m.writes[0]; assert.equal(w.col,'usuarios_privado'); assert.equal(w.id,'U1'); assert(w.merge); assert.equal(w.v.cpf,'123'); });
  t('_privSalvarLoja grava em negocios_privado/{negId} com uid e cpf',()=>{ F._privSalvarLoja('neg_U1','U1','999'); const w=m.writes[1]; assert.equal(w.col,'negocios_privado'); assert.deepEqual(Object.keys(w.v).sort(),['atualizadoEm','cpf','uid']); });
  t('_negSemCpf remove o CPF (e, v4.3, os campos de aprovação do servidor) e não altera o original',()=>{ const o={nome:'L',cpf:'1',cnpj:'2',publicaAte:9,aprovacaoStatus:'aprovada',aprovacaoPor:'x'}; const c=F._negSemCpf(o); assert(!('cpf' in c)); assert(!('publicaAte' in c)&&!('aprovacaoStatus' in c)&&!('aprovacaoPor' in c)); assert.equal(c.nome,'L'); assert.equal(c.cnpj,'2'); assert.equal(o.cpf,'1'); assert.equal(o.publicaAte,9); });
  t('sem uid não grava (não quebra)',()=>{ const n=m.writes.length; F._privSalvarUsuario('',{cpf:'1'}); assert.equal(m.writes.length,n); }); }
{ const m=mk(); m.ctx.document={getElementById:(id)=>({'seg-cpf':{value:'111.444.777-35'},'seg-contato-emergencia':{value:'(31) 99999-0000'},'seg-cpf-status':{style:{}}})[id]||null};
  m.ctx.window._fb={salvarPerfil:()=>{m.log.push('SALVOU_PERFIL_PUBLICO');return Promise.resolve()}};
  const F=load(m.ctx,['_privDb','_privSalvarUsuario','_salvarDadosSeguranca']);
  t('Salvar dados de segurança: vai para usuarios_privado e NÃO para usuarios',()=>{ F._salvarDadosSeguranca(); assert(!m.log.includes('SALVOU_PERFIL_PUBLICO')); const w=m.writes.find(x=>x.col==='usuarios_privado'); assert(w); assert.equal(w.v.cpf,'11144477735'); assert.equal(w.v.contatoEmergencia,'31999990000'); assert.equal(m.ls['frilaone_cpf'],'11144477735'); assert.equal(m.ls['frilaone_contato_emergencia'],'31999990000'); }); }
// 4 buscas estáticas no código
t('nenhuma gravação de cpf/contatoEmergencia/localização em usuarios',()=>{ assert(!/ultima_emergencia/.test(h)); assert(!/dadosParaSalvar\.cpf/.test(h)); assert(!/salvarPerfil\(uid, *\{ *cpf/.test(h)); });
t('pânico continua gravando em emergencias',()=>{ assert((h.match(/collection\('emergencias'\)\.add/g)||[]).length>=2); });
t('lojas: set() usa cópia sem CPF (e sem campos de aprovação) nos 2 pontos, com merge (v4.3: a gravação antiga sem merge apagaria os campos do servidor)',()=>{ assert(/var dadosEnviar = _negSemCpf\(negData\)/.test(h)); assert(/\.collection\('negocios'\)\.doc\(meuId\)\.set\(dadosEnviar, \{ merge: true \}\)/.test(h)); assert(/var dadosRetry = _negSemCpf\(negLocal\)/.test(h)); assert(/\.collection\('negocios'\)\.doc\(negId\)\.set\(dadosRetry, \{ merge: true \}\)/.test(h)); });
t('"Já assinei" não chama _ativarPlano',()=>{ const f=fn('_jaAssineiPrestador'); assert(!/_ativarPlano/.test(f)); });

// ───────── acesso pago decidido pelo servidor (v16): com a integração LIGADA e DESLIGADA
function ctxAcesso(ligado, ac, extra){
  const m=mk(Object.assign({_assinaturaConfigurada:()=>ligado, _atualizarTrialBadge(){}, _planoDaConta:()=>'golden', _acessoDoServidor(){m.log.push('pediu-acesso');return Promise.resolve()}},extra||{}));
  m.ctx.window._acessoSrv=ac||null; return m;
}
const AGORA=Date.now(), DIA=86400000;
{ const m=ctxAcesso(true,null); m.ls['frilaone_assin_master']=JSON.stringify({status:'ativo',fim:AGORA+9*DIA}); // usuário "forjou" plano no navegador
  const F=load(m.ctx,['_planoAtivo','_acessoServidorPermite']);
  t('SERVIDOR LIGADO: plano forjado no navegador (frilaone_assin_master) NÃO vale',()=>{ assert.equal(F._planoAtivo('master'),false); });
  m.ctx.window._acessoSrv={temAcesso:true,plano:'todos'}; 
  t('SERVIDOR LIGADO: teste/código do servidor libera tudo; "master" não libera Minha Loja',()=>{ assert.equal(F._planoAtivo('prestador'),true); m.ctx.window._acessoSrv={temAcesso:true,plano:'master'}; assert.equal(F._planoAtivo('vit'),false); assert.equal(F._planoAtivo('empresa'),true); });
  t('SERVIDOR LIGADO: plano de uma área só libera as áreas "golden"',()=>{ m.ctx.window._acessoSrv={temAcesso:true,plano:'golden'}; assert.equal(F._planoAtivo('parceiro'),true); assert.equal(F._planoAtivo('master'),false); assert.equal(F._planoAtivo('vit'),false); });
  t('SERVIDOR LIGADO: sem acesso confirmado, nada libera',()=>{ m.ctx.window._acessoSrv={temAcesso:false}; assert.equal(F._planoAtivo('prestador'),false); }); }
{ const m=ctxAcesso(false,null); const F=load(m.ctx,['_planoAtivo','_ativarPlano']);
  t('SERVIDOR DESLIGADO: comportamento antigo preservado (teste local libera)',()=>{ F._ativarPlano('master',true); assert.equal(F._planoAtivo('master'),true); }); }
{ const m=ctxAcesso(true,null); const F=load(m.ctx,['_ativarPlano']);
  t('SERVIDOR LIGADO: _ativarPlano(teste) não grava nada no aparelho; pede ao servidor',()=>{ F._ativarPlano('master',true); assert.deepEqual(m.ls,{}); assert(m.log.includes('pediu-acesso')); }); }
{ const m=ctxAcesso(true,null); const src=fn('_ativarTrial'); const F=new Function(...Object.keys(m.ctx),src+';return _ativarTrial')(...Object.values(m.ctx));
  t('SERVIDOR LIGADO: _ativarTrial não calcula/grava teste local nem trial_* no Firestore',()=>{ m.ctx.window._fb={salvarPerfil:()=>{m.log.push('GRAVOU_TRIAL');return Promise.resolve()}}; F('AUTO',60); assert.deepEqual(m.ls,{}); assert(!m.log.includes('GRAVOU_TRIAL')); assert(m.log.includes('pediu-acesso')); }); }
{ const base={_planoDaConta:()=>'golden'};
  const mk2=(lig,ac,plano)=>{ const m=ctxAcesso(lig,ac,{_planoDaConta:()=>plano}); return {m,F:load(m.ctx,['_statusPeloAcessoServidor'])}; };
  t('estado: Pessoa Física nunca é bloqueada',()=>{ const {F}=mk2(true,{temAcesso:false,trialFim:1},''); assert.deepEqual(F._statusPeloAcessoServidor(),{existe:false,bloqueado:false}); });
  t('estado: teste válido → dias restantes',()=>{ const {F}=mk2(true,{temAcesso:true,ate:AGORA+5*DIA},'golden'); const r=F._statusPeloAcessoServidor(); assert(r.existe&&!r.bloqueado&&!r.vencido&&r.diasRestam===5); });
  t('estado: carência (3 dias) não bloqueia',()=>{ const {F}=mk2(true,{temAcesso:false,emCarencia:true,carenciaAte:AGORA+2*DIA},'golden'); const r=F._statusPeloAcessoServidor(); assert(r.vencido&&!r.bloqueado&&r.diasCarenciaRestam===2); });
  t('estado: vencido e sem pagamento → bloqueado; pendente/recusado também não concedem',()=>{ const {F}=mk2(true,{temAcesso:false,trialFim:AGORA-9*DIA},'golden'); assert.equal(F._statusPeloAcessoServidor().bloqueado,true); });
  t('estado: servidor desligado → não interfere (null)',()=>{ const {F}=mk2(false,{temAcesso:true},'golden'); assert.equal(F._statusPeloAcessoServidor(),null); }); }
{ const m=ctxAcesso(true,null); const F=load(m.ctx,['_aplicarAcessoServidor']);
  t('cópia local do teste vem SÓ do servidor',()=>{ F._aplicarAcessoServidor({temAcesso:true,trialInicio:AGORA,trialFim:AGORA+3*DIA,codigoFim:AGORA+9*DIA}); const td=JSON.parse(m.ls['frilaone_trial']); assert.equal(td.cod,'SERVIDOR'); assert.equal(td.fim,AGORA+9*DIA); }); }
// ── Sistema de códigos retirado / preços e links antigos eliminados ──
{ const m=ctxAcesso(true,null); const F=load(m.ctx,['_abrirPagamentoOficial']);
  t('contratar com servidor LIGADO leva ao cartão e NÃO abre link externo',()=>{ F._abrirPagamentoOficial(); assert(m.log.includes('abriu-assinatura')); assert(!m.log.some(x=>x.startsWith('OPEN:'))); });
  const m2=ctxAcesso(false,null); const F2=load(m2.ctx,['_abrirPagamentoOficial']);
  t('contratar com servidor DESLIGADO avisa "em breve" e NÃO abre link nem ativa nada',()=>{ F2._abrirPagamentoOficial(); assert(m2.log.some(x=>/em breve/.test(x))); assert(!m2.log.some(x=>x.startsWith('OPEN:'))); assert(!m2.log.includes('abriu-assinatura')); assert.deepEqual(Object.keys(m2.ls),[]); }); }
t('app sem nenhum link mpago.la',()=>{ assert(!/mpago\.la/.test(h)); });
t('app sem preços antigos (308,56 / 29,90 / 149,90 / 19,90 / 24,90 / 4,99)',()=>{ for(const p of ['308,56','29,90','149,90','19,90','24,90','4,99','19.90','149.90']) assert(!h.includes(p),p); });
t('tabela oficial: Golden 14,90 · Master 34,90 · Diamond 79,90 (_planPagtoLinks e _PLANOS)',()=>{
  const i=h.indexOf('var _planPagtoLinks={'); const tab=h.slice(i,h.indexOf('};',i)); assert(/empresa:[^}]*14,90/.test(tab)&&/prestador:[^}]*14,90/.test(tab)&&/parceiro:[^}]*14,90/.test(tab)&&/master:[^}]*34,90/.test(tab)&&/completo:[^}]*34,90/.test(tab)&&/vit:[^}]*79,90/.test(tab));
  const j=h.indexOf('var _PLANOS = {'); const pl=h.slice(j,h.indexOf('};',j)); assert(/master:[^}]*R\$ 34,90\/mês/.test(pl)&&/negocio:[^}]*R\$ 79,90\/mês/.test(pl)&&!/link:/.test(pl)); });
t('app sem listas de códigos GP/MN/CV nem textos de cupom/código promocional',()=>{
  assert(!/GP-[A-Z0-9]{6}/.test(h)&&!/MN-[A-Z0-9]{6}/.test(h)&&!/CV-0|'CV-'/.test(h));
  assert(!/upom/.test(h),'cupom'); assert(!/inp-codigo|codigo-cad|resgatarCodigo|_CODIGOS_|validarCodigo|abrirCodigoPromo/.test(h)); });
t('app: campo de cupom não existe mais no modal de pagamento nem em Planos',()=>{ assert(!/modal-pag-cupom|plan-cupom|cupom-modal/.test(h)); });
t('compartilhar: link sem código e sem ?convite=',()=>{ const ctx={window:{location:{origin:'https://frilaone.com.br',pathname:'/index.html'}}}; const F=new Function('window',fn('_getLinkComConvite')+';return _getLinkComConvite')(ctx.window); const l=F(); assert.equal(l,'https://frilaone.com.br'); assert(!/convite=/.test(l)); });
t('indicação (?ref=) da campanha do Kit continua existindo',()=>{ assert(/function _linkIndicacao\(/.test(h)&&/\?ref=/.test(h)&&/function _registrarIndicacaoSeHouver\(/.test(h)); });
{ const m=mk(); m.ctx.abrirVitrine=()=>m.log.push('planos'); m.ctx.abrirCadastroVitrine=()=>m.log.push('cadastro-vitrine'); m.ctx._planoAtivo=()=>false; const F=load(m.ctx,['quererMinhaVitrine']);
  t('Vitrine sem plano confirmado → vai para os planos, NÃO abre cadastro ("pagamento confirmado" falso removido)',()=>{ F.quererMinhaVitrine(); assert(m.log.includes('planos')); assert(!m.log.includes('cadastro-vitrine')); });
  const m2=mk(); m2.ctx.abrirVitrine=()=>m2.log.push('planos'); m2.ctx.abrirCadastroVitrine=()=>m2.log.push('cadastro-vitrine'); m2.ctx._planoAtivo=()=>true; const F2=load(m2.ctx,['quererMinhaVitrine']);
  t('Vitrine com plano confirmado → abre o cadastro da vitrine',()=>{ F2.quererMinhaVitrine(); assert(m2.log.includes('cadastro-vitrine')); assert(!m2.log.includes('planos')); }); }
{ const fut=AGORA+20*DIA; const m=ctxAcesso(false,null); m.ls['frilaone_assin_master']=JSON.stringify({status:'trial',fim:fut,origem:'GP'}); const F=load(m.ctx,['_planoAtivo']);
  t('direito antigo já concedido neste aparelho (origem GP) continua valendo com servidor desligado',()=>{ assert.equal(F._planoAtivo('master'),true); });
  const m2=ctxAcesso(true,{temAcesso:false}); m2.ls['frilaone_assin_master']=JSON.stringify({status:'trial',fim:fut,origem:'GP'}); const F2=load(m2.ctx,['_planoAtivo']);
  t('com servidor ligado, cópia local antiga NÃO concede nada (só o servidor decide)',()=>{ assert.equal(F2._planoAtivo('master'),false); }); }
t('?payment=approved na URL não ativa plano local',()=>{ const i=h.indexOf("if(status === 'approved' || status === 'success'){"); const trecho=h.slice(i,i+900); assert(!/frilaone_plano_/.test(trecho)); assert(!/setItem\('frilaone_trial|removeItem\('frilaone_trial/.test(trecho)); });
t('salvar perfil: master_ativo=true NUNCA vai no salvamento do perfil (v18: em nenhum modo; com servidor ligado o pedido vai para definirModoMaster) — comportamento coberto no Chromium por teste-regressao-app.js',()=>{ assert(/pedirMasterAoServidor = _assinaturaConfigurada\(\) && masterAtivo/.test(h)); assert(/if\(!masterAtivo\) dadosParaSalvar\.master_ativo = false;/.test(h)); assert(!/dadosParaSalvar\.master_ativo = masterAtivo/.test(h)); });
t('verificação: com servidor ligado o selo vem de confirmarVerificacao',()=>{ assert(/_fnPost\('confirmarVerificacao'/.test(h)); });
t('criarAssinatura envia o plano escolhido (validado no servidor)',()=>{ assert(/criarAssinatura', \{emailMP:em, trocar:!!window\._cartaoTrocar, plano:/.test(h)); });

setTimeout(()=>{
const f=res.filter(x=>!x).length; console.log('\n'+(res.length-f)+'/'+res.length+' OK'); process.exit(f?1:0);
},200);
// console.log('\n'+(res.length-f)+'/'+res.length+' OK'); process.exit(f?1:0);
