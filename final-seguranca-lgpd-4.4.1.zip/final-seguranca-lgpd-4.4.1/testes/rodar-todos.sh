#!/usr/bin/env bash
# Roda TODOS os testes que não precisam do Emulador (Firebase/Mercado Pago simulados). Uso: bash testes/rodar-todos.sh
# Os testes de REGRAS com o Emulador oficial são separados: ver testes/regras/EXECUTAR-NO-COMPUTADOR.md
cd "$(dirname "$0")" || exit 1
falhou=0
for t in teste-app teste-app-sem-privilegios teste-acesso teste-acesso-regras teste-regressao-app teste-aprovacao-loja teste-loja-gratuita teste-servidor-simulado teste-botao-ja-assinei teste-assinatura-duplicidade teste-migracao teste-beneficios teste-exclusao teste-aceite teste-emergencias teste-scripts; do
  printf '== %s\n' "$t"; node "$t.js" > "/tmp/$t.log" 2>&1 && echo "   passou" || { echo "   FALHOU (veja /tmp/$t.log)"; falhou=1; }
done
printf '== regras (avaliador LOCAL, SIMULADO — não é o Emulador)\n'; (cd regras && node executar-simulado.js > /tmp/regras-simulado.log 2>&1 && tail -1 /tmp/regras-simulado.log || { echo "   FALHOU"; falhou=1; })
exit $falhou
