// Minha Loja — aprovação administrativa, de PONTA A PONTA no que existe hoje (SIMULADO: banco falso + regras no avaliador local + função
// decidirLoja real com Auth falso). Não usa Firebase real nem o Emulador oficial.
// Fluxo: dono cadastra (pendente) → ninguém aprova pelo cliente → administrador decide pela função/script (servidor) → regras e vitrine reagem
// → depois de 30/11/2026 a aprovação sozinha NÃO mantém a loja publicada (precisa pagamento registrado).
const assert = require('assert'), fs = require('fs'), path = require('path'), Module = require('module');
const { rulesUnitTesting, firestoreMod } = require('./regras/avaliador-local/firebase-falso.js');
const { doc, setDoc, getDoc, updateDoc } = firestoreMod;
const LIB = require('../functions/loja-lib.js'), AL = require('../migracao/autorizar-loja.js'), DL = require('../migracao/decidir-loja.js');
let n = 0, f = 0; const ok = async (nome, fn) => { try { await fn(); n++; console.log('OK     | ' + nome); } catch (e) { f++; console.log('FALHOU | ' + nome + ' -> ' + (e.message || e).split('\n')[0]); } };
const T = (s) => Date.parse(s), DIA = 86400e3;
// banco falso do servidor (Admin SDK): ignora regras
const S = {}; let audit = 0;
const fdb = { collection: (c) => ({
  doc: (i) => ({ id: i, get: async () => ({ exists: S[c + '/' + i] !== undefined, data: () => S[c + '/' + i], id: i }), set: async (v, o) => { S[c + '/' + i] = Object.assign((o && o.merge && S[c + '/' + i]) || {}, v); } }),
  add: async (v) => { audit++; S[c + '/auto' + audit] = v; return { id: 'auto' + audit }; },
  get: async () => { const docs = Object.keys(S).filter((k) => k.startsWith(c + '/')).map((k) => ({ id: k.split('/')[1], data: () => S[k] })); return { docs, forEach: (g) => docs.forEach(g) }; } }) };
// função REAL com Auth falso: tokens "ok:uid:admin" (claim), "ok:uid:email" (e-mail do dono verificado), "ok:uid:emailnv" (não verificado), "ok:uid" (comum)
const fakeAdmin = { initializeApp() {}, auth: () => ({ verifyIdToken: async (t) => { const m = /^ok:([^:]+)(?::(.+))?$/.exec(t); if (!m) throw new Error('x'); const d = { uid: m[1] };
  if (m[2] === 'admin') d.admin = true; if (m[2] === 'email') { d.email = LIB.ADMIN_EMAIL; d.email_verified = true; } if (m[2] === 'emailnv') { d.email = LIB.ADMIN_EMAIL; d.email_verified = false; } return d; } }), firestore: () => fdb };
const orig = Module._load; Module._load = function (r, ...a) { if (r === 'firebase-functions/v1') return { runWith: () => ({ region: () => ({ https: { onRequest: (h) => h } }) }) }; if (r === 'firebase-admin') return fakeAdmin; return orig.call(this, r, ...a); };
const F = require('../functions/loja.js'); Module._load = orig;
const res = () => { const r = { code: 200, body: null }; r.status = (c) => { r.code = c; return r; }; r.json = (b) => { r.body = b; return r; }; r.send = (b) => { r.body = b; return r; }; r.set = () => {}; return r; };
const chama = async (token, corpo, metodo = 'POST') => { const r = res(); await F.decidirLoja({ method: metodo, headers: token ? { authorization: 'Bearer ' + token, origin: 'https://frilaone.com.br' } : { origin: 'https://frilaone.com.br' }, body: corpo }, r); return r; };

(async () => {
  const env = await rulesUnitTesting.initializeTestEnvironment({ projectId: 'x', firestore: { rules: fs.readFileSync(path.join(__dirname, '../firestore-regras-v18.4.txt'), 'utf8') } });
  const relogio = (iso) => { globalThis.__RELOGIO_SIMULADO = T(iso); }; const cli = (u, claims) => env.authenticatedContext(u, claims || {}).firestore();
  const sincroniza = async (negId) => env.withSecurityRulesDisabled(async (ctx) => { await setDoc(doc(ctx.firestore(), 'negocios/' + negId), JSON.parse(JSON.stringify(S['negocios/' + negId]))); });  // espelha o que o Admin SDK gravou
  const abre = (u) => setDoc(doc(cli(u), 'disponiveis/' + u), { uid: u, nome: 'L', categoria: 'negocio', ts: new Date() }).then(() => true, (e) => { if (e.code === 'permission-denied') return false; throw e; });
  const vitrine = (negId, agora) => (S['negocios/' + negId].publicaAte || 0) > agora && S['negocios/' + negId].ativo !== false;   // o mesmo critério da consulta do app
  const tenta = (fn) => fn().then(() => true, (e) => { if (e.code === 'permission-denied') return false; throw e; });
  relogio('2026-10-20T12:00:00-03:00'); const AG = T('2026-10-20T12:00:00-03:00');
  const U = 'Uabc123456';  // dono da loja
  await env.withSecurityRulesDisabled(async (ctx) => { await setDoc(doc(ctx.firestore(), 'usuarios/' + U), { nome: 'Dono', tipo: 'negocio' }); });
  S['usuarios/' + U] = { nome: 'Dono', tipo: 'negocio' };
  const NEG = 'neg_' + U;

  await ok('1. dono cadastra a loja com nome e produtos: nasce PENDENTE (as regras aceitam) e não aparece na vitrine nem abre', async () => {
    const cria = await tenta(() => setDoc(doc(cli(U), 'negocios/' + NEG), { uid: U, nome: 'Padaria', servicos: ['Pão R$1'], desc: 'x', aprovacaoStatus: 'pendente' })); assert(cria, 'cadastro recusado');
    S['negocios/' + NEG] = { uid: U, nome: 'Padaria', servicos: ['Pão R$1'], desc: 'x', aprovacaoStatus: 'pendente' };
    assert(!vitrine(NEG, AG), 'apareceu na vitrine'); assert.equal(await abre(U), false, 'abriu pendente');
  });
  await ok('2. o dono NÃO consegue aprovar a própria loja (status, publicaAte, auditoria) nem pelo cliente', async () => {
    assert.equal(await tenta(() => updateDoc(doc(cli(U), 'negocios/' + NEG), { aprovacaoStatus: 'aprovada' })), false);
    assert.equal(await tenta(() => updateDoc(doc(cli(U), 'negocios/' + NEG), { publicaAte: 9e12 })), false);
    assert.equal(await tenta(() => setDoc(doc(cli(U), 'lojas_autorizadas/' + U), { ate: 9e12 })), false);
    assert.equal(await tenta(() => setDoc(doc(cli(U), 'lojas_decisoes/x'), { decisao: 'aprovar' })), false);
  });
  await ok('3. a função decidirLoja recusa: sem login (401), usuário comum/dono da loja (403), e-mail do dono NÃO verificado (403), método GET (405)', async () => {
    const corpo = { negId: NEG, decisao: 'aprovar' };
    assert.equal((await chama(null, corpo)).code, 401); assert.equal((await chama('lixo', corpo)).code, 401);
    assert.equal((await chama('ok:' + U, corpo)).code, 403, 'dono da loja aprovou'); assert.equal((await chama('ok:Outro', corpo)).code, 403);
    assert.equal((await chama('ok:ADM:emailnv', corpo)).code, 403, 'e-mail não verificado'); assert.equal((await chama('ok:ADM:admin', corpo, 'GET')).code, 405);
    assert.equal(S['negocios/' + NEG].aprovacaoStatus, 'pendente'); assert.equal(audit, 0);
  });
  await ok('4. validações: id inválido, decisão inválida, pendência/recusa sem motivo, loja inexistente, uid do documento ≠ id', async () => {
    assert.equal((await chama('ok:ADM:admin', { negId: '../x', decisao: 'aprovar' })).code, 400);
    assert.equal((await chama('ok:ADM:admin', { negId: NEG, decisao: 'talvez' })).code, 400);
    assert.equal((await chama('ok:ADM:admin', { negId: NEG, decisao: 'pendencia' })).body.erro, 'motivo_obrigatorio');
    assert.equal((await chama('ok:ADM:admin', { negId: NEG, decisao: 'recusar', motivo: '  ' })).body.erro, 'motivo_obrigatorio');
    assert.equal((await chama('ok:ADM:admin', { negId: 'neg_Zzzzzzzzzz', decisao: 'aprovar' })).code, 404);
    S['negocios/neg_Qqqqqqqqqq'] = { uid: 'OUTRO', nome: 'x' }; assert.equal((await chama('ok:ADM:admin', { negId: 'neg_Qqqqqqqqqq', decisao: 'aprovar' })).body.erro, 'loja_inconsistente');
    delete S['negocios/neg_Qqqqqqqqqq']; assert.equal(audit, 0);
  });
  await ok('5. administrador (claim) pede ajustes com motivo → "pendencia", não publicada; dono corrige e reenvia pelas regras → volta a "pendente"', async () => {
    const r = await chama('ok:ADM:admin', { negId: NEG, decisao: 'pendencia', motivo: 'faltam fotos dos produtos' }); assert.equal(r.code, 200); assert.equal(r.body.status, 'pendencia');
    assert.equal(S['negocios/' + NEG].aprovacaoMotivo, 'faltam fotos dos produtos'); assert.equal(S['negocios/' + NEG].publicaAte, 0); assert.equal(S['negocios/' + NEG].aprovacaoPor, 'ADM'); await sincroniza(NEG);
    assert(!vitrine(NEG, AG)); assert.equal(await abre(U), false);
    assert.equal(await tenta(() => setDoc(doc(cli(U), 'negocios/' + NEG), { aprovacaoStatus: 'pendente', desc: 'com fotos' }, { merge: true })), true, 'reenvio recusado');
    S['negocios/' + NEG].aprovacaoStatus = 'pendente'; S['negocios/' + NEG].desc = 'com fotos';
  });
  await ok('6. administrador (e-mail do dono verificado) APROVA durante a campanha → publicaAte = fim da campanha: aparece na vitrine e a loja abre', async () => {
    const r = await chama('ok:ADM2:email', { negId: NEG, decisao: 'aprovar' }); assert.equal(r.code, 200); assert.equal(r.body.status, 'aprovada');
    assert.equal(S['negocios/' + NEG].publicaAte, LIB.CAMPANHA_ATE); assert.equal(S['negocios/' + NEG].aprovacaoStatus, 'aprovada'); await sincroniza(NEG);
    assert(vitrine(NEG, AG)); assert.equal(await abre(U), true, 'loja aprovada não abriu na campanha');
  });
  await ok('7. a aprovação NÃO substitui a cobrança: depois de 30/11/2026, loja aprovada SEM pagamento sai da vitrine e não abre', async () => {
    const dep = T('2026-12-02T12:00:00-03:00'); relogio('2026-12-02T12:00:00-03:00');
    assert(!vitrine(NEG, dep), 'continuou na vitrine sem pagar'); assert.equal(await abre(U), false, 'abriu sem pagamento');
    relogio('2026-11-30T23:00:00-03:00'); assert.equal(await abre(U), true, 'ainda é campanha'); relogio('2026-12-02T12:00:00-03:00');
  });
  await ok('8. pagamento registrado (script autorizar-loja) recalcula a publicação: volta à vitrine e abre; revogar tira de novo', async () => {
    const dep = T('2026-12-02T12:00:00-03:00');
    let r = await AL.executar({ db: fdb, uid: U, ate: '2027-01-31', exec: true, agora: dep }); assert(!r.erro); assert(r.loja && r.loja.ok);
    assert.equal(S['negocios/' + NEG].publicaAte, T('2027-01-31T23:59:59-03:00')); await sincroniza(NEG);
    await env.withSecurityRulesDisabled(async (ctx) => { await setDoc(doc(ctx.firestore(), 'lojas_autorizadas/' + U), JSON.parse(JSON.stringify(S['lojas_autorizadas/' + U]))); });
    assert(vitrine(NEG, dep)); assert.equal(await abre(U), true, 'pago e aprovado não abriu');
    r = await AL.executar({ db: fdb, uid: U, revogar: true, exec: true, agora: dep + 1000 }); assert(r.loja.ok);   // pagamento revogado → volta a valer só a campanha (já acabou)
    assert(S['negocios/' + NEG].publicaAte <= dep + 1000, 'publicaAte não encolheu'); await sincroniza(NEG);
    await env.withSecurityRulesDisabled(async (ctx) => { await setDoc(doc(ctx.firestore(), 'lojas_autorizadas/' + U), JSON.parse(JSON.stringify(S['lojas_autorizadas/' + U]))); });
    globalThis.__RELOGIO_SIMULADO = dep + 5000; assert.equal(await abre(U), false, 'abriu depois de revogado'); assert(!vitrine(NEG, dep + 5000));
  });
  await ok('9. pagamento SEM aprovação não publica nada: loja pendente + pago continua oculta', async () => {
    const U2 = 'Uxyz9876543', N2 = 'neg_' + U2; S['usuarios/' + U2] = { nome: 'D2' }; S['negocios/' + N2] = { uid: U2, nome: 'L2', aprovacaoStatus: 'pendente' };
    await AL.executar({ db: fdb, uid: U2, ate: '2027-06-30', exec: true, agora: T('2026-12-02T12:00:00-03:00') });
    assert(S['lojas_autorizadas/' + U2].ate > 0); assert.equal(S[ 'negocios/' + N2].publicaAte, undefined); assert(!vitrine(N2, T('2026-12-02T12:00:00-03:00')));
  });
  await ok('10. recusa com motivo tira a loja do ar e fica registrada na auditoria; repetir a mesma decisão é seguro', async () => {
    const antes = audit; const r = await chama('ok:ADM:admin', { negId: NEG, decisao: 'recusar', motivo: 'conteúdo fora das regras' }); assert.equal(r.code, 200);
    assert.equal(S['negocios/' + NEG].aprovacaoStatus, 'recusada'); assert.equal(S['negocios/' + NEG].publicaAte, 0); assert.equal(audit, antes + 1);
    const reg = Object.entries(S).filter(([k]) => k.startsWith('lojas_decisoes/')).map(([, v]) => v).pop(); assert(reg.negId === NEG && reg.porUid === 'ADM' && reg.decisao === 'recusar' && reg.motivo);
    const r2 = await chama('ok:ADM:admin', { negId: NEG, decisao: 'recusar', motivo: 'conteúdo fora das regras' }); assert.equal(r2.code, 200); assert.equal(S['negocios/' + NEG].publicaAte, 0);
  });
  await ok('11. script decidir-loja: lista por situação, simulação não grava, --executar grava, legado só atinge lojas sem status', async () => {
    S['negocios/neg_Leg0000001'] = { uid: 'Leg0000001', nome: 'Antiga' }; const antes = JSON.stringify(S['negocios/neg_Leg0000001']);
    const lista = await DL.listar(fdb); assert(lista.some((x) => x.negId === 'neg_Leg0000001' && /antiga/.test(x.situacao)));
    S['negocios/neg_Leg0000002'] = { uid: 'Leg0000002', nome: 'Outra antiga' };  // 4.4: aprovar loja antiga exige LISTAR o negId; não existe aprovação em massa
    assert.equal((await DL.executar({ db: fdb, legado: true, exec: true, agora: AG })).erro, 'informe_os_negIds'); assert.equal(S['negocios/neg_Leg0000002'].aprovacaoStatus, undefined);
    let r = await DL.executar({ db: fdb, legado: true, negIds: ['neg_Leg0000001'], exec: false, agora: AG }); assert(r.simulacao && r.aprovadas.includes('neg_Leg0000001')); assert.equal(JSON.stringify(S['negocios/neg_Leg0000001']), antes);
    r = await DL.executar({ db: fdb, legado: true, negIds: ['neg_Leg0000001'], exec: true, agora: AG }); assert.equal(S['negocios/neg_Leg0000001'].aprovacaoStatus, 'aprovada'); assert.equal(S['negocios/neg_Leg0000002'].aprovacaoStatus, undefined, 'aprovou loja que não foi listada'); assert.equal(S['negocios/neg_Leg0000001'].aprovacaoPor, 'script:decidir-loja.js');
    assert.equal(S['negocios/' + NEG].aprovacaoStatus, 'recusada', 'o legado mexeu em loja que já tinha status');
    const sim = await DL.executar({ db: fdb, negId: 'neg_Leg0000001', decisao: 'recusar', motivo: 'x', exec: false }); assert(sim.simulacao && S['negocios/neg_Leg0000001'].aprovacaoStatus === 'aprovada');
  });
  Module._load = orig; console.log('\nAPROVAÇÃO DE LOJA (simulado): ' + n + ' OK, ' + f + ' falharam'); process.exit(f ? 1 : 0);
})();
