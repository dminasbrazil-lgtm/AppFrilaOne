// Executa testar-regras.js com o AVALIADOR LOCAL (SIMULADO) no lugar do Emulador. Uso: node executar-simulado.js
// ATENÇÃO: resultado SIMULADO. Não aprova as regras; a aprovação exige `npm test` com o Emulador oficial.
const Module = require('module'), path = require('path');
const { rulesUnitTesting, firestoreMod } = require('./avaliador-local/firebase-falso.js');
const orig = Module._load;
Module._load = function (r, ...a) { if (r === '@firebase/rules-unit-testing') return rulesUnitTesting; if (r === 'firebase/firestore') return firestoreMod; return orig.call(this, r, ...a); };
globalThis.__EH_SIMULADO = true; globalThis.__FIRESTORE_ESTRITO = true; // permite fixar o relógio nos testes de data
process.chdir(path.join(__dirname));
console.log('*** MODO SIMULADO (avaliador local) — NÃO é o Emulador oficial ***\n');
require('./testar-regras.js');
if (process.argv.includes('--cobertura')) {
  const { _cobertura } = require('./avaliador-local/firebase-falso.js');
  process.on('exit', () => { console.log('\nCOBERTURA (avaliador local, SIMULADA):\n' + require('./relatorio-cobertura.js')(_cobertura, path.join(__dirname, '../../firestore-regras-v18.4.txt'))); });
}
