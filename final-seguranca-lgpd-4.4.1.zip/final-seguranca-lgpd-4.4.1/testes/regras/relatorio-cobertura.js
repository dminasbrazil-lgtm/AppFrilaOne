// Mostra (SIMULADO) quais coleção × operação × resultado os testes de regras exercitaram, comparando com as coleções do arquivo de regras.
// Uso: node executar-simulado.js --cobertura   (imprime a tabela no fim)
const fs = require('fs'), path = require('path');
module.exports = function (cobertura, regrasArquivo) {
  const txt = fs.readFileSync(regrasArquivo, 'utf8');
  const cols = []; const re = /match \/([A-Za-z_]+)\/\{/g; let m; while ((m = re.exec(txt))) if (!['databases', 'eventos'].includes(m[1])) cols.push(m[1]);
  ['config', 'conversas/mensagens', 'aceites_termos/eventos'].forEach((c) => { if (!cols.includes(c)) cols.push(c); });
  const OPS = ['get', 'list', 'create', 'update', 'delete'];
  const linhas = []; const faltam = [];
  for (const c of [...new Set(cols)].sort()) {
    const cel = OPS.map((op) => { const p = cobertura.get(c + '|' + op + '|permitido') || 0, n = cobertura.get(c + '|' + op + '|negado') || 0; return (p ? 'P' + p : '·') + '/' + (n ? 'N' + n : '·'); });
    linhas.push('| ' + c.padEnd(22) + ' | ' + cel.map((x) => x.padEnd(8)).join(' | ') + ' |');
  }
  return '| coleção                | get      | list     | create   | update   | delete   |\n|---|---|---|---|---|---|\n' + linhas.join('\n') + '\n(P = permitido, N = negado, número = quantas vezes os testes exercitaram; · = nunca)';
};
