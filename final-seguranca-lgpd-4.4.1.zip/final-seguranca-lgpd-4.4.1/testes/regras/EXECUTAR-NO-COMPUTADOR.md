# Como executar os testes das regras (v18.3) no seu computador

**Status: NÃO EXECUTADOS NO EMULADOR OFICIAL.** O ambiente onde o pacote foi preparado não baixa o Emulador (npm/JAR bloqueados). **As regras v18.3 não estão aprovadas.**

Existe um resultado **SIMULADO** (avaliador local próprio em `avaliador-local/`): **447/447 conforme o esperado**. Não é o Emulador, não valida sintaxe/semântica oficial (ex.: `request.time.toMillis()`) e **não vale como aprovação**.

## Requisitos
Node.js 18+ e Java 11+. Confira `node -v` e `java -version`. Internet na primeira vez.

## Comandos exatos (PowerShell, Mac ou Linux)
```
cd testes/regras
npm install
npm test
```
`npm test` primeiro roda `npm run pretest` (`preparar-regras.js`), que copia `../../firestore-regras-v18.4.txt` para `testes/regras/firestore.rules` (dentro da pasta do `firebase.json`, caminho válido no Windows); o teste carrega essa cópia. **Esperado:** nenhuma linha `FALHOU`, última linha `N/N conforme o esperado` (447/447 no simulador; no Emulador N esperado = 414, pois roda 1 cenário de data em vez de 4) e código de saída 0.

## Atenção
- Se a regra tiver erro de sintaxe/compilação, o Emulador mostra o erro **antes** dos testes — envie a mensagem inteira. Ponto de maior atenção: `request.time.toMillis()` em `cobrancaAtiva()`.
- Os testes de data: no simulador o relógio é fixado em 4 momentos (15/11, 30/11 23:30 BRT, 01/12 00:30 BRT, 02/12). No Emulador oficial roda **um** cenário, com a data real de hoje: antes de 01/12/2026 espera "permite" para conta de plano sem registro de acesso; depois, "bloqueia". Logo, no Emulador o total de testes pode ser menor que 436 — o que vale é **nenhuma linha FALHOU** e saída 0. O ramo pós-01/12 só é exercitado no Emulador depois dessa data (no simulador, já é).
- Se algo falhar: **não publique as regras**; envie as linhas `FALHOU` com `detalhe`.

## Simulado (opcional, não aprova nada)
`npm run test:simulado` · cobertura: `node executar-simulado.js --cobertura`.

## Mudanças deliberadas de expectativa (v17 → v18; v18.1 → v18.3 detalhadas em `docs/RELATORIO-CORRECOES-4.2.md`)
Três testes passaram de "permite" para "bloqueia" (`trial_fim`, `master_ativo:true`, e a antiga "limitação conhecida" de `trial_fim`), porque a proteção agora é permanente (sem chave). Nenhum outro teste teve expectativa alterada. Nada toca o Firebase real.
