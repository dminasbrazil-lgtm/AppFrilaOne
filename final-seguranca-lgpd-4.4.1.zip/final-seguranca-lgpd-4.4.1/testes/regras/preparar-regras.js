// Copia as regras OFICIAIS do projeto (../../firestore-regras-v18.4.txt) para ./firestore.rules, dentro da pasta deste firebase.json.
// Motivo: o firebase-tools só aceita de forma confiável caminhos de regras dentro da pasta do projeto (o firebase.json antigo apontava para ../../).
// A cópia é regerada a cada `npm test` (pretest) e a cada execução de testar-regras.js; nunca edite firestore.rules à mão.
const fs = require('fs'), path = require('path');
const ORIGEM = path.join(__dirname, '..', '..', 'firestore-regras-v18.4.txt'), DESTINO = path.join(__dirname, 'firestore.rules');
function preparar() { const txt = fs.readFileSync(ORIGEM); fs.writeFileSync(DESTINO, txt); return DESTINO; }
module.exports = preparar; module.exports.ORIGEM = ORIGEM; module.exports.DESTINO = DESTINO;
if (require.main === module) { console.log('Regras copiadas para ' + preparar()); }
