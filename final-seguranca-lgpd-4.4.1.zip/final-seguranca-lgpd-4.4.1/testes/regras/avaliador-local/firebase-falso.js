// Substitutos mínimos de '@firebase/rules-unit-testing' e 'firebase/firestore' que usam o avaliador local (SIMULADO).
'use strict';
const { makeEvaluator, FSet } = require('./avaliador.js');
const clone = (v) => v instanceof Date ? new Date(v.getTime()) : Array.isArray(v) ? v.map(clone) : (v && typeof v === 'object' && !v.__s) ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, clone(x)])) : v;
const store = new Map();
let evaluator = null, seq = 0;
const agora = () => (globalThis.__RELOGIO_SIMULADO ? new Date(globalThis.__RELOGIO_SIMULADO) : new Date()); // testes podem fixar a hora
const denied = () => { const e = new Error('7 PERMISSION_DENIED: negado pelas regras (simulado)'); e.code = 'permission-denied'; return e; };

const doc = (db, path) => ({ _t: 'doc', db, path });
const collection = (db, path) => ({ _t: 'col', db, path });
const where = (f, op, v) => ({ f, op, v });
const query = (col, ...c) => ({ _t: 'q', col, c });
const increment = (n) => ({ __s: 'inc', n });
const arrayUnion = (...a) => ({ __s: 'union', a });
const deleteField = () => ({ __s: 'del' });
const serverTimestamp = () => ({ __s: 'ts' });

function applyData(existing, data, merge) {
  const out = merge ? clone(existing || {}) : {};
  for (const [k, v] of Object.entries(data)) {
    if (v && v.__s) {
      if (v.__s === 'inc') out[k] = (typeof (existing || {})[k] === 'number' ? existing[k] : 0) + v.n;
      else if (v.__s === 'union') { const cur = Array.isArray((existing || {})[k]) ? existing[k].slice() : []; v.a.forEach((x) => { if (!cur.some((y) => JSON.stringify(y) === JSON.stringify(x))) cur.push(x); }); out[k] = cur; }
      else if (v.__s === 'del') delete out[k]; else if (v.__s === 'ts') out[k] = new Date();
    } else out[k] = clone(v);
  }
  return out;
}
function allow(db, op, path, before, after, newData) {
  if (db._bypass) return true;
  const r = before.get(path);
  const ok = evaluator.allowed({ op, path, auth: db._auth, resourceData: r === undefined ? null : r, newData, before, after, time: agora() });
  registrarCobertura(op, path, ok);
  return ok;
}
// Cobertura (medida no avaliador local): quais combinações coleção × operação × resultado os testes exercitaram.
const cobertura = new Map();
function registrarCobertura(op, path, ok) {
  const col = path.split('/').filter((_, i) => i % 2 === 0).join('/');   // usuarios/U1 → usuarios ; conversas/x/mensagens/y → conversas/mensagens
  const k = col + '|' + op + '|' + (ok ? 'permitido' : 'negado'); cobertura.set(k, (cobertura.get(k) || 0) + 1);
}
// executa uma lista de operações como lote atômico (também usado para operações simples)
function commit(db, ops) {
  const before = new Map(store); const after = new Map(store); const plan = [];
  for (const o of ops) {
    const cur = after.get(o.path);
    if (o.kind === 'delete') { plan.push({ op: 'delete', path: o.path, newData: undefined }); after.delete(o.path); }
    else if (o.kind === 'update') { if (cur === undefined) plan.push({ op: 'update', path: o.path, newData: applyData(null, o.data, true), missing: true }); else { const nd = applyData(cur, o.data, true); plan.push({ op: 'update', path: o.path, newData: nd }); after.set(o.path, nd); } }
    else { const exists = cur !== undefined; const nd = applyData(cur, o.data, !!o.merge); plan.push({ op: exists ? 'update' : 'create', path: o.path, newData: nd }); after.set(o.path, nd); }
  }
  for (const p of plan) { if (p.missing) throw denied(); if (!allow(db, p.op, p.path, before, after, p.newData)) throw denied(); }
  for (const [k] of [...store]) if (!after.has(k)) store.delete(k);
  for (const [k, v] of after) store.set(k, v);
}
const setDoc = async (ref, data, opts) => commit(ref.db, [{ kind: 'set', path: ref.path, data, merge: !!(opts && opts.merge) }]);
const updateDoc = async (ref, data) => commit(ref.db, [{ kind: 'update', path: ref.path, data }]);
const deleteDoc = async (ref) => commit(ref.db, [{ kind: 'delete', path: ref.path }]);
const addDoc = async (col, data) => { const id = 'auto' + (++seq); commit(col.db, [{ kind: 'set', path: col.path + '/' + id, data, merge: false }]); return doc(col.db, col.path + '/' + id); };
const getDoc = async (ref) => { const before = new Map(store); if (!allow(ref.db, 'get', ref.path, before, before)) throw denied(); const d = store.get(ref.path); return { exists: () => d !== undefined, data: () => d === undefined ? undefined : clone(d), id: ref.path.split('/').pop() }; };
function writeBatch(db) { const ops = []; return { set(ref, data, opts) { ops.push({ kind: 'set', path: ref.path, data, merge: !!(opts && opts.merge) }); return this; }, update(ref, data) { ops.push({ kind: 'update', path: ref.path, data }); return this; }, delete(ref) { ops.push({ kind: 'delete', path: ref.path }); return this; }, async commit() { commit(db, ops); } }; }
const getDocs = async (qOrCol) => {
  const col = qOrCol._t === 'q' ? qOrCol.col : qOrCol; const cons = qOrCol._t === 'q' ? qOrCol.c : [];
  const eqs = {}; cons.forEach((c) => { if (c.op === '==') eqs[c.f] = c.v; });
  const before = new Map(store);
  if (!col.db._bypass) { const okL = evaluator.allowed({ op: 'list', path: col.path, auth: col.db._auth, resourceData: eqs, newData: undefined, before, after: before, time: agora() }); registrarCobertura('list', col.path + '/x', okL); if (!okL) throw denied(); }
  const docs = [...store].filter(([k, v]) => k.startsWith(col.path + '/') && !k.slice(col.path.length + 1).includes('/') && cons.every((c) => c.op !== '==' || v[c.f] === c.v)).map(([k, v]) => ({ id: k.split('/').pop(), data: () => clone(v), exists: () => true }));
  return { docs, size: docs.length, empty: docs.length === 0, forEach: (f) => docs.forEach(f) };
};
const firestoreMod = { doc, collection, query, where, setDoc, updateDoc, deleteDoc, addDoc, getDoc, getDocs, writeBatch, increment, arrayUnion, deleteField, serverTimestamp };

async function initializeTestEnvironment(cfg) {
  evaluator = makeEvaluator(cfg.firestore.rules); store.clear();
  // Modo ESTRITO (ligado por executar-simulado.js): imita o Emulador/SDK, em que chamar firestore() DE NOVO no mesmo contexto depois de a instância
  // já existir dispara "Firestore has already been started and its settings can no longer be changed." (comportamento do SDK que o teste real mostrou).
  const mk = (auth, bypass) => { let usado = false; return { firestore: () => { if (globalThis.__FIRESTORE_ESTRITO && usado) throw new Error('Firestore has already been started and its settings can no longer be changed.'); usado = true; return { _auth: auth, _bypass: !!bypass }; } }; };
  return {
    authenticatedContext: (uid, claims) => mk({ uid, token: Object.assign({ user_id: uid, sub: uid, firebase: { sign_in_provider: 'custom' } }, claims || {}) }),
    unauthenticatedContext: () => mk(null),
    withSecurityRulesDisabled: async (cb) => cb(mk(null, true)),
    clearFirestore: async () => store.clear(), cleanup: async () => {}
  };
}
const assertSucceeds = async (p) => p;
const assertFails = async (p) => { try { await p; } catch (e) { if (e && e.code === 'permission-denied') return; throw e; } throw new Error('esperava falha de permissão, mas a operação foi permitida'); };
module.exports = { rulesUnitTesting: { initializeTestEnvironment, assertSucceeds, assertFails }, firestoreMod, _store: store, _cobertura: cobertura };
