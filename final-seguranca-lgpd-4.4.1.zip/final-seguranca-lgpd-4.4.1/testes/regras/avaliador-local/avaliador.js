// AVALIADOR LOCAL DE REGRAS DO FIRESTORE — SIMULADO. NÃO substitui o Emulador oficial.
// Implementa o subconjunto da linguagem de regras usado pelo FrilaOne (funções, let, &&/||/! com absorção de erro,
// in, is, ?:, get/exists/getAfter/existsAfter, diff().affectedKeys(), keys().hasOnly/hasAny/hasAll, matches, toSet, etc.).
// Serve para detectar erros de lógica ao alterar as regras; a aprovação só vale com o Emulador (ver EXECUTAR-NO-COMPUTADOR.md).
'use strict';
class RuleError extends Error {}
const err = (m) => { throw new RuleError(m); };

// ---------- conjuntos / estruturas ----------
class FSet { constructor(a) { this.items = []; for (const x of (a || [])) if (!this.has(x)) this.items.push(x); } has(x) { return this.items.some((y) => eq(x, y)); }
  get size() { return this.items.length; } }
function eq(a, b) {
  if (a instanceof FSet || b instanceof FSet) { if (!(a instanceof FSet && b instanceof FSet)) return false; return a.size === b.size && a.items.every((x) => b.has(x)); }
  if (a instanceof Date && b instanceof Date) return a.getTime() === b.getTime();
  if (Array.isArray(a) && Array.isArray(b)) return a.length === b.length && a.every((x, i) => eq(x, b[i]));
  if (a && b && typeof a === 'object' && typeof b === 'object' && !Array.isArray(a) && !Array.isArray(b)) {
    const ka = Object.keys(a), kb = Object.keys(b); return ka.length === kb.length && ka.every((k) => k in b && eq(a[k], b[k])); }
  return a === b;
}
class Path { constructor(s) { this.s = s; } toString() { return this.s; } }

// ---------- léxico de expressões ----------
function lex(src) {
  const toks = []; let i = 0; const n = src.length;
  const operandEnd = () => { const t = toks[toks.length - 1]; return t && (t.k === 'id' || t.k === 'num' || t.k === 'str' || t.v === ')' || t.v === ']'); };
  while (i < n) {
    const c = src[i];
    if (/\s/.test(c)) { i++; continue; }
    if (src.startsWith('//', i)) { while (i < n && src[i] !== '\n') i++; continue; }
    if (src.startsWith('/*', i)) { i = src.indexOf('*/', i) + 2; continue; }
    if (c === '"' || c === "'") { let j = i + 1, s = ''; while (j < n && src[j] !== c) { if (src[j] === '\\') { s += src[j + 1]; j += 2; } else s += src[j++]; } toks.push({ k: 'str', v: s }); i = j + 1; continue; }
    if (/[0-9]/.test(c)) { let j = i; while (j < n && /[0-9.]/.test(src[j])) j++; toks.push({ k: 'num', v: parseFloat(src.slice(i, j)) }); i = j; continue; }
    if (/[A-Za-z_]/.test(c)) { let j = i; while (j < n && /[A-Za-z0-9_]/.test(src[j])) j++; toks.push({ k: 'id', v: src.slice(i, j) }); i = j; continue; }
    if (c === '/' && !operandEnd()) { // literal de caminho
      let j = i, depth = 0; const parts = [];
      while (j < n) {
        if (src.startsWith('$(', j)) { let d = 1, k = j + 2; while (k < n && d) { if (src[k] === '(') d++; else if (src[k] === ')') d--; k++; } parts.push({ expr: src.slice(j + 2, k - 1) }); j = k; continue; }
        if (/[\s),;\]]/.test(src[j])) break; // fim do caminho
        let k = j; while (k < n && !/[\s),;\]$]/.test(src[k]) ) k++; if (k === j) break; parts.push(src.slice(j, k)); j = k;
      }
      toks.push({ k: 'path', v: parts }); i = j; continue;
    }
    const three = src.slice(i, i + 2);
    if (['&&', '||', '==', '!=', '<=', '>='].includes(three)) { toks.push({ k: 'op', v: three }); i += 2; continue; }
    toks.push({ k: 'op', v: c }); i++;
  }
  return toks;
}

// ---------- parser de expressões (AST) ----------
function parseExpr(src) {
  const t = lex(src); let p = 0;
  const peek = () => t[p], next = () => t[p++];
  const isOp = (v) => t[p] && (t[p].k === 'op') && t[p].v === v;
  const isId = (v) => t[p] && t[p].k === 'id' && t[p].v === v;
  const expect = (v) => { if (!isOp(v)) throw new Error('esperado ' + v + ' em: ' + src); p++; };
  function ternary() { const c = orx(); if (isOp('?')) { p++; const a = ternary(); expect(':'); const b = ternary(); return { t: 'cond', c, a, b }; } return c; }
  function orx() { let l = andx(); while (isOp('||')) { p++; l = { t: 'or', l, r: andx() }; } return l; }
  function andx() { let l = eqx(); while (isOp('&&')) { p++; l = { t: 'and', l, r: eqx() }; } return l; }
  function eqx() { let l = relx(); while (isOp('==') || isOp('!=')) { const o = next().v; l = { t: 'bin', o, l, r: relx() }; } return l; }
  function relx() { let l = addx();
    for (;;) { if (isOp('<') || isOp('>') || isOp('<=') || isOp('>=')) { const o = next().v; l = { t: 'bin', o, l, r: addx() }; }
      else if (isId('in')) { p++; l = { t: 'in', l, r: addx() }; }
      else if (isId('is')) { p++; l = { t: 'is', l, ty: next().v }; } else break; } return l; }
  function addx() { let l = mulx(); while (isOp('+') || isOp('-')) { const o = next().v; l = { t: 'bin', o, l, r: mulx() }; } return l; }
  function mulx() { let l = unx(); while (isOp('*') || isOp('/') || isOp('%')) { const o = next().v; l = { t: 'bin', o, l, r: unx() }; } return l; }
  function unx() { if (isOp('!')) { p++; return { t: 'not', e: unx() }; } if (isOp('-')) { p++; return { t: 'neg', e: unx() }; } return post(); }
  function post() { let e = prim();
    for (;;) { if (isOp('.')) { p++; const name = next().v; if (isOp('(')) { p++; const args = []; if (!isOp(')')) { do { args.push(ternary()); } while (isOp(',') && ++p); } expect(')'); e = { t: 'mcall', o: e, name, args }; } else e = { t: 'prop', o: e, name }; }
      else if (isOp('[')) { p++; const i = ternary(); expect(']'); e = { t: 'idx', o: e, i }; } else break; } return e; }
  function prim() { const x = next(); if (!x) throw new Error('fim inesperado em: ' + src);
    if (x.k === 'num') return { t: 'lit', v: x.v }; if (x.k === 'str') return { t: 'lit', v: x.v };
    if (x.k === 'path') return { t: 'path', parts: x.v.map((q) => typeof q === 'string' ? q : { e: parseExpr(q.expr) }) };
    if (x.k === 'id') { if (x.v === 'true') return { t: 'lit', v: true }; if (x.v === 'false') return { t: 'lit', v: false }; if (x.v === 'null') return { t: 'lit', v: null };
      if (isOp('(')) { p++; const args = []; if (!isOp(')')) { do { args.push(ternary()); } while (isOp(',') && ++p); } expect(')'); return { t: 'call', name: x.v, args }; }
      return { t: 'var', name: x.v }; }
    if (x.v === '(') { const e = ternary(); expect(')'); return e; }
    if (x.v === '[') { const items = []; if (!isOp(']')) { do { items.push(ternary()); } while (isOp(',') && ++p); } expect(']'); return { t: 'list', items }; }
    if (x.v === '{') { expect('}'); return { t: 'lit', v: {} }; }
    throw new Error('token inesperado ' + x.v + ' em: ' + src); }
  const e = ternary(); if (p < t.length) throw new Error('sobrou texto em: ' + src); return e;
}

// ---------- parser de regras ----------
function parseRules(text) {
  let i = 0; const n = text.length;
  const ws = () => { for (;;) { while (i < n && /\s/.test(text[i])) i++; if (text.startsWith('//', i)) { while (i < n && text[i] !== '\n') i++; } else if (text.startsWith('/*', i)) { i = text.indexOf('*/', i) + 2; } else break; } };
  const word = () => { ws(); const m = /^[A-Za-z_][A-Za-z0-9_.]*/.exec(text.slice(i)); return m ? m[0] : ''; };
  function readExprUntilSemicolon() { let d = 0, j = i, q = null; for (; j < n; j++) { const c = text[j];
      if (q) { if (c === '\\') j++; else if (c === q) q = null; continue; }
      if (c === '"' || c === "'") { q = c; continue; }
      if (text.startsWith('//', j)) { while (j < n && text[j] !== '\n') j++; continue; }
      if (c === '(' || c === '[' || c === '{') d++; else if (c === ')' || c === ']' || c === '}') d--; else if (c === ';' && d === 0) break; }
    const s = text.slice(i, j); i = j + 1; return s; }
  function block() { // lê { ... } de um match/service
    ws(); if (text[i] !== '{') throw new Error('esperava { em ' + i); i++;
    const b = { funcs: {}, allows: [], matches: [] };
    for (;;) { ws(); if (text[i] === '}') { i++; return b; }
      const w = word();
      if (w === 'function') { i += 8; ws(); const name = /^[A-Za-z_][A-Za-z0-9_]*/.exec(text.slice(i))[0]; i += name.length; ws(); i++; const pr = text.slice(i, text.indexOf(')', i)); i = text.indexOf(')', i) + 1;
        const params = pr.split(',').map((s) => s.trim()).filter(Boolean); ws(); i++; const lets = []; let ret = null;
        for (;;) { ws(); if (text[i] === '}') { i++; break; } const w2 = word();
          if (w2 === 'let') { i += 3; ws(); const nm = /^[A-Za-z_][A-Za-z0-9_]*/.exec(text.slice(i))[0]; i += nm.length; ws(); i++; lets.push([nm, parseExpr(readExprUntilSemicolon())]); }
          else if (w2 === 'return') { i += 6; ret = parseExpr(readExprUntilSemicolon()); } else throw new Error('função: instrução desconhecida em ' + i + ': ' + text.slice(i, i + 40)); }
        b.funcs[name] = { params, lets, ret }; }
      else if (w === 'match') { i += 5; ws(); let j = i; for (;;) { if (j >= n) throw new Error('match'); if (text[j] === '{') { if (text[j - 1] === '/') { j = text.indexOf('}', j) + 1; continue; } break; } j++; }
        const pathTxt = text.slice(i, j).trim(); i = j; const inner = block(); inner.path = pathTxt.split('/').filter(Boolean); b.matches.push(inner); }
      else if (w === 'allow') { i += 5; ws(); const mEnd = text.indexOf(':', i); const methods = text.slice(i, mEnd).split(',').map((s) => s.trim()); i = mEnd + 1; ws();
        let cond = { t: 'lit', v: true }; if (word() === 'if') { i += 2; cond = parseExpr(readExprUntilSemicolon()); } else { readExprUntilSemicolon(); cond = { t: 'lit', v: true }; }
        b.allows.push({ methods, cond }); }
      else if (w === 'rules_version') { i = text.indexOf(';', i) + 1; }
      else if (w === 'service') { i += 7; const inner = block(); return Object.assign(inner, { __service: true }); }
      else throw new Error('regra: palavra desconhecida "' + w + '" em ' + i + ': ' + text.slice(i, i + 50)); } }
  ws(); if (word() === 'rules_version') { i = text.indexOf(';', i) + 1; } ws();
  if (word() !== 'service') throw new Error('esperava service'); i += 7; ws(); i = text.indexOf('{', i);
  return block();
}

// ---------- avaliação ----------
const OPS = { get: ['read', 'get'], list: ['read', 'list'], create: ['write', 'create'], update: ['write', 'update'], delete: ['write', 'delete'] };
const TS = { __timestamp: true }; // objeto global 'timestamp' das regras (só timestamp.date foi implementado)
function makeEvaluator(rulesText) {
  const root = parseRules(rulesText);
  function typeOf(v) { if (v === null) return 'null'; if (typeof v === 'boolean') return 'bool'; if (typeof v === 'number') return Number.isInteger(v) ? 'int' : 'float'; if (typeof v === 'string') return 'string'; if (Array.isArray(v)) return 'list'; if (v instanceof FSet) return 'set'; if (v instanceof Date) return 'timestamp'; if (v instanceof Path) return 'path'; return 'map'; }
  function ev(node, env) {
    switch (node.t) {
      case 'lit': return node.v;
      case 'var': { if (node.name in env.vars) return env.vars[node.name]; err('variável desconhecida ' + node.name); break; }
      case 'list': return node.items.map((x) => ev(x, env));
      case 'path': return new Path(('/' + node.parts.map((q) => typeof q === 'string' ? q : String(ev(q.e, env))).join('')).replace(/\/+/g, '/'));
      case 'not': { const v = ev(node.e, env); if (typeof v !== 'boolean') err('! em não-booleano'); return !v; }
      case 'neg': return -ev(node.e, env);
      case 'and': { let l, r, le = null, re = null; try { l = ev(node.l, env); } catch (e) { if (!(e instanceof RuleError)) throw e; le = e; }
        if (le === null && l === false) return false; try { r = ev(node.r, env); } catch (e) { if (!(e instanceof RuleError)) throw e; re = e; }
        if (re === null && r === false) return false; if (le) throw le; if (re) throw re; if (typeof l !== 'boolean' || typeof r !== 'boolean') err('&& em não-booleano'); return l && r; }
      case 'or': { let l, r, le = null, re = null; try { l = ev(node.l, env); } catch (e) { if (!(e instanceof RuleError)) throw e; le = e; }
        if (le === null && l === true) return true; try { r = ev(node.r, env); } catch (e) { if (!(e instanceof RuleError)) throw e; re = e; }
        if (re === null && r === true) return true; if (le) throw le; if (re) throw re; if (typeof l !== 'boolean' || typeof r !== 'boolean') err('|| em não-booleano'); return l || r; }
      case 'cond': { const c = ev(node.c, env); if (typeof c !== 'boolean') err('?: em não-booleano'); return c ? ev(node.a, env) : ev(node.b, env); }
      case 'in': { const l = ev(node.l, env), r = ev(node.r, env);
        if (Array.isArray(r)) return r.some((x) => eq(x, l)); if (r instanceof FSet) return r.has(l);
        if (r && typeof r === 'object' && !(r instanceof Date)) { if (typeof l !== 'string') err('in: chave não-string'); return Object.prototype.hasOwnProperty.call(r, l); } err('in: operando inválido'); break; }
      case 'is': { const v = ev(node.l, env); const ty = typeOf(v); if (node.ty === 'number') return ty === 'int' || ty === 'float'; if (node.ty === 'int') return ty === 'int'; return ty === node.ty; }
      case 'bin': { const l = ev(node.l, env), r = ev(node.r, env);
        switch (node.o) { case '==': return eq(l, r); case '!=': return !eq(l, r);
          case '<': case '>': case '<=': case '>=': { if (typeof l !== typeof r || (l === null)) err('comparação de tipos diferentes'); const a = l instanceof Date ? l.getTime() : l, b = r instanceof Date ? r.getTime() : r; return node.o === '<' ? a < b : node.o === '>' ? a > b : node.o === '<=' ? a <= b : a >= b; }
          case '+': if ((typeof l === 'number' && typeof r === 'number') || (typeof l === 'string' && typeof r === 'string')) return l + r; if (Array.isArray(l) && Array.isArray(r)) return l.concat(r); err('+ inválido'); break;
          case '-': case '*': case '/': case '%': if (typeof l !== 'number' || typeof r !== 'number') err('aritmética em não-número'); return node.o === '-' ? l - r : node.o === '*' ? l * r : node.o === '/' ? l / r : l % r; } break; }
      case 'idx': { const o = ev(node.o, env), i = ev(node.i, env); if (Array.isArray(o)) { if (i < 0 || i >= o.length) err('índice fora'); return o[i]; } if (o && typeof o === 'object') { if (!(i in o)) err('chave ausente ' + i); return o[i]; } err('índice inválido'); break; }
      case 'prop': { const o = ev(node.o, env);
        if (o && typeof o === 'object' && !Array.isArray(o) && !(o instanceof FSet) && !(o instanceof Date) && !(o instanceof Path)) { if (Object.prototype.hasOwnProperty.call(o, node.name)) return o[node.name]; err('campo ausente: ' + node.name); }
        err('acesso a campo de valor inválido: ' + node.name); break; }
      case 'call': return callFn(node, env);
      case 'mcall': return callMethod(node, env);
    }
    throw new Error('nó desconhecido ' + node.t);
  }
  function docVal(env, path, after) { const s = String(path); const m = /^\/databases\/[^/]+\/documents\/(.+)$/.exec(s); if (!m) err('caminho inválido'); const st = after ? env.after : env.before; const d = st.get(m[1]); return d; }
  function callFn(node, env) {
    const nm = node.name;
    if (nm === 'get' || nm === 'getAfter') { const d = docVal(env, ev(node.args[0], env), nm === 'getAfter'); if (!d) err('documento inexistente'); return { data: d, id: '' }; }
    if (nm === 'exists' || nm === 'existsAfter') { return !!docVal(env, ev(node.args[0], env), nm === 'existsAfter'); }
    // função definida pelo usuário (escopo mais interno primeiro)
    for (let s = env.scope; s; s = s.parent) if (s.funcs[nm]) { const f = s.funcs[nm]; const vars = Object.assign({}, env.baseVars); f.params.forEach((pn, k) => { vars[pn] = ev(node.args[k], env); });
      const fe = Object.assign({}, env, { vars }); for (const [ln, le] of f.lets) vars[ln] = ev(le, fe); return ev(f.ret, fe); }
    err('função desconhecida ' + nm);
  }
  function callMethod(node, env) {
    const o = ev(node.o, env); const a = node.args.map((x) => ev(x, env)); const nm = node.name;
    const toArr = (x) => x instanceof FSet ? x.items : x;
    if (nm === 'get') { if (!o || typeof o !== 'object' || Array.isArray(o)) err('get em não-mapa'); return Object.prototype.hasOwnProperty.call(o, a[0]) ? o[a[0]] : a[1]; }
    if (nm === 'keys') { if (!o || typeof o !== 'object') err('keys'); return new FSet(Object.keys(o)); }
    if (nm === 'diff') { const keys = new Set([...Object.keys(o), ...Object.keys(a[0])]); const ch = []; keys.forEach((k) => { if (!(k in o) || !(k in a[0]) || !eq(o[k], a[0][k])) ch.push(k); }); return { __diff: true, affectedKeys: () => new FSet(ch) }; }
    if (nm === 'affectedKeys') return o.affectedKeys();
    if (nm === 'hasOnly') { const s = new FSet(toArr(a[0])); return toArr(o).every((x) => s.has(x)); }
    if (nm === 'hasAny') { const s = new FSet(toArr(a[0])); return toArr(o).some((x) => s.has(x)); }
    if (nm === 'hasAll') { const s = new FSet(toArr(o)); return toArr(a[0]).every((x) => s.has(x)); }
    if (nm === 'toSet') return new FSet(toArr(o));
    if (nm === 'size') { if (typeof o === 'string' || Array.isArray(o)) return o.length; if (o instanceof FSet) return o.size; return Object.keys(o).length; }
    if (nm === 'matches') { if (typeof o !== 'string') err('matches'); return new RegExp('^(?:' + a[0] + ')$').test(o); }
    if (nm === 'toMillis') { if (!(o instanceof Date)) err('toMillis em não-timestamp'); return o.getTime(); }
    if (nm === 'date' && o && o.__timestamp) { if (a.length !== 3 || a.some((x) => !Number.isInteger(x))) err('timestamp.date(ano, mês, dia)'); return new Date(Date.UTC(a[0], a[1] - 1, a[2])); }
    if (nm === 'concat') return o.concat(a[0]);
    err('método desconhecido ' + nm);
  }
  // casamento de caminho
  function matchPath(pattern, segs, vars) { // devolve resto de segs ou null
    let k = 0; for (const p of pattern) { const m = /^\{([A-Za-z_][A-Za-z0-9_]*)(=\*\*)?\}$/.exec(p);
      if (m && m[2]) { vars[m[1]] = segs.slice(k).join('/'); return []; }
      if (k >= segs.length) return null; if (m) vars[m[1]] = segs[k]; else if (p !== segs[k]) return null; k++; }
    return segs.slice(k); }
  // avalia: devolve true/false. Para "list", path é o da COLEÇÃO e resourceData são as restrições de igualdade da consulta.
  function allowed(opts) {
    const { op, path, auth, resourceData, newData, before, after, time } = opts;
    const isList = op === 'list';
    const segs = path.split('/').concat(isList ? ['\u0000'] : []);
    const methods = OPS[op];
    const req = { auth: auth ? { uid: auth.uid, token: auth.token } : null, time, method: op, path: new Path('/databases/(default)/documents/' + path) };
    if (newData !== undefined && newData !== null) req.resource = { data: newData };
    let ok = false;
    function matchPathLocal(pattern, rest, vars) {
      let k = 0;
      for (const p of pattern) { const m = /^\{([A-Za-z_][A-Za-z0-9_]*)(=\*\*)?\}$/.exec(p);
        if (m && m[2]) { vars[m[1]] = rest.slice(k).join('/'); return []; }
        if (k >= rest.length) return null;
        if (m) { if (rest[k] !== '\u0000') vars[m[1]] = rest[k]; } else if (p !== rest[k]) return null;
        k++; }
      return rest.slice(k);
    }
    function walkDocs(block, rest, vars, parentScope) {
      const scope = { funcs: block.funcs, parent: parentScope };
      for (const m of block.matches) {
        const v2 = Object.assign({}, vars); const r = matchPathLocal(m.path, rest, v2); if (r === null) continue;
        const scope2 = { funcs: m.funcs, parent: scope };
        if (r.length === 0) {
          for (const a of m.allows) { if (!a.methods.some((x) => methods.includes(x))) continue;
            const vv = Object.assign({}, v2, { database: '(default)', request: req, timestamp: TS });
            if (resourceData !== undefined && resourceData !== null) vv.resource = { data: resourceData, id: segs[segs.length - 1] };
            const baseVars = { database: '(default)', request: req, timestamp: TS }; if (vv.resource) baseVars.resource = vv.resource;
            const env = { vars: vv, baseVars, scope: scope2, before, after };
            try { if (ev(a.cond, env) === true) ok = true; } catch (e) { if (!(e instanceof RuleError)) throw e; } } }
        else walkDocs(m, r, v2, scope2);
      }
    }
    for (const m of root.matches) { const v = {}; const rem = matchPathLocal(m.path, ['databases', '(default)', 'documents', ...segs], v); if (rem !== null) walkDocs(m, rem, v, { funcs: root.funcs, parent: null }); }
    return ok;
  }
  return { allowed };
}
module.exports = { makeEvaluator, FSet, RuleError, eq };
