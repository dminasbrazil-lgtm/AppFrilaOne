// Prova que a limpeza de emergências identifica só os vencidos, usa o campo certo, e começa em simulação.
const assert=require('assert');const {executar}=require('../migracao/limpar-emergencias-expiradas.js');
const D=86400e3,agora=Date.parse('2026-10-12T12:00:00Z');
function mk(){const s={
 'emergencias/velho1':{uid:'A',expiraEm:agora-1*D},'emergencias/velho2':{uid:'B',expiraEm:agora-100*D},
 'emergencias/limite':{uid:'A',expiraEm:agora},'emergencias/recente':{uid:'A',expiraEm:agora+89*D},
 'emergencias/semdata':{uid:'A'},'emergencias/texto':{uid:'C',expiraEm:'2020-01-01'},'emergencias/nulo':{uid:'C',expiraEm:null},
 'usuarios/A':{},'pagamentos/p':{uid:'A'},'agendamentos/x':{expiraEm:1}};
 const db={collection:c=>({where:(f,o,v)=>({get:async()=>g(c,x=>x[f]===v)}),get:async()=>g(c,()=>true)}),batch:()=>{const ops=[];return {delete:r=>ops.push(r.p),commit:async()=>ops.forEach(p=>delete s[p])}}};
 const g=async(c,fl)=>{const docs=Object.keys(s).filter(k=>k.startsWith(c+'/')&&fl(s[k])).map(k=>({id:k.split('/')[1],data:()=>s[k],ref:{p:k}}));return {forEach:f=>docs.forEach(f)}};
 return {s,db}}
(async()=>{let n=0;const t=(nome,f)=>f().then(()=>{n++;console.log('OK     | '+nome)},e=>{console.log('FALHOU | '+nome+' -> '+e.message);process.exitCode=1});
 await t('simulação (padrão) identifica 2 vencidos e não apaga nada',async()=>{const {s,db}=mk();const antes=Object.keys(s).length;const r=await executar({db,agora,apagar:false});assert.equal(r.vencidos.length,2);assert.equal(Object.keys(s).length,antes);assert.equal(r.apagados,0)});
 await t('registros recentes, no limite exato e sem data/ inválidos NUNCA são apagados',async()=>{const {s,db}=mk();const r=await executar({db,agora,apagar:true});assert.equal(r.apagados,2);for(const k of ['limite','recente','semdata','texto','nulo'])assert(s['emergencias/'+k],k);assert(!s['emergencias/velho1']&&!s['emergencias/velho2']);assert.deepEqual(r.semData.sort(),['nulo','semdata','texto'])});
 await t('só mexe na coleção emergencias (outras coleções, mesmo com expiraEm vencido, ficam)',async()=>{const {s,db}=mk();await executar({db,agora,apagar:true});assert(s['usuarios/A']&&s['pagamentos/p']&&s['agendamentos/x'])});
 await t('filtro --uid restringe a uma pessoa (outra pessoa com vencido fica)',async()=>{const {s,db}=mk();const r=await executar({db,agora,apagar:true,uid:'A'});assert.equal(r.apagados,1);assert(!s['emergencias/velho1']);assert(s['emergencias/velho2'])});
 console.log('EMERGÊNCIAS: '+n+'/4 OK');})();
