const Module=require('module'); const path=__dirname+'/../functions/';
const L=require(path+'assinatura-lib.js'); const assert=require('assert');
// ---- lib
assert.equal(L.planoDaConta({tipo:'prestador'}),'golden'); assert.equal(L.planoDaConta({tipo:'trabalhador'}),''); assert.equal(L.planoDaConta({tipo:'negocio'}),'diamond'); assert.equal(L.planoDaConta({tipo:'prestador',master_ativo:true}),'master');
const out=Date.parse('2026-10-12T12:00:00-03:00'); assert.equal(L.inicioCobranca(out,null),L.PRIMEIRA_COBRANCA);
const dez=Date.parse('2026-12-10T12:00:00-03:00'); assert.equal(L.inicioCobranca(dez,null),dez+7*86400e3);
assert.equal(L.inicioCobranca(out,out+10*86400e3),out+10*86400e3);
assert(L.emailValido('a@b.co')&&!L.emailValido('ab'));
const c=L.camposDoPreapproval({status:'authorized',next_payment_date:'2027-01-01T12:00:00.000-03:00',auto_recurring:{start_date:'2026-12-01T09:00:00.000-03:00'},last_four_digits:'4242'},{});
assert.equal(c.status,'authorized'); assert(c.nextBillingAt&&c.firstChargeAt); assert.equal(c.cartaoFinal,'4242'); assert.equal(c.pagamentoRecusado,false);
const cc=L.camposDoPreapproval({status:'cancelled',next_payment_date:'2027-01-01T12:00:00.000-03:00'},{});
assert.equal(cc.acessoAte,cc.nextBillingAt);
// ---- handlers com Firebase e MP falsos
const store={}; const FV={delete:()=>({__del:true})};
function docRef(col,id){return {get:async()=>({exists:!!(store[col+'/'+id]),data:()=>store[col+'/'+id]}),set:async(v,o)=>{const cur=(o&&o.merge&&store[col+'/'+id])||{};const n={...cur};for(const k in v){if(v[k]&&v[k].__del)delete n[k];else n[k]=v[k];}store[col+'/'+id]=n;}}}
const fakeAdmin={initializeApp(){},auth:()=>({verifyIdToken:async t=>{if(t==='ok')return{uid:'u1'};throw new Error('x')}}),firestore:Object.assign(()=>({collection:c=>({doc:i=>docRef(c,i)})}),{FieldValue:FV})};
const handlers={};
const fakeFns={runWith:()=>({region:()=>({https:{onRequest:h=>h}})})};
const orig=Module._load; Module._load=function(r,...a){if(r==='firebase-functions/v1')return fakeFns; if(r==='firebase-admin')return fakeAdmin; return orig.call(this,r,...a)};
const mpCalls=[]; let preState={};
global.fetch=async(url,o)=>{const m=o.method;const p=url.replace('https://api.mercadopago.com','');mpCalls.push(m+' '+p);
  const R=(b,ok=true,st=200)=>({ok,status:st,json:async()=>b});
  if(m==='POST'&&p==='/preapproval'){const b=JSON.parse(o.body);const id='PRE'+mpCalls.length;preState[id]={id,status:'pending',external_reference:b.external_reference,auto_recurring:b.auto_recurring};return R({id,init_point:'https://mp/ckout/'+id});}
  if(m==='GET'&&p.startsWith('/preapproval/'))return R(preState[p.split('/')[2]]);
  if(m==='PUT'&&p.startsWith('/preapproval/')){const id=p.split('/')[2];Object.assign(preState[id],JSON.parse(o.body));return R(preState[id]);}
  return R({},false,404)};
process.env.MP_ACCESS_TOKEN='TEST'; process.env.MP_WEBHOOK_SECRET='segredo-de-teste';
const crypto=require('crypto');
const assinar=(id,reqId,ts,seg='segredo-de-teste')=>'ts='+ts+',v1='+crypto.createHmac('sha256',seg).update((id?'id:'+String(id).toLowerCase()+';':'')+'request-id:'+reqId+';ts:'+ts+';').digest('hex');
const hook=async(tipo,id,over={})=>{const w=mkres();const rid=over.rid===undefined?'req-'+Math.random():over.rid;const hd={};if(rid)hd['x-request-id']=rid;const sig=over.sig!==undefined?over.sig:assinar(id,rid,over.ts||'1704908010',over.seg);if(sig)hd['x-signature']=sig;await A.webhookMercadoPago({method:'POST',headers:hd,body:{type:tipo,data:{id}},query:{'data.id':over.qid!==undefined?over.qid:id,type:tipo}},w);return w;};
const A=require(path+'assinatura.js');
const mkres=()=>{const r={code:200,body:null,hdr:{}};r.status=c=>{r.code=c;return r};r.json=b=>{r.body=b;return r};r.send=b=>{r.body=b;return r};r.set=(k,v)=>{r.hdr[k]=v};return r};
const call=async(h,body,tok='ok',method='POST')=>{const rs=mkres();await h({method,headers:{authorization:tok?'Bearer '+tok:'',origin:'https://frilaone.com.br'},body,query:{}},rs);return rs};
(async()=>{
 let r=await call(A.criarAssinatura,{emailMP:'a@b.com'},null); assert.equal(r.code,401);
 r=await call(A.criarAssinatura,{emailMP:'x'}); assert.equal(r.body.erro,'email_invalido');
 store['usuarios/u1']={tipo:'trabalhador'}; r=await call(A.criarAssinatura,{emailMP:'a@b.com'}); assert.equal(r.body.erro,'plano_indisponivel');
 store['usuarios/u1']={tipo:'prestador'}; r=await call(A.criarAssinatura,{emailMP:'a@b.com'}); assert(r.body.ok&&r.body.url,JSON.stringify(r.body));
 const id=store['assinaturas/u1'].preapprovalId; assert.equal(store['assinaturas/u1'].status,'pending'); assert.equal(store['assinaturas/u1'].valor,14.9);
 // MP autoriza -> webhook
 preState[id].status='authorized'; preState[id].next_payment_date='2026-12-01T09:00:00.000-03:00';
 let w=await hook('subscription_preapproval',id); assert.equal(w.code,200);
 assert.equal(store['assinaturas/u1'].status,'authorized');
 r=await call(A.criarAssinatura,{emailMP:'a@b.com'}); assert.equal(r.body.erro,'ja_ativa');
 // troca de cartão
 r=await call(A.criarAssinatura,{emailMP:'a@b.com',trocar:true}); assert(r.body.ok); const nova=store['assinaturas/u1'].novaPreapprovalId; assert(nova&&nova!==id);
 preState[nova].status='authorized'; r=await call(A.sincronizarAssinatura,{}); assert.equal(store['assinaturas/u1'].preapprovalId,nova); assert.equal(preState[id].status,'cancelled'); assert(!store['assinaturas/u1'].novaPreapprovalId);
 // aviso atrasado da antiga não revive
 w=await hook('subscription_preapproval',id); assert.equal(store['assinaturas/u1'].preapprovalId,nova);
 // x-signature: ausente, inválida, segredo errado, id adulterado, request-id ausente, válida, repetida
 {const st0=JSON.stringify(store['assinaturas/u1']); const n0=mpCalls.length;
  preState[store['assinaturas/u1'].preapprovalId].status='paused';
  let x=await hook('subscription_preapproval',store['assinaturas/u1'].preapprovalId,{sig:''}); assert.equal(x.code,401,'sem x-signature');
  x=await hook('subscription_preapproval',store['assinaturas/u1'].preapprovalId,{sig:'ts=1,v1=abc'}); assert.equal(x.code,401,'v1 malformado');
  x=await hook('subscription_preapproval',store['assinaturas/u1'].preapprovalId,{seg:'outro-segredo'}); assert.equal(x.code,401,'segredo errado');
  x=await hook('subscription_preapproval',store['assinaturas/u1'].preapprovalId,{qid:'OUTRO-ID'}); assert.equal(x.code,401,'id da URL diferente do assinado');
  x=await hook('subscription_preapproval',store['assinaturas/u1'].preapprovalId,{rid:''}); assert.equal(x.code,401,'sem x-request-id');
  assert.equal(JSON.stringify(store['assinaturas/u1']),st0,'notificação inválida NÃO pode alterar o banco'); assert.equal(mpCalls.length,n0,'notificação inválida NÃO pode chamar o MP');
  const idp=store['assinaturas/u1'].preapprovalId; const rid='req-fixo', sig=assinar(idp,rid,'1704908010');
  for(let i=0;i<2;i++){ x=mkres(); await A.webhookMercadoPago({method:'POST',headers:{'x-request-id':rid,'x-signature':sig},body:{},query:{'data.id':idp,type:'subscription_preapproval'}},x); assert.equal(x.code,200,'válida e repetida'); assert.equal(store['assinaturas/u1'].status,'paused'); }
  preState[idp].status='authorized'; await hook('subscription_preapproval',idp); assert.equal(store['assinaturas/u1'].status,'authorized');
  const sv=process.env.MP_WEBHOOK_SECRET; delete process.env.MP_WEBHOOK_SECRET; x=await hook('subscription_preapproval',idp); assert.equal(x.code,500,'sem segredo configurado: recusa tudo'); process.env.MP_WEBHOOK_SECRET=sv; }
 // pagamento recusado / aprovado / repetido
 {const idc=store['assinaturas/u1'].preapprovalId; store['assinaturas/u1'].status='authorized'; preState[idc].status='authorized';
  const orf=global.fetch; global.fetch=async(url,o)=>{ if(url.includes('/authorized_payments/')) return {ok:true,status:200,json:async()=>({preapproval_id:idc,status:'recycling',payment:{status:'rejected'}})}; return orf(url,o)};
  for(let i=0;i<2;i++){ w=await hook('subscription_authorized_payment','P1'); assert.equal(w.code,200); assert.equal(store['assinaturas/u1'].pagamentoRecusado,true,'recusado deve persistir (aviso repetido)'); }
  global.fetch=async(url,o)=>{ if(url.includes('/authorized_payments/')) return {ok:true,status:200,json:async()=>({preapproval_id:idc,status:'processed',payment:{status:'approved'}})}; return orf(url,o)};
  w=await hook('subscription_authorized_payment','P2'); assert.equal(store['assinaturas/u1'].pagamentoRecusado,false); global.fetch=orf; }
 // cancelar
 r=await call(A.cancelarAssinatura,{}); assert(r.body.ok); assert.equal(store['assinaturas/u1'].status,'cancelled'); assert(store['assinaturas/u1'].acessoAte>0);
 // CORS preflight
 r=await call(A.criarAssinatura,{}, 'ok','OPTIONS'); assert.equal(r.code,204); assert.equal(r.hdr['Access-Control-Allow-Origin'],'https://frilaone.com.br');
 console.log('TODOS OS TESTES PASSARAM', mpCalls.length,'chamadas falsas ao MP');
})().catch(e=>{console.error('FALHOU',e);process.exit(1)});
