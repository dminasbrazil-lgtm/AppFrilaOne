// Prova o que processarExclusao APAGA e o que MANTÉM. Firebase falso em memória (nada real é tocado).
const Module=require('module'),assert=require('assert');
const store={};const authUsers={};
const put=(p,v)=>{store[p]=v};
function col(c){
  return {
    doc:i=>({_p:c+'/'+i,
      delete:async()=>{if(falhar&&(c+'/'+i)===falhar)throw new Error('falha simulada');delete store[c+'/'+i]},
      get:async()=>({exists:!!store[c+'/'+i],data:()=>store[c+'/'+i]}),
      set:async(v,o)=>{const cur=(o&&o.merge&&store[c+'/'+i])||{};const n={...cur};for(const k in v){if(v[k]&&v[k].__del)delete n[k];else n[k]=v[k];}store[c+'/'+i]=n;}}),
    where:(f,op,val)=>({get:async()=>{const docs=Object.keys(store).filter(k=>k.startsWith(c+'/')&&store[k][f]===val).map(k=>({ref:{_p:k}}));return {forEach:fn=>docs.forEach(fn)}}})
  };
}
const FV={serverTimestamp:()=>'TS',delete:()=>({__del:true})};
const fakeAdmin={initializeApp(){},auth:()=>({getUser:async u=>({email:'Pessoa.Teste@gmail.com'}),deleteUser:async u=>{authUsers[u]='apagado'}}),
  firestore:Object.assign(()=>({collection:col,batch:()=>{const ops=[];return {delete:r=>ops.push(r._p),commit:async()=>ops.forEach(p=>delete store[p])}}}),{FieldValue:FV})};
let handler,apagaLogin;
let falhar=null; // nome de caminho que deve falhar ao apagar (simula erro do servidor)
const chain={region:()=>chain,firestore:{document:()=>({onWrite:h=>{handler=h;return h}})},auth:{user:()=>({onCreate:h=>h,onDelete:h=>{apagaLogin=h;return h}})},runWith:()=>chain,https:{onRequest:h=>h}};
const orig=Module._load;Module._load=function(r,...a){if(r==='firebase-functions/v1')return chain;if(r==='firebase-admin')return fakeAdmin;if(r==='./assinatura')return {};return orig.call(this,r,...a)};
const m=require('../functions/index.js');
const mkChange=(uid,dados)=>({after:{exists:!!(dados||store['solicitacoes_exclusao/'+uid]),data:()=>dados||store['solicitacoes_exclusao/'+uid],ref:col('solicitacoes_exclusao').doc(uid)}});
(async()=>{
  const U='u1',O='u2';
  // dados da pessoa (devem sumir)
  ['usuarios/'+U,'usuarios_privado/'+U,'disponiveis/'+U,'curriculos/'+U,'estagiarios/'+U,'negocios/neg_'+U,'negocios_privado/neg_'+U,'verificacoes/'+U,'profissionais_aprovados/'+U].forEach(p=>put(p,{uid:U}));
  put('emergencias/e1',{uid:U,tipo:'panico'});put('emergencias/e2',{uid:U,tipo:'checkin'});put('vagas/v1',{uid:U});
  // devem ficar
  put('assinaturas/'+U,{status:'authorized'});put('pagamentos/p1',{uid:U,valor:14.9});put('aceites_termos/'+U,{termos:'1.1'});
  put('indicacoes/'+U,{referrerUid:O,referredUid:U});put('conversas/c1',{participantes:[U,O]});put('avaliacoes/a1',{de:U,para:O});
  // dados de OUTRA pessoa (nunca podem sumir)
  ['usuarios/'+O,'usuarios_privado/'+O,'verificacoes/'+O,'negocios_privado/neg_'+O].forEach(p=>put(p,{uid:O}));
  put('emergencias/e3',{uid:O});put('vagas/v2',{uid:O});
  put('solicitacoes_exclusao/'+U,{status:'pendente',email:'x'});
  await handler(mkChange(U),{params:{uid:U}});
  const apagados=['usuarios/'+U,'usuarios_privado/'+U,'disponiveis/'+U,'curriculos/'+U,'estagiarios/'+U,'negocios/neg_'+U,'negocios_privado/neg_'+U,'verificacoes/'+U,'profissionais_aprovados/'+U,'emergencias/e1','emergencias/e2','vagas/v1'];
  apagados.forEach(p=>assert(!store[p],'deveria ter sido apagado: '+p));
  const mantidos=['assinaturas/'+U,'pagamentos/p1','aceites_termos/'+U,'indicacoes/'+U,'conversas/c1','avaliacoes/a1','usuarios/'+O,'usuarios_privado/'+O,'verificacoes/'+O,'negocios_privado/neg_'+O,'emergencias/e3','vagas/v2'];
  mantidos.forEach(p=>assert(store[p],'deveria ter sido mantido: '+p));
  assert.equal(authUsers[U],'apagado');
  const bloq=Object.keys(store).filter(k=>k.startsWith('exclusoes_bloqueadas/'));assert.equal(bloq.length,1);
  assert(!JSON.stringify(store[bloq[0]]).includes('@'),'bloqueio não pode guardar e-mail em claro');
  assert.equal(store['solicitacoes_exclusao/'+U].status,'concluida');assert(!('email' in store['solicitacoes_exclusao/'+U]));
  // ---- falha no meio: NÃO pode declarar concluída, não pode apagar o login; e deve dar para tentar de novo
  ['usuarios/'+U,'usuarios_privado/'+U,'verificacoes/'+U].forEach(p=>put(p,{uid:U}));put('emergencias/e9',{uid:U});
  authUsers[U]='ativo';put('solicitacoes_exclusao/'+U,{status:'pendente',email:'x'});
  falhar='verificacoes/'+U;
  await handler(mkChange(U),{params:{uid:U}});
  assert.equal(store['solicitacoes_exclusao/'+U].status,'erro','falha deve gravar status erro');
  assert.notEqual(store['solicitacoes_exclusao/'+U].status,'concluida');
  assert.equal(authUsers[U],'ativo','login NÃO pode ser apagado se uma etapa falhou');
  // gravações do próprio servidor não reprocessam
  for(const st of ['processando','concluida','erro']){authUsers[U]='ativo';put('usuarios/'+U,{uid:U});falhar=null;await handler(mkChange(U,{status:st}),{params:{uid:U}});assert.equal(authUsers[U],'ativo','status '+st+' não deve disparar exclusão');assert(store['usuarios/'+U])}
  // documento apagado não faz nada
  await handler({after:{exists:false}},{params:{uid:U}});assert(store['usuarios/'+U]);
  // tentar de novo (o app regrava 'pendente'): conclui
  falhar=null;put('solicitacoes_exclusao/'+U,{status:'pendente'});await handler(mkChange(U),{params:{uid:U}});
  assert.equal(store['solicitacoes_exclusao/'+U].status,'concluida');assert(!store['usuarios/'+U]&&!store['verificacoes/'+U]&&!store['emergencias/e9']);assert.equal(authUsers[U],'apagado');
  // limpeza do perfil quando o login é apagado (ex.: recusou os Termos no Google)
  put('usuarios/G9',{nome:'x'});put('usuarios/G8',{nome:'y'});await apagaLogin({uid:'G9'});assert(!store['usuarios/G9']);assert(store['usuarios/G8'],'não pode apagar perfil de outra pessoa');
  console.log('OK teste-exclusao: '+apagados.length+' itens apagados, '+mantidos.length+' mantidos (incl. dados de outra conta), Auth removido, e-mail só em hash, pedido concluído; falha → status erro e login preservado; nova tentativa conclui; limpeza ao apagar login');
})().catch(e=>{console.error('FALHOU',e.message);process.exit(1)});
