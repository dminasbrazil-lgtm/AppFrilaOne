// Testa os scripts de operação (acesso manual com verificação no Mercado Pago, profissionais, prontidão, chaves). Firestore/MP FALSOS.
const assert = require('assert'); const path = require('path');
const M = require('../migracao/conceder-acesso-manual.js'), PR = require('../migracao/conceder-profissional.js'), PD = require('../migracao/verificar-prontidao.js'), CH = require('../migracao/ligar-chaves-seguranca.js'), RS = require('../migracao/revisar-selos.js'), AL = require('../migracao/autorizar-loja.js');
function fakeDb(S) {
  const ref = (c, i) => ({ id: i, get: async () => ({ exists: S[c + '/' + i] !== undefined, data: () => S[c + '/' + i], id: i }), set: async (v, o) => { S[c + '/' + i] = Object.assign((o && o.merge && S[c + '/' + i]) || {}, v); } });
  const lst = (c, f) => { const docs = Object.keys(S).filter((k) => k.startsWith(c + '/') && f(S[k])).map((k) => ({ id: k.split('/')[1], data: () => S[k] })); return { docs, size: docs.length, forEach: (g) => docs.forEach(g) }; };
  return { collection: (c) => ({ doc: (i) => ref(c, i), get: async () => lst(c, () => true), where: (f, o, v) => ({ get: async () => lst(c, (x) => x[f] === v) }) }) };
}
const AG = Date.parse('2026-10-12T12:00:00-03:00'); let n = 0;
const t = async (nome, f) => { try { await f(); n++; console.log('OK     | ' + nome); } catch (e) { console.log('FALHOU | ' + nome + ' -> ' + e.message); process.exitCode = 1; } };
const mp = (tabela) => async (id) => tabela[id] || null;
(async () => {
  const base = () => [{ uid: 'a', plano: 'golden', ate: '2027-01-31', idPagamentoMP: '111' }, { uid: 'b', plano: 'master', ate: '2027-01-31', idPagamentoMP: '222', valorPago: 34.9 }, { uid: 'c', plano: 'diamond', ate: '2027-01-31', idPagamentoMP: '333' }, { uid: 'd', plano: 'golden', ate: '2027-01-31', idPagamentoMP: '999' }];
  const pagos = { '111': { status: 'approved', transaction_amount: 14.9 }, '222': { status: 'approved', transaction_amount: 29.9 }, '333': { status: 'pending', transaction_amount: 79.9 } };
  await t('acesso manual: só concede o que o Mercado Pago confirma (aprovado + valor do plano)', async () => {
    const S = {}; const r = await M.processar({ db: fakeDb(S), lista: base(), exec: true, buscarPagamento: mp(pagos), agora: AG });
    assert.deepEqual(r.concedidos, ['a']); assert.equal(r.recusadosMP.length, 3); assert(S['assinaturas/a'].manualVerificadoMP === true);
    assert(!S['assinaturas/b'] && !S['assinaturas/c'] && !S['assinaturas/d']);
    assert(/valor/.test(r.recusadosMP.find((x) => x.uid === 'b').motivo)); assert(/pending/.test(r.recusadosMP.find((x) => x.uid === 'c').motivo)); assert(/não encontrado/.test(r.recusadosMP.find((x) => x.uid === 'd').motivo)); });
  await t('acesso manual: pagamento de link ANTIGO (valor antigo) é aceito sem valorPago e o valor fica registrado', async () => { const S = {}; const r = await M.processar({ db: fakeDb(S), lista: [{ uid: 'o', plano: 'master', ate: '2027-01-31', idPagamentoMP: '222' }], exec: true, buscarPagamento: mp(pagos), agora: AG }); assert.deepEqual(r.concedidos, ['o']); assert.equal(S['assinaturas/o'].manualValorMP, 29.9); });
  await t('acesso manual: simulação não grava nada', async () => { const S = {}; const r = await M.processar({ db: fakeDb(S), lista: base(), exec: false, buscarPagamento: mp(pagos), agora: AG }); assert.deepEqual(r.concedidos, ['a']); assert.deepEqual(S, {}); });
  await t('acesso manual: repetir o comando não duplica (idempotente)', async () => { const S = {}; const db = fakeDb(S); await M.processar({ db, lista: base(), exec: true, buscarPagamento: mp(pagos), agora: AG }); const r = await M.processar({ db, lista: base(), exec: true, buscarPagamento: mp(pagos), agora: AG }); assert.deepEqual(r.jaConcedidos, ['a']); assert.deepEqual(r.concedidos, []); });
  await t('acesso manual: o mesmo pagamento não vale para duas contas', async () => { const S = {}; const db = fakeDb(S); await M.processar({ db, lista: [base()[0]], exec: true, buscarPagamento: mp(pagos), agora: AG }); const r = await M.processar({ db, lista: [{ uid: 'z', plano: 'golden', ate: '2027-01-31', idPagamentoMP: '111' }], exec: true, buscarPagamento: mp(pagos), agora: AG }); assert.equal(r.conflitos.length, 1); assert(!S['assinaturas/z']); });
  await t('acesso manual: sem número do pagamento, plano inválido ou data vencida → nada', async () => { const S = {}; const r = await M.processar({ db: fakeDb(S), lista: [{ uid: 'x', plano: 'golden', ate: '2027-01-31' }, { uid: 'y', plano: 'ouro', ate: '2027-01-31', idPagamentoMP: '1' }, { uid: 'w', plano: 'golden', ate: '2026-01-01', idPagamentoMP: '2' }], exec: true, buscarPagamento: mp(pagos), agora: AG }); assert.equal(r.invalidos.length, 3); assert.deepEqual(S, {}); });
  await t('acesso manual: executar sem poder consultar o Mercado Pago não concede', async () => { const S = {}; const r = await M.processar({ db: fakeDb(S), lista: [base()[0]], exec: true, buscarPagamento: null, agora: AG }); assert.equal(r.concedidos.length, 0); assert.deepEqual(S, {}); });
  await t('acesso manual: falha de rede ao consultar o MP → recusa (não concede)', async () => { const S = {}; const r = await M.processar({ db: fakeDb(S), lista: [base()[0]], exec: true, buscarPagamento: async () => { throw new Error('rede'); }, agora: AG }); assert.equal(r.recusadosMP.length, 1); assert.deepEqual(S, {}); });
  // profissionais
  const dbPro = () => ({ 'usuarios/p1': { tipo: 'academico', nome: 'Psi', cadMaster: { area: 'psicologo', registro: 'CRP 04/1' } }, 'usuarios/p2': { tipo: 'academico', nome: 'Falso', cadMaster: { area: 'advogado' } }, 'usuarios/u1': { tipo: 'trabalhador' }, 'profissionais_aprovados/p2': { ativo: true } });
  await t('profissionais: simulação lista candidatos (academicos) e quem já está aprovado, sem gravar', async () => { const S = dbPro(); const antes = JSON.stringify(S); const r = await PR.executar({ db: fakeDb(S), aprovar: ['p1'], exec: false }); assert.equal(r.candidatos.length, 2); assert.equal(r.candidatos.find((c) => c.uid === 'p2').aprovado, true); assert.equal(r.candidatos.find((c) => c.uid === 'p1').aprovado, false); assert.equal(JSON.stringify(S), antes); });
  await t('profissionais: --executar aprova só quem existe; revoga com ativo:false', async () => { const S = dbPro(); const r = await PR.executar({ db: fakeDb(S), aprovar: ['p1', 'naoexiste'], revogar: ['p2'], exec: true, agora: AG }); assert.deepEqual(r.aprovados, ['p1']); assert.deepEqual(r.naoEncontrados, ['naoexiste']); assert.equal(S['profissionais_aprovados/p1'].ativo, true); assert.equal(S['profissionais_aprovados/p2'].ativo, false); assert(!S['profissionais_aprovados/naoexiste']); });
  // prontidão (somente leitura)
  await t('prontidão: aponta CPF no perfil público, selo sem verificação, profissional não aprovado, plano sem acesso e pedido com erro — sem gravar', async () => {
    const S = { 'usuarios/a': { tipo: 'prestador', cpf: '1', verificado: true, email: 'a@x.com', trial_fim: 5, plano: 'golden' }, 'usuarios/b': { tipo: 'academico' }, 'usuarios/c': { tipo: 'trabalhador', master_ativo: true }, 'assinaturas/c': { acessoRegraAte: AG - 1 }, 'solicitacoes_exclusao/x': { status: 'erro' }, 'aceites_termos/c': {} };
    const antes = JSON.stringify(S); const r = await PD.analisar(fakeDb(S), AG);
    assert.equal(r.usuarios, 3); assert.equal(r.comCpfNoPerfilPublico, 1); assert.equal(r.verificadosSemDocumentoDeVerificacao, 1); assert.equal(r.academicosNaoAprovados, 1); assert.equal(r.prestadoresSemRegistroDeAcesso, 2); assert.equal(r.contasDePlanoSemAcessoValidoAgora, 3); assert.equal(r.comEmailNoPerfilPublico, 1); assert.equal(r.comTrialGravadoNoPerfil, 1); assert.equal(r.masterAtivoNoPerfil, 1); assert.equal(r.comPlanoPagoNoPerfil, 1); assert.equal(r.pedidosExclusaoComErro, 1); assert.equal(r.aceitesRegistrados, 1); assert(r.bloqueios.length === 5, "bloqueios: " + r.bloqueios.length); assert.equal(r.chaves.exigirAcesso, false); assert.equal(JSON.stringify(S), antes); });
  // chaves
  await t('chaves: sem --executar só mostra; ligar exige a confirmação; desligar é a reversão', async () => {
    const S = {}; const db = fakeDb(S);
    let r = await CH.executar({ db, exec: false, ligar: true }); assert.equal(r.acao, 'mostrar'); assert.deepEqual(S, {});
    await assert.rejects(() => CH.executar({ db, exec: true, ligar: true, confirmo: false }), /confirme/); assert.deepEqual(S, {});
    r = await CH.executar({ db, exec: true, ligar: true, confirmo: true, agora: AG }); assert.equal(r.acao, 'ligado'); assert.equal(S['config/seguranca'].exigirAcesso, true); assert.equal(S['config/seguranca'].protegerCampos, undefined, 'v18: protegerCampos não existe mais');
    r = await CH.executar({ db, exec: true, desligar: true, agora: AG }); assert.equal(r.acao, 'desligado'); assert.equal(S['config/seguranca'].exigirAcesso, false); });
  await t('revisar-selos: simulação lista selo sem verificação válida e não grava; executar exige confirmação, faz backup antes e preserva quem tem verificação válida', async () => {
    const selfie = 'x'.repeat(300);
    const S = { 'usuarios/ok': { verificado: true }, 'verificacoes/ok': { cpf: '11144477735', selfie }, 'usuarios/fake': { verificado: true }, 'usuarios/semselfie': { verificado: true }, 'verificacoes/semselfie': { cpf: '11144477735', selfie: 'x' }, 'usuarios/cpfruim': { verificado: true }, 'verificacoes/cpfruim': { cpf: '11111111111', selfie }, 'usuarios/livre': { nome: 'L' } };
    const antes = JSON.stringify(S); let r = await RS.executar({ db: fakeDb(S), exec: false });
    assert.equal(r.comSelo, 4); assert.equal(r.comVerificacaoValida, 1); assert.deepEqual(r.semVerificacaoValida.sort(), ['cpfruim', 'fake', 'semselfie']); assert.equal(JSON.stringify(S), antes);
    await assert.rejects(() => RS.executar({ db: fakeDb(S), exec: true, confirmo: false }), /confirme/); assert.equal(JSON.stringify(S), antes);
    const ordem = []; const db = fakeDb(S); r = await RS.executar({ db, exec: true, confirmo: true, agora: AG, escreverBackup: (nome, txt) => { ordem.push('backup'); assert(S['usuarios/fake'].verificado === true, 'backup deve vir ANTES de alterar'); assert(/fake/.test(txt)); } });
    assert.equal(r.alterados, 3); assert.equal(S['usuarios/fake'].verificado, false); assert.equal(S['usuarios/ok'].verificado, true); assert.equal(S['usuarios/livre'].verificado, undefined); assert.deepEqual(ordem, ['backup']); });
  await t('autorizar-loja: simulação não grava; --executar grava lojas_autorizadas/{uid}.ate; revogar encerra; repetir não duplica', async () => {
    const S = { 'usuarios/u1': { nome: 'u1' } }; const db = fakeDb(S); const AG = Date.parse('2026-12-02T12:00:00Z');
    let r = await AL.executar({ db, uid: 'u1', ate: '2027-01-31', exec: false, agora: AG }); assert(r.simulacao && !r.erro); assert(!S['lojas_autorizadas/u1']);
    r = await AL.executar({ db, uid: 'u1', ate: '2027-01-31', exec: true, agora: AG }); assert(S['lojas_autorizadas/u1'].ate > AG);
    await AL.executar({ db, uid: 'u1', ate: '2027-01-31', exec: true, agora: AG }); assert.equal(Object.keys(S).filter((k) => k.startsWith('lojas_autorizadas/')).length, 1);
    await AL.executar({ db, uid: 'u1', revogar: true, exec: true, agora: AG + 1000 }); assert(S['lojas_autorizadas/u1'].ate <= AG + 1000);
  });
  await t('autorizar-loja: recusa usuário inexistente, data ausente/passada e uid inválido; não toca assinaturas', async () => {
    const S = { 'usuarios/u1': { nome: 'u1' } }; const db = fakeDb(S); const AG = Date.parse('2026-12-02T12:00:00Z');
    for (const a of [{ uid: 'zz', ate: '2027-01-31' }, { uid: 'u1' }, { uid: 'u1', ate: '2026-01-01' }, { uid: 'a/b', ate: '2027-01-31' }]) { const r = await AL.executar({ db, ...a, exec: true, agora: AG }); assert(r.erro, JSON.stringify(a)); }
    assert(!Object.keys(S).some((k) => k.startsWith('lojas_autorizadas/') || k.startsWith('assinaturas/')));
  });
  console.log('SCRIPTS: ' + n + '/15 OK');
})();
