// Liga o SERVIDOR (assinatura-lib) às REGRAS (v18, avaliador local SIMULADO): para cada situação de acesso, o que o servidor grava em
// assinaturas/{uid} faz as regras permitirem/negarem exatamente o que o app promete? Também confere as datas da campanha.
// Rodar: node teste-acesso-regras.js     (SIMULADO — não é o Emulador oficial)
const assert = require('assert'), fs = require('fs'), path = require('path');
const L = require('../functions/assinatura-lib.js');
const { rulesUnitTesting, firestoreMod } = require('./regras/avaliador-local/firebase-falso.js');
const { doc, setDoc, addDoc, collection, deleteDoc } = firestoreMod;
const DIA_ = 86400e3;
const REGRAS = fs.readFileSync(path.join(__dirname, '../firestore-regras-v18.4.txt'), 'utf8');
let n = 0, f = 0;
const ok = async (nome, fn) => { try { await fn(); n++; console.log('OK     | ' + nome); } catch (e) { f++; console.log('FALHOU | ' + nome + ' -> ' + e.message.split('\n')[0]); } };
const T = (s) => Date.parse(s), DIA = 86400e3;
(async () => {
  // ── datas: regras × servidor
  await ok('regras: a data de início da cobrança é 01/12/2026 00:00 de Brasília e está no arquivo', () => {
    const alvo = Date.parse('2026-12-01T00:00:00-03:00'); assert.equal(alvo, 1796094000000);
    assert(REGRAS.includes(String(alvo)), 'constante 1796094000000 não está nas regras');
  });
  await ok('campanha termina ANTES da data de cobrança das regras e o 1º débito vem depois', () => {
    assert(L.CAMPANHA_ATE < 1796094000000 + 1 && L.CAMPANHA_ATE >= 1796094000000 - 1000 * 3600 * 24, 'CAMPANHA_ATE fora de 30/11'); assert(L.PRIMEIRA_COBRANCA >= 1796094000000);
  });
  await ok('regras v18: não existe mais a chave protegerCampos nem tipo como único critério', () => {
    assert(!/chaveLigada\('protegerCampos'\)/.test(REGRAS)); assert(/precisaPlano/.test(REGRAS));
  });
  // ── integração servidor → regras
  const env = await rulesUnitTesting.initializeTestEnvironment({ projectId: 'x', firestore: { rules: REGRAS } });
  const AGORA = T('2026-12-10T12:00:00-03:00');           // depois da data de cobrança, sem precisar de chave
  globalThis.__RELOGIO_SIMULADO = AGORA;
  const cenarios = [
    ['teste grátis válido (plano todos)', { trialFim: AGORA + 2 * DIA }, true, true],
    ['teste vencido há 2 dias (carência)', { trialFim: AGORA - 2 * DIA }, true, true],
    ['teste vencido há 4 dias', { trialFim: AGORA - 4 * DIA }, false, false],
    ['assinatura Golden autorizada', { status: 'authorized', plano: 'golden' }, true, false],
    ['assinatura Master autorizada', { status: 'authorized', plano: 'master' }, true, false],
    ['assinatura Minha Loja autorizada', { status: 'authorized', plano: 'diamond' }, true, true],
    ['assinatura Golden com cartão recusado há 1 dia', { status: 'authorized', plano: 'golden', pagamentoRecusado: true, recusadoEm: AGORA - DIA }, true, false],
    ['assinatura Golden com cartão recusado há 4 dias', { status: 'authorized', plano: 'golden', pagamentoRecusado: true, recusadoEm: AGORA - 4 * DIA }, false, false],
    ['cancelada com período pago até amanhã (Golden)', { status: 'cancelled', plano: 'golden', acessoAte: AGORA + DIA }, true, false],
    ['cancelada com período vencido há 5 dias', { status: 'cancelled', plano: 'golden', acessoAte: AGORA - 5 * DIA }, false, false],
    ['concessão manual Golden válida', { manualAte: AGORA + 5 * DIA, manualPlano: 'golden' }, true, false],
    ['concessão manual Minha Loja válida', { manualAte: AGORA + 5 * DIA, manualPlano: 'diamond' }, true, true],
    ['benefício legado (codigoFim) válido', { codigoFim: AGORA + 5 * DIA }, true, true],
    ['assinatura pendente (link gerado, não pago)', { status: 'pending', plano: 'golden' }, false, false]
  ];
  for (const [nome, a, esperaBasico, esperaLoja] of cenarios) {
    const uid = 'S' + Math.random().toString(36).slice(2, 8);
    await env.withSecurityRulesDisabled(async (ctx) => {
      const d = ctx.firestore();
      await setDoc(doc(d, 'usuarios/' + uid), { nome: uid, tipo: 'prestador' });
      await setDoc(doc(d, 'assinaturas/' + uid), Object.assign({}, a, L.camposDerivados(a, AGORA), { precisaPlano: true }));
    });
    const c = env.authenticatedContext(uid).firestore();
    const tenta = async (fn) => { try { await fn(); return true; } catch (e) { if (e.code === 'permission-denied') return false; throw e; } };
    await ok(nome + ' → vaga/disponível: ' + (esperaBasico ? 'permitido' : 'negado'), async () => {
      assert.equal(await tenta(() => addDoc(collection(c, 'vagas'), { uid, titulo: 'x' })), esperaBasico, 'vaga');
      assert.equal(await tenta(() => setDoc(doc(c, 'disponiveis/' + uid), { uid, online: true })), esperaBasico, 'disponível');
    });
    await ok(nome + ' → loja: cadastro é permitido (nasce PENDENTE), mas o plano/teste/benefício NÃO publica nem abre a loja (v18.3: precisa aprovação do administrador)', async () => {
      assert.equal(await tenta(() => setDoc(doc(c, 'negocios/neg_' + uid), { uid, nome: 'L', aprovacaoStatus: 'pendente' })), true, 'cadastro pendente');
      assert.equal(await tenta(() => setDoc(doc(c, 'disponiveis/' + uid), { uid, categoria: 'negocio', nome: 'L' })), false, 'loja pendente abriu');
      assert.equal(await tenta(() => setDoc(doc(c, 'negocios/neg_' + uid), { aprovacaoStatus: 'aprovada', publicaAte: AGORA + 400 * DIA }, { merge: true })), false, 'o dono aprovou a própria loja');
    });
    await ok(nome + ' → o servidor continua gravando acessoPlano coerente com o plano (informativo; as regras de loja NÃO o usam mais)', async () => {
      const d = L.camposDerivados(a, AGORA); assert.equal(['diamond', 'todos'].includes(d.acessoPlano), esperaLoja);
    });
  }

  // ── C) ciclo de vida: contas EXISTENTES antes da ativação (sem registro em assinaturas) × app em Modo Servidor × regras na data da cobrança
  const Module = require('module'); const S = {}; const FVd = { delete: () => ({ __del: true }) };
  const ref = (c, i) => ({ get: async () => ({ exists: S[c + '/' + i] !== undefined, data: () => S[c + '/' + i] }), set: async (v, o) => { const cur = (o && o.merge && S[c + '/' + i]) || {}; const m = { ...cur }; for (const k in v) { if (v[k] && v[k].__del) delete m[k]; else m[k] = v[k]; } S[c + '/' + i] = m; } });
  const fakeAdmin = { initializeApp() {}, auth: () => ({ verifyIdToken: async (t) => { if (/^ok:/.test(t)) return { uid: t.slice(3) }; throw new Error('x'); } }), firestore: Object.assign(() => ({ collection: (c) => ({ doc: (i) => ref(c, i) }), runTransaction: async (fn) => fn({ get: (r) => r.get(), set: (r, v, o) => r.set(v, o) }) }), { FieldValue: FVd }) };
  const orig = Module._load; Module._load = function (r, ...a) { if (r === 'firebase-functions/v1') return { runWith: () => ({ region: () => ({ https: { onRequest: (h) => h } }) }) }; if (r === 'firebase-admin') return fakeAdmin; return orig.call(this, r, ...a); };
  process.env.MP_ACCESS_TOKEN = 'T'; process.env.MP_WEBHOOK_SECRET = 's';
  const A = require('../functions/assinatura.js'); Module._load = orig;
  const mkres = () => { const r = { code: 200, body: null }; r.status = (c) => { r.code = c; return r; }; r.json = (b) => { r.body = b; return r; }; r.send = (b) => { r.body = b; return r; }; r.set = () => {}; return r; };
  const login = async (uid) => { const rs = mkres(); await A.statusAcesso({ method: 'POST', headers: { authorization: 'Bearer ok:' + uid, origin: 'https://frilaone.com.br' }, body: {}, query: {} }, rs); assert(rs.body && rs.body.ok, 'statusAcesso falhou'); };
  const realNow = Date.now; const relogio = (iso) => { Date.now = () => Date.parse(iso); globalThis.__RELOGIO_SIMULADO = Date.parse(iso); };
  // contas existentes (legado), SEM registro em assinaturas — o app antigo as criou
  Object.assign(S, { 'usuarios/L1': { tipo: 'prestador' }, 'usuarios/L2': { tipo: 'trabalhador' }, 'usuarios/L3': { tipo: 'negocio' }, 'usuarios/L4': { tipo: 'academico', master_ativo: true }, 'usuarios/L5': { tipo: 'prestador' } });
  const semear = async () => env.withSecurityRulesDisabled(async (ctx) => { for (const [k, v] of Object.entries(S)) await setDoc(doc(ctx.firestore(), k), JSON.parse(JSON.stringify(v))); });
  const publica = async (uid) => { try { await addDoc(collection(env.authenticatedContext(uid).firestore(), 'vagas'), { uid, titulo: 'x' }); return true; } catch (e) { if (e.code === 'permission-denied') return false; throw e; } };
  await env.withSecurityRulesDisabled(async (ctx) => { try { await deleteDoc(doc(ctx.firestore(), 'config/seguranca')); } catch (e) {} });
  relogio('2026-11-20T12:00:00-03:00'); await semear();
  await ok('ativação: ANTES da data, contas existentes sem registro continuam publicando (campanha grátis)', async () => { for (const u of ['L1', 'L2', 'L3', 'L4', 'L5']) assert.equal(await publica(u), true, u); });
  for (const u of ['L1', 'L2', 'L3', 'L4']) await login(u);       // abriram o app já em Modo Servidor; L5 não abriu
  await semear();
  await ok('ativação: o servidor cria o teste só para conta de plano (L1, L3, L4) e marca precisaPlano; Pessoa Física (L2) não recebe teste nem marca', () => {
    for (const u of ['L1', 'L3', 'L4']) { assert.equal(S['assinaturas/' + u].precisaPlano, true, u); assert.equal(S['assinaturas/' + u].trialFim, L.CAMPANHA_ATE, u); }
    assert(!S['assinaturas/L2'] || (!S['assinaturas/L2'].trialInicio && !S['assinaturas/L2'].precisaPlano), 'Pessoa Física ganhou teste/plano');
  });
  await ok('ativação: L4 tinha master_ativo gravado pelo app antigo; durante o teste (plano todos) o servidor mantém', () => { assert.equal(S['usuarios/L4'].master_ativo, true); });
  relogio('2026-12-02T12:00:00-03:00');
  await ok('ativação: logo APÓS 01/12, dentro dos 3 dias de carência, quem entrou antes continua publicando; Pessoa Física também', async () => { for (const u of ['L1', 'L2', 'L3', 'L4']) assert.equal(await publica(u), true, u); });
  await ok('ativação: quem NÃO abriu o app depois da ativação (L5) fica sem publicar até entrar — não é bloqueio definitivo', async () => { assert.equal(await publica('L5'), false); });
  await login('L5'); await semear();
  await ok('ativação: ao entrar, L5 recebe 7 dias de teste (conta nova no calendário de cobrança) e volta a publicar', async () => { assert.equal(S['assinaturas/L5'].trialFim, T('2026-12-02T12:00:00-03:00') + 7 * DIA); assert.equal(await publica('L5'), true); });
  relogio('2026-12-06T12:00:00-03:00');
  await ok('ativação: depois da carência, sem assinatura, L1/L3/L4 deixam de publicar; Pessoa Física (L2) segue livre; L5 ainda está no teste de 7 dias', async () => {
    for (const u of ['L1', 'L3', 'L4']) assert.equal(await publica(u), false, u); assert.equal(await publica('L2'), true); assert.equal(await publica('L5'), true); });
  await ok('ativação: L2 muda o tipo para prestador depois da cobrança: ganha UM teste de 7 dias a partir daí (não há como renovar)', async () => {
    S['usuarios/L2'].tipo = 'prestador'; await login('L2'); const fim = S['assinaturas/L2'].trialFim; assert.equal(fim, T('2026-12-06T12:00:00-03:00') + 7 * DIA);
    relogio('2026-12-20T12:00:00-03:00'); await login('L2'); assert.equal(S['assinaturas/L2'].trialFim, fim, 'teste renovado!');
    S['usuarios/L2'].tipo = 'trabalhador'; await login('L2'); await semear(); assert.equal(await publica('L2'), false, 'trocar para Pessoa Física não pode devolver o acesso'); });
  Date.now = realNow;
  globalThis.__RELOGIO_SIMULADO = 0;
  console.log('\nACESSO×REGRAS (SIMULADO): ' + n + ' OK, ' + f + ' falharam'); process.exit(f ? 1 : 0);
})();
