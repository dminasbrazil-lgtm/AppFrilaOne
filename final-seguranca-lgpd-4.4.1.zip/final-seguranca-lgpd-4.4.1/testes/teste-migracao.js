// Testa os scripts de migração/limpeza com um firebase-admin FALSO em memória (nenhum dado real).
const Module=require('module'),assert=require('assert'),path=require('path');
function novoBanco(){ const S={ 'usuarios/a':{cpf:'111',contatoEmergencia:'3199',nome:'A',ultima_emergencia_tipo:'panico'}, 'usuarios/b':{nome:'B'}, 'usuarios/c':{cpf:'333'}, 'negocios/neg_a':{uid:'a',cpf:'111',nome:'L'}, 'negocios/neg_x':{uid:'x',nome:'sem cpf'}, 'usuarios_privado/c':{cpf:'999'} }; return S; }
function rodar(arquivo,args,S){
  const fv={delete:()=>({__del:1})};
  const mkRef=(col,id)=>({id,get:async()=>({exists:S[col+'/'+id]!==undefined,data:()=>S[col+'/'+id]}),set:async(v,o)=>{S[col+'/'+id]=Object.assign((o&&o.merge&&S[col+'/'+id])||{},v)},update:async(v)=>{const c=S[col+'/'+id];for(const k in v){ if(v[k]&&v[k].__del) delete c[k]; else c[k]=v[k]; }}});
  const fs={collection:(col)=>({doc:(id)=>mkRef(col,id),orderBy(){return this},limit(){return this},startAfter(){return this},get:async()=>{ const docs=Object.keys(S).filter(k=>k.startsWith(col+'/')).map(k=>{const id=k.split('/')[1];return {id,data:()=>S[k],ref:mkRef(col,id)}}); return {empty:!docs.length||global.__jaLeu,docs}} })};
  const admin={initializeApp(){},firestore:Object.assign(()=>fs,{FieldValue:fv,FieldPath:{documentId:()=>'id'}})};
  const orig=Module._load; Module._load=function(r,...a){ if(r==='firebase-admin') return admin; return orig.call(this,r,...a)};
  const out=[]; const ol=console.log; console.log=(...x)=>out.push(x.join(' '));
  const oe=process.exit; let code=0; process.exit=(c)=>{code=c||0};
  process.argv=['node',arquivo,...args];
  // paginação falsa: segunda chamada retorna vazio
  let n=0; const getOrig=fs.collection; fs.collection=(c)=>{const o=getOrig(c); const g=o.get; o.get=async()=>{ n++; return (n%2===0)?{empty:true,docs:[]}:g(); }; return o;};
  delete require.cache[require.resolve(arquivo)]; require(arquivo);
  return new Promise(r=>setTimeout(()=>{console.log=ol;process.exit=oe;Module._load=orig;r({out:out.join('\n'),code})},300));
}
(async()=>{
  const M=path.join(__dirname,'../migracao/migrar-dados-privados.js'), L=path.join(__dirname,'../migracao/limpar-campos-antigos.js');
  let S=novoBanco(); let r=await rodar(M,[],S);
  assert(!S['usuarios_privado/a'] && !S['negocios_privado/neg_a'],'simulação não pode gravar'); console.log('OK | simulação não grava nada');
  S=novoBanco(); r=await rodar(M,['--executar'],S);
  assert.equal(S['usuarios_privado/a'].cpf,'111'); assert.equal(S['usuarios_privado/a'].contatoEmergencia,'3199'); assert.equal(S['negocios_privado/neg_a'].cpf,'111'); assert.equal(S['negocios_privado/neg_a'].uid,'a');
  assert.equal(S['usuarios_privado/c'].cpf,'999','não sobrescreve privado existente'); assert.equal(S['usuarios/a'].cpf,'111','não apaga o antigo'); assert(!S['usuarios_privado/b'],'sem dados = sem doc'); console.log('OK | executar copia, não sobrescreve privado, não apaga antigo');
  r=await rodar(M,['--verificar'],S); assert.equal(r.code,2); assert(/usuarios\/c campo cpf/.test(r.out)); console.log('OK | verificar aponta divergência (usuarios/c)');
  S['usuarios/c'].cpf='999'; r=await rodar(M,['--verificar'],S); assert.equal(r.code,0); console.log('OK | verificar sem divergências');
  r=await rodar(L,[],S); assert.equal(S['usuarios/a'].cpf,'111'); console.log('OK | limpeza em simulação não apaga');
  r=await rodar(L,['--executar'],S); assert.equal(S['usuarios/a'].cpf,'111'); console.log('OK | --executar sem a confirmação não apaga');
  r=await rodar(L,['--executar','--confirmo-que-verifiquei'],S);
  assert(!('cpf' in S['usuarios/a']) && !('contatoEmergencia' in S['usuarios/a']) && !('ultima_emergencia_tipo' in S['usuarios/a']) && S['usuarios/a'].nome==='A'); assert(!('cpf' in S['negocios/neg_a'])); assert.equal(S['usuarios_privado/a'].cpf,'111');
  console.log('OK | limpeza confirmada remove só os campos antigos; privados intactos'); 
  S=novoBanco(); delete S['usuarios_privado/c']; await rodar(L,['--executar','--confirmo-que-verifiquei'],S); assert.equal(S['usuarios/a'].cpf,'111','sem privado equivalente NÃO apaga'); console.log('OK | não apaga campo antigo se o privado não tiver o mesmo valor');
  // v18: e-mails (login e de contato) saem do perfil público só depois de copiados e conferidos
  S={'usuarios/e':{nome:'E',email:'e@x.com',emailContato:'c@x.com'},'usuarios/f':{nome:'F',email:'f@x.com'}};
  r=await rodar(M,[],S); assert(!S['usuarios_privado/e'],'simulação não grava'); r=await rodar(M,['--executar'],S);
  assert.equal(S['usuarios_privado/e'].email,'e@x.com'); assert.equal(S['usuarios_privado/e'].emailContato,'c@x.com'); assert.equal(S['usuarios/e'].email,'e@x.com','não apaga o antigo');
  delete S['usuarios_privado/f']; await rodar(L,['--executar','--confirmo-que-verifiquei'],S);
  assert(!('email' in S['usuarios/e']) && !('emailContato' in S['usuarios/e']) && S['usuarios/e'].nome==='E','copiado e igual: apaga'); assert.equal(S['usuarios/f'].email,'f@x.com','sem privado equivalente: NÃO apaga');
  console.log('OK | e-mails: copia, confere e só então limpa o perfil público');
  console.log('\nMIGRAÇÃO: 9/9 OK'); process.exit(0);
})().catch(e=>{console.error('FALHOU',e.message);process.exit(1)});
