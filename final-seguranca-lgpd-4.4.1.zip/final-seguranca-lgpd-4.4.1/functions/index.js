// FrilaOne — exclusão automática de conta + bloqueio de recadastro por 30 dias.
// Precisa do plano Blaze. Duas funções:
//  1) processarExclusao: dispara quando o app grava solicitacoes_exclusao/{uid}. Apaga os dados e o login,
//     e grava só o "código embaralhado" (SHA-256) do e-mail com a data de liberação (hoje + 30 dias).
//  2) bloquearRecadastro: dispara quando nasce uma conta nova; se o e-mail ainda está no prazo, apaga a conta
//     na hora (vale também para o login com Google, que o app não consegue barrar antes).
const functions = require('firebase-functions/v1');
const admin = require('firebase-admin');
const crypto = require('crypto');
admin.initializeApp();
const db = admin.firestore();
const REGIAO = 'southamerica-east1';
const DIAS_BLOQUEIO = 30;

// MESMA regra que o app usa (index.html, função _hashEmailExclusao). Se mudar aqui, mude lá.
function normalizarEmail(e) {
  e = String(e || '').trim().toLowerCase();
  const p = e.split('@');
  if (p.length !== 2) return e;
  let [u, d] = p;
  if (d === 'gmail.com' || d === 'googlemail.com') { u = u.split('+')[0].replace(/\./g, ''); d = 'gmail.com'; }
  return u + '@' + d;
}
function hashEmail(e) { return crypto.createHash('sha256').update(normalizarEmail(e)).digest('hex'); }

async function apagarColecaoPorCampo(col, campo, valor) {
  const snap = await db.collection(col).where(campo, '==', valor).get();
  const lotes = [];
  let batch = db.batch(), n = 0;
  snap.forEach((d) => { batch.delete(d.ref); if (++n % 400 === 0) { lotes.push(batch.commit()); batch = db.batch(); } });
  lotes.push(batch.commit());
  await Promise.all(lotes);
}

// Dispara em QUALQUER gravação do pedido, mas só age quando status == 'pendente'. Assim:
//  - o pedido novo é processado (o app grava status 'pendente');
//  - se deu erro (status 'erro'), a pessoa pode pedir de novo (o app regrava 'pendente') e a exclusão é refeita;
//  - as gravações do próprio servidor ('processando', 'concluida', 'erro') não disparam nova execução.
exports.processarExclusao = functions.region(REGIAO).firestore
  .document('solicitacoes_exclusao/{uid}')
  .onWrite(async (change, ctx) => {
    if (!change.after.exists) return null;
    const dadosPedido = change.after.data() || {};
    if (dadosPedido.status !== 'pendente') return null;
    const uid = ctx.params.uid;
    const ref = change.after.ref;
    try {
      await ref.set({ status: 'processando' }, { merge: true });
      // E-mail vem do próprio login (Auth), nunca do que o app mandou.
      let email = '';
      try { email = (await admin.auth().getUser(uid)).email || ''; } catch (e) { /* login já não existe */ }
      if (email) {
        await db.collection('exclusoes_bloqueadas').doc(hashEmail(email)).set({
          liberaEm: Date.now() + DIAS_BLOQUEIO * 24 * 3600 * 1000,
          criadoEm: admin.firestore.FieldValue.serverTimestamp()
        });
      }
      // APAGADOS (dados da própria pessoa, finalidade encerrada com a exclusão da conta):
      //  perfil público e currículo, vagas dela, e os dados privados/sensíveis: usuarios_privado (CPF, contato de
      //  emergência), negocios_privado (CPF da loja), verificacoes (CPF e selfie) e emergencias (localização/aviso de saída).
      // MANTIDOS DE PROPÓSITO (ver docs/DECISOES-LGPD.md): assinaturas e pagamentos (obrigação fiscal/contábil e defesa
      //  em disputa de cobrança), exclusoes_bloqueadas (só o código embaralhado do e-mail), solicitacoes_exclusao (prova do
      //  pedido), aceites_termos (prova do aceite) e dados de terceiros (conversas, avaliações e indicações de outras pessoas).
      await Promise.all([
        db.collection('usuarios').doc(uid).delete(),
        db.collection('usuarios_privado').doc(uid).delete(),
        db.collection('disponiveis').doc(uid).delete(),
        db.collection('curriculos').doc(uid).delete(),
        db.collection('estagiarios').doc(uid).delete(),
        db.collection('negocios').doc('neg_' + uid).delete(),
        db.collection('negocios_privado').doc('neg_' + uid).delete(),
        db.collection('verificacoes').doc(uid).delete(),
        db.collection('profissionais_aprovados').doc(uid).delete(),
        apagarColecaoPorCampo('negocios_privado', 'uid', uid),
        apagarColecaoPorCampo('emergencias', 'uid', uid),
        apagarColecaoPorCampo('vagas', 'uid', uid)
      ]);
      try { await admin.auth().deleteUser(uid); } catch (e) { if (e.code !== 'auth/user-not-found') throw e; }
      // 'concluida' só é gravado aqui, depois que TODAS as etapas acima deram certo.
      await ref.set({ status: 'concluida', concluidaEm: admin.firestore.FieldValue.serverTimestamp(), email: admin.firestore.FieldValue.delete() }, { merge: true });
    } catch (err) {
      console.error('processarExclusao falhou', uid, err);
      try { await ref.set({ status: 'erro', erro: String(err && err.message || err).slice(0, 300) }, { merge: true }); } catch (e2) { console.error('não foi possível gravar o erro', uid, e2); }
    }
    return null;
  });

// Se o LOGIN de uma pessoa deixar de existir (ex.: quem recusou os Termos no cadastro com Google e teve a conta cancelada),
// apaga só o perfil público que o app criou na hora. Idempotente: na exclusão normal o perfil já foi apagado.
exports.limparPerfilDoLoginExcluido = functions.region(REGIAO).auth.user().onDelete(async (user) => {
  await db.collection('usuarios').doc(user.uid).delete().catch((e) => console.error('limparPerfilDoLoginExcluido', user.uid, e.message));
  return null;
});

exports.bloquearRecadastro = functions.region(REGIAO).auth.user().onCreate(async (user) => {
  if (!user.email) return null;
  const d = await db.collection('exclusoes_bloqueadas').doc(hashEmail(user.email)).get();
  if (d.exists && Number(d.data().liberaEm) > Date.now()) {
    await admin.auth().deleteUser(user.uid);
    await db.collection('usuarios').doc(user.uid).delete().catch(() => {});
    return null;
  }
  if (d.exists) await d.ref.delete(); // prazo vencido: libera
  return null;
});

// Assinatura (Mercado Pago)
Object.assign(exports, require('./assinatura'));
Object.assign(exports, require('./loja'));

