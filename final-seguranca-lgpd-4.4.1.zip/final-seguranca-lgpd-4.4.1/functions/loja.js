// FrilaOne — decisão administrativa sobre "Minha Loja" (aprovar / recusar / pedir ajustes). SÓ administrador.
// Autenticação reutilizada: o mesmo token do Firebase Auth e o mesmo critério de administrador das regras (ehDono): claim "admin"
// OU o e-mail do dono com e-mail verificado. O futuro painel administrativo chama esta função (POST + Authorization: Bearer <idToken>);
// nada de decisão é gravado pelo cliente. Não há tela de administração dentro da área do usuário.
// Corpo: { negId: "neg_UID", decisao: "aprovar"|"recusar"|"pendencia"|"recalcular", motivo: "texto (obrigatório em recusar/pendencia)" }
const functions = require('firebase-functions/v1');
const admin = require('firebase-admin');
const L = require('./loja-lib');
const REGIAO = 'southamerica-east1';
const ORIGENS = ['https://frilaone.com.br', 'https://www.frilaone.com.br', 'https://app-frila-one.vercel.app'];
function cors(req, res) {
  const o = req.headers.origin;
  if (ORIGENS.indexOf(o) !== -1) { res.set('Access-Control-Allow-Origin', o); res.set('Vary', 'Origin'); }
  res.set('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.status(204).send(''); return true; }
  return false;
}
const falha = (res, st, erro) => res.status(st).json({ ok: false, erro });
exports.decidirLoja = functions.runWith({ timeoutSeconds: 30 }).region(REGIAO).https.onRequest(async (req, res) => {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return falha(res, 405, 'metodo');
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  let decoded = null; if (m) { try { decoded = await admin.auth().verifyIdToken(m[1]); } catch (e) { decoded = null; } }
  if (!decoded) return falha(res, 401, 'sem_login');
  if (!L.ehAdmin(decoded)) return falha(res, 403, 'somente_administrador');
  try {
    const b = req.body || {};
    const r = await L.decidir({ db: admin.firestore(), negId: b.negId, decisao: b.decisao, motivo: b.motivo, adminUid: decoded.uid });
    if (!r.ok) return falha(res, r.erro === 'loja_inexistente' ? 404 : 400, r.erro);
    return res.json(r);
  } catch (e) { console.error('decidirLoja', e.message); return falha(res, 500, 'erro_servidor'); }
});
