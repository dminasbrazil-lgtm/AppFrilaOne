// FrilaOne — aprovação administrativa de "Minha Loja". Lógica pura (sem Firebase real), usada pela função decidirLoja e pelo
// script migracao/decidir-loja.js. O cliente NUNCA decide: quem escreve estes campos é o servidor (Admin SDK).
//
// Modelo (documento negocios/neg_{uid}):
//   aprovacaoStatus  'pendente' (o app grava ao cadastrar/reenviar) | 'aprovada' | 'pendencia' | 'recusada'  (as 3 últimas: só servidor)
//   publicaAte       até quando a loja pode aparecer na vitrine e abrir. SÓ o servidor grava. 0/ausente = não publicada.
//                    = aprovada ? max(fim da campanha, pagoAte) : 0
//   aprovacaoEm / aprovacaoPor / aprovacaoMotivo   auditoria visível ao dono (motivo da pendência/recusa)
// lojas_autorizadas/{uid}.ate = direito comercial (pagamento) da Minha Loja, também só do servidor/dono do app.
// lojas_gratuitas/{uid} = gratuidade PERMANENTE de lojas específicas (as lojas anteriores à cobrança), concedida só pelo dono do app via
// migracao/marcar-loja-gratuita.js com os negId confirmados por ele. NUNCA por nome, data de cadastro ou qualquer dado que o usuário controle.
// REGRA DE NEGÓCIO: a aprovação NÃO substitui a cobrança — após a campanha (30/11/2026) a loja aprovada só continua publicada
// enquanto houver pagamento (lojas_autorizadas.ate). Não existe ainda fluxo de cobrança da Minha Loja: hoje o pagamento é registrado
// à mão (migracao/autorizar-loja.js).
const CAMPANHA_ATE = Date.parse('2026-11-30T23:59:59-03:00');
const ADMIN_EMAIL = 'frilaoneapp@gmail.com';   // mesmo critério de ehDono() nas regras: claim admin OU este e-mail verificado
const DECISOES = { aprovar: 'aprovada', recusar: 'recusada', pendencia: 'pendencia' };
const PERMANENTE = 9999999999999;   // "sem data de fim" (mesmo valor de ILIMITADO em assinatura-lib.js)
const CHAVES_SERVIDOR = ['publicaAte', 'aprovacaoEm', 'aprovacaoPor', 'aprovacaoMotivo'];

function ehAdmin(decoded) {
  if (!decoded) return false;
  return decoded.admin === true || (decoded.email === ADMIN_EMAIL && decoded.email_verified === true);
}
// Três controles SEPARADOS: (1) aprovação do administrador (status), (2) cobrança (pagoAte), (3) gratuidade permanente concedida pelo dono
// do app a lojas específicas (lojas_gratuitas). Sem aprovação nada é publicado. Com aprovação: gratuita → sem fim; senão → campanha/pago.
function publicaAteDaLoja(status, pagoAte, campanhaAte, gratuita) {
  if (status !== 'aprovada') return 0;
  if (gratuita === true) return PERMANENTE;
  return Math.max(campanhaAte || CAMPANHA_ATE, pagoAte || 0);
}
// lojas_gratuitas/{uid}: só vale se for DESTA loja (negId igual), permanente e não revogada. Gravada só pelo servidor/script.
async function lojaGratuita(db, negId) {
  const g = await db.collection('lojas_gratuitas').doc(String(negId).slice(4)).get();
  if (!g.exists) return false; const d = g.data() || {};
  return d.permanente === true && d.negId === negId && !d.revogadaEm;
}
const idValido = (negId) => /^neg_[A-Za-z0-9]{6,128}$/.test(String(negId || ''));

// decisao: 'aprovar' | 'recusar' | 'pendencia' | 'recalcular' (refaz publicaAte de loja já aprovada, ex.: depois de registrar pagamento)
async function decidir({ db, negId, decisao, motivo = '', adminUid, agora = Date.now(), campanhaAte = CAMPANHA_ATE, simulacao = false }) {
  if (!idValido(negId)) return { ok: false, erro: 'id_invalido' };
  if (decisao !== 'recalcular' && !DECISOES[decisao]) return { ok: false, erro: 'decisao_invalida' };
  motivo = String(motivo || '').trim().slice(0, 500);
  if ((decisao === 'recusar' || decisao === 'pendencia') && !motivo) return { ok: false, erro: 'motivo_obrigatorio' };
  const ref = db.collection('negocios').doc(negId);
  const snap = await ref.get();
  if (!snap.exists) return { ok: false, erro: 'loja_inexistente' };
  const neg = snap.data() || {};
  const dono = negId.slice(4);
  if (neg.uid !== dono) return { ok: false, erro: 'loja_inconsistente' };
  const pag = await db.collection('lojas_autorizadas').doc(dono).get();
  const pagoAte = pag.exists ? Number((pag.data() || {}).ate) || 0 : 0;
  let status;
  if (decisao === 'recalcular') { if (neg.aprovacaoStatus !== 'aprovada') return { ok: true, status: neg.aprovacaoStatus || '', publicaAte: 0, semMudanca: true }; status = 'aprovada'; }
  else status = DECISOES[decisao];
  const gratuita = await lojaGratuita(db, negId);
  const publicaAte = publicaAteDaLoja(status, pagoAte, campanhaAte, gratuita);
  const novo = decisao === 'recalcular' ? { publicaAte } : { aprovacaoStatus: status, publicaAte, aprovacaoEm: agora, aprovacaoPor: adminUid || '', aprovacaoMotivo: status === 'aprovada' ? '' : motivo };
  if (simulacao) return { ok: true, simulacao: true, status, publicaAte, pagoAte, gratuita, publicadaAgora: publicaAte > agora, gravaria: novo };
  await ref.set(novo, { merge: true });
  await db.collection('lojas_decisoes').add({ negId, uid: dono, decisao, status, motivo, publicaAte, pagoAte, gratuita, porUid: adminUid || '', em: agora });
  return { ok: true, status, publicaAte, pagoAte, gratuita, publicadaAgora: publicaAte > agora };
}
module.exports = { decidir, ehAdmin, publicaAteDaLoja, lojaGratuita, idValido, PERMANENTE, CAMPANHA_ATE, ADMIN_EMAIL, CHAVES_SERVIDOR, DECISOES };
