# FrilaOne — servidor (Cloud Functions)

Arquivos: `index.js`, `assinatura.js`, `assinatura-lib.js`, `package.json`  (todos na pasta `functions`). O webhook confere o `x-signature` (precisa do segredo `MP_WEBHOOK_SECRET`).

## O que cada função faz
- `processarExclusao` — apaga a conta quando o app grava `solicitacoes_exclusao/{uid}` e bloqueia o e-mail por 30 dias.
- `bloquearRecadastro` — apaga conta nova criada com e-mail ainda em quarentena (vale para login com Google).
- `criarAssinatura` — cria a assinatura no Mercado Pago e devolve o link para o cliente cadastrar o cartão.
- `sincronizarAssinatura` — confere com o Mercado Pago e atualiza `assinaturas/{uid}`.
- `cancelarAssinatura` — cancela no Mercado Pago (sem novas cobranças).
- `webhookMercadoPago` — recebe o aviso automático do Mercado Pago (confere a assinatura `x-signature`).
- `registrarAceite` — grava o aceite dos Termos/ciência da Política (uid do token; versões e data do servidor).
- `limparPerfilDoLoginExcluido` — apaga o perfil público quando o login é cancelado (ex.: recusa dos Termos no cadastro Google).
- `processarExclusao` — exclusão de conta (refaz se o pedido for regravado como 'pendente'; só conclui se todas as etapas deram certo).
- `statusAcesso` — o app pergunta aqui se a pessoa tem acesso pago (assinatura, teste grátis, código ou acesso manual). Cria o teste grátis UMA vez só.
- `definirModoMaster` — liga/desliga o modo Master da própria pessoa, só se o servidor confirmar o direito.
- `confirmarVerificacao` — confere CPF (dígitos) e selfie e só então grava o selo de verificação.

## Preços (fonte única: `assinatura-lib.js`)
Somente uma área R$ 14,90 · Todas as áreas R$ 34,90 · Minha Loja R$ 79,90.
Primeira cobrança: 1º/12/2026 (quem já está no app). Quem entra depois: 7 dias grátis.

## Publicar (no computador, com o plano Blaze ativo)
1. Instalar o Node.js 20 e depois: `npm i -g firebase-tools`
2. `firebase login`
3. Na pasta do projeto: `firebase init functions` (JavaScript; NÃO sobrescrever os arquivos desta pasta)
4. Guardar os DOIS segredos (o comando pede para colar no terminal; nada aparece em arquivo nem no chat):
   `firebase functions:secrets:set MP_ACCESS_TOKEN`  (primeiro a chave de TESTE; só no fim a de produção)
   `firebase functions:secrets:set MP_WEBHOOK_SECRET`  (chave secreta do webhook, no painel do Mercado Pago → Webhooks → revelar)
5. `firebase deploy --only functions`
6. No painel de desenvolvedores do Mercado Pago → Webhooks, informar:
   `https://southamerica-east1-frilaone-e6247.cloudfunctions.net/webhookMercadoPago`
   com os eventos de "Planos e assinaturas".
7. SÓ DEPOIS de testar: no app, trocar `_ASSINATURA_ATIVA` para `true`.

## Regras de segurança
Publicar `firestore-regras-v16.txt` ANTES do app novo (sem o documento `config/seguranca` ela se comporta como a v15). A coleção `assinaturas` só o servidor grava.

## Ordem de ligação (cada passo é reversível)
1. Regras v16 (sem `config/seguranca`) → nada muda para os usuários.
2. Funções publicadas e testadas com chave de TESTE do Mercado Pago.
3. Preservar direitos já concedidos por códigos antigos: `migracao/preservar-beneficios-codigos.js` (simulação primeiro). O sistema de códigos foi RETIRADO: não existe mais resgate nem coleção `codigos`.
4. Para quem já pagou pelos links antigos: ver `docs/CONCILIACAO-PAGAMENTOS-ANTIGOS.md` e `migracao/conceder-acesso-manual.js` (simulação primeiro; exige o número do pagamento).
5. App novo publicado com `_ASSINATURA_ATIVA = false`; conferir que tudo segue igual.
6. Trocar `_ASSINATURA_ATIVA` para `true` e testar no celular (statusAcesso devolve acesso para usuários existentes).
7. (Opcional) antecipar a exigência de acesso: `config/seguranca` = `{ exigirAcesso: true }`. Em 01/12/2026 a exigência liga sozinha por data. A chave `protegerCampos` não existe mais na v18.
   Reverter: apagar o documento (ou colocar `false`) — efeito imediato.
8. Opcional: `migracao/definir-admin.js UID` para a claim de administrador.

## Não colar nunca chaves ou tokens em chat, print ou arquivo do app.


> Ordem completa de publicação e reversão: `docs/ATIVACAO-SEGURA.md`. `criarAssinatura` reaproveita o link pendente (clique duplo) e cancela links antigos; `sincronizarAssinatura` ('Já assinei') consulta o MP no máximo 1x/15 s.


## v18: campos derivados
`assinaturas/{uid}` recebe do servidor `acessoValidoAte`, `acessoRegraAte` (inclui carência de 3 dias; ILIMITADO para assinatura ativa), `acessoPlano` e `precisaPlano:true` (permanente, impede escapar mudando `tipo`). As regras v18 leem esses campos. Publicar funções **antes** das regras.
