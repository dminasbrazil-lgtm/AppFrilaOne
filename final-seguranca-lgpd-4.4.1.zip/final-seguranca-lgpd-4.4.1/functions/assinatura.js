// FrilaOne — assinatura com cartão (Mercado Pago "Assinaturas"). Quem confirma o pagamento é SEMPRE o servidor.
// O app só chama criarAssinatura / cancelarAssinatura / sincronizarAssinatura e LÊ assinaturas/{uid}.
// O número do cartão nunca passa por aqui: o cliente cadastra no ambiente do Mercado Pago.
const functions = require('firebase-functions/v1');
const admin = require('firebase-admin');
const L = require('./assinatura-lib');
const REGIAO = 'southamerica-east1';
const MP = 'https://api.mercadopago.com';
const ORIGENS = ['https://frilaone.com.br', 'https://www.frilaone.com.br', 'https://app-frila-one.vercel.app'];
const BACK_URL = 'https://frilaone.com.br/?assinatura=retorno';
const opts = functions.runWith({ secrets: ['MP_ACCESS_TOKEN'], timeoutSeconds: 30 });
// O aviso do Mercado Pago precisa também do segredo do webhook (para conferir o x-signature).
const optsWebhook = functions.runWith({ secrets: ['MP_ACCESS_TOKEN', 'MP_WEBHOOK_SECRET'], timeoutSeconds: 30 });
const db = () => admin.firestore();

async function mp(metodo, caminho, corpo, chaveIdem) {
  const h = { Authorization: 'Bearer ' + process.env.MP_ACCESS_TOKEN, 'Content-Type': 'application/json' };
  if (chaveIdem) h['X-Idempotency-Key'] = chaveIdem;
  const r = await fetch(MP + caminho, { method: metodo, headers: h, body: corpo ? JSON.stringify(corpo) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error('mp_' + r.status); e.detalhe = j; throw e; }
  return j;
}
function cors(req, res) {
  const o = req.headers.origin;
  if (ORIGENS.indexOf(o) !== -1) { res.set('Access-Control-Allow-Origin', o); res.set('Vary', 'Origin'); }
  res.set('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.status(204).send(''); return true; }
  return false;
}
async function quem(req) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || '');
  if (!m) return null;
  try { return (await admin.auth().verifyIdToken(m[1])).uid; } catch (e) { return null; }
}
const falha = (res, st, erro, mensagem) => res.status(st).json({ ok: false, erro, mensagem });
const refA = (uid) => db().collection('assinaturas').doc(uid);

// Aplica no banco o que o Mercado Pago diz sobre uma assinatura (usado pelo aviso automático e pela conferência manual).
async function aplicar(uid, pre) {
  const ref = refA(uid);
  const snap = await ref.get();
  const a = snap.exists ? snap.data() : {};
  if (pre.id !== a.preapprovalId && pre.id !== a.novaPreapprovalId) {
    // Assinatura que NÃO é a que acompanhamos (ex.: link anterior que a pessoa acabou autorizando depois de gerar outro).
    // Se estiver ativa/pendente, cancela no Mercado Pago para evitar cobrança em duplicidade; nunca concede acesso por ela.
    if (pre.status === 'authorized' || pre.status === 'pending') { try { await mp('PUT', '/preapproval/' + pre.id, { status: 'cancelled' }); } catch (e) { console.error('cancelar assinatura órfã', e.message); } }
    return a;
  }
  const eNova = pre.id === a.novaPreapprovalId && pre.id !== a.preapprovalId;
  if (eNova) {
    if (pre.status !== 'authorized') return a; // cartão novo ainda não confirmado: mantém o antigo
    try { if (a.preapprovalId) await mp('PUT', '/preapproval/' + a.preapprovalId, { status: 'cancelled' }); } catch (e) { console.error('cancelar antiga', e.message); }
    await ref.set(Object.assign(L.camposDoPreapproval(pre, {}), { preapprovalId: pre.id, novaPreapprovalId: admin.firestore.FieldValue.delete(), acessoAte: admin.firestore.FieldValue.delete() }), { merge: true });
  } else {
    if (a.status === 'cancelled' && pre.status !== 'cancelled') return a; // não "revive" cancelada por aviso atrasado
    await ref.set(L.camposDoPreapproval(pre, a), { merge: true });
  }
  await atualizarAcesso(uid);
  return (await ref.get()).data();
}

exports.criarAssinatura = opts.region(REGIAO).https.onRequest(async (req, res) => {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return falha(res, 405, 'metodo');
  const uid = await quem(req); if (!uid) return falha(res, 401, 'sem_login');
  try {
    const { emailMP, trocar } = req.body || {};
    if (!L.emailValido(emailMP)) return falha(res, 400, 'email_invalido');
    const u = (await db().collection('usuarios').doc(uid).get()).data() || {};
    let plano = L.planoDaConta(u);
    // Quem é Prestador/Acadêmico/Empresa pode escolher "Todas as áreas" ao assinar; o servidor valida o tipo.
    if ((req.body || {}).plano === 'master' && ['prestador', 'academico', 'empresa'].indexOf(u.tipo) !== -1) plano = 'master';
    if (!plano) return falha(res, 400, 'plano_indisponivel');
    const antes = (await refA(uid).get()).data() || {};
    if (antes.status === 'authorized' && !trocar) return falha(res, 409, 'ja_ativa');
    const agora = Date.now();
    // Clique repetido / duas abas: se já existe um link pendente recente para o MESMO plano e e-mail, devolve o mesmo (não cria outra assinatura).
    if (!(trocar && antes.status === 'authorized') && antes.status === 'pending' && antes.preapprovalId && antes.initPoint && antes.plano === plano
        && antes.emailMP === String(emailMP).trim() && agora - (antes.criadoEm || 0) < 30 * 60e3) return res.json({ ok: true, url: antes.initPoint, reaproveitado: true });
    // Link pendente antigo (ou de outro plano/e-mail) é cancelado antes de gerar o novo, para não sobrar duas assinaturas possíveis.
    if (trocar && antes.status === 'authorized' && antes.novaPreapprovalId) {
      try { await mp('PUT', '/preapproval/' + antes.novaPreapprovalId, { status: 'cancelled' }); } catch (e) { console.error('cancelar troca anterior', e.message); }
    }
    if (!(trocar && antes.status === 'authorized') && antes.status === 'pending' && antes.preapprovalId) {
      try { await mp('PUT', '/preapproval/' + antes.preapprovalId, { status: 'cancelled' }); } catch (e) { console.error('cancelar pendente anterior', e.message); }
    }
    const inicio = L.inicioCobranca(agora, trocar && antes.status === 'authorized' ? antes.nextBillingAt : null);
    const pre = await mp('POST', '/preapproval', {
      reason: 'FrilaOne — ' + L.NOMES[plano],
      external_reference: uid,
      payer_email: String(emailMP).trim(),
      back_url: BACK_URL,
      status: 'pending',
      auto_recurring: { frequency: 1, frequency_type: 'months', start_date: new Date(inicio).toISOString(), transaction_amount: L.PRECOS[plano], currency_id: 'BRL' }
    }, uid + '-' + plano + '-' + Math.floor(agora / 300000));   // chave de idempotência do MP: mesma pessoa/plano na mesma janela de 5 min = mesma assinatura
    if (!pre.init_point) throw new Error('sem_init_point');
    if (trocar && antes.status === 'authorized') {
      await refA(uid).set({ novaPreapprovalId: pre.id, novaCriadaEm: agora }, { merge: true });
    } else {
      await refA(uid).set({ status: 'pending', precisaPlano: true, plano, valor: L.PRECOS[plano], preapprovalId: pre.id, initPoint: pre.init_point, emailMP: String(emailMP).trim(), firstChargeAt: inicio, criadoEm: agora, atualizadoEm: agora,
        acessoAte: admin.firestore.FieldValue.delete(), novaPreapprovalId: admin.firestore.FieldValue.delete(), pagamentoRecusado: false }, { merge: true });
    }
    return res.json({ ok: true, url: pre.init_point });
  } catch (e) { console.error('criarAssinatura', uid, e.message, JSON.stringify(e.detalhe || {})); return falha(res, 500, 'erro_servidor'); }
});

exports.sincronizarAssinatura = opts.region(REGIAO).https.onRequest(async (req, res) => {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return falha(res, 405, 'metodo');
  const uid = await quem(req); if (!uid) return falha(res, 401, 'sem_login');
  try {
    const a = (await refA(uid).get()).data();
    if (!a) return res.json({ ok: true, status: 'none' });
    // "Já assinei" repetido: no máximo uma consulta ao Mercado Pago a cada 15 s por pessoa.
    if (a.sincronizadoEm && Date.now() - a.sincronizadoEm < 15000) return res.json({ ok: true, status: a.status, limitado: true });
    await refA(uid).set({ sincronizadoEm: Date.now() }, { merge: true });
    let ultimo = a;
    for (const id of [a.preapprovalId, a.novaPreapprovalId].filter(Boolean)) ultimo = await aplicar(uid, await mp('GET', '/preapproval/' + id));
    return res.json({ ok: true, status: ultimo.status });
  } catch (e) { console.error('sincronizarAssinatura', uid, e.message); return falha(res, 500, 'erro_servidor'); }
});

exports.cancelarAssinatura = opts.region(REGIAO).https.onRequest(async (req, res) => {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return falha(res, 405, 'metodo');
  const uid = await quem(req); if (!uid) return falha(res, 401, 'sem_login');
  try {
    const a = (await refA(uid).get()).data();
    if (!a || !a.preapprovalId) return falha(res, 404, 'sem_assinatura');
    for (const id of [a.preapprovalId, a.novaPreapprovalId].filter(Boolean)) {
      try { await mp('PUT', '/preapproval/' + id, { status: 'cancelled' }); } catch (e) { if (!/mp_(404|400)/.test(e.message)) throw e; }
    }
    await refA(uid).set({ status: 'cancelled', acessoAte: a.acessoAte || a.nextBillingAt || a.firstChargeAt || Date.now(), novaPreapprovalId: admin.firestore.FieldValue.delete(), atualizadoEm: Date.now() }, { merge: true });
    await atualizarAcesso(uid);
    return res.json({ ok: true });
  } catch (e) { console.error('cancelarAssinatura', uid, e.message); return falha(res, 500, 'erro_servidor'); }
});


// ───────────────────────────────────────────────────────────────────────────
// ACESSO PAGO DECIDIDO PELO SERVIDOR (teste grátis, benefício legado, modo Master, verificação)
// ───────────────────────────────────────────────────────────────────────────
const optsLeve = functions.runWith({ timeoutSeconds: 30 });
const refU = (uid) => db().collection('usuarios').doc(uid);

// Recalcula e grava os campos derivados (acessoValidoAte/acessoFonte) e acerta o modo Master
// (quem não tem direito a "Todas as áreas" volta para o plano de uma área). Nunca concede nada que o usuário pediu: só deriva dos fatos.
async function atualizarAcesso(uid) {
  const ref = refA(uid);
  const a = (await ref.get()).data() || {};
  const agora = Date.now();
  const ac = L.calcularAcesso(a, agora);
  const u = (await refU(uid).get()).data() || {};
  const derivados = L.camposDerivados(a, agora);
  // precisaPlano: marcado pelo SERVIDOR na primeira vez que a conta tem tipo de plano (ou assinatura) e NUNCA desmarcado.
  // As regras usam isto além do campo "tipo" (que o usuário escolhe): trocar para Pessoa Física depois não livra do acesso.
  if (a.precisaPlano !== true && (L.planoDaConta(u) || a.status === 'authorized' || a.status === 'pending' || a.status === 'cancelled')) derivados.precisaPlano = true;
  await ref.set(derivados, { merge: true });
  if (u.master_ativo === true && !ac.permiteMaster) {
    await refU(uid).set({ master_ativo: false, master_modo: admin.firestore.FieldValue.delete() }, { merge: true });
  } else if (a.plano === 'master' && a.status === 'authorized' && u.master_ativo !== true && ['prestador', 'academico', 'empresa'].indexOf(u.tipo) !== -1) {
    await refU(uid).set({ master_ativo: true }, { merge: true });   // pagou "Todas as áreas": o servidor liga o modo
  }
  return ac;
}
function resumo(a, ac, agora) {
  return { temAcesso: ac.temAcesso, fonte: ac.fonte, ate: ac.ate === L.ILIMITADO ? null : ac.ate, plano: ac.plano, emCarencia: ac.emCarencia, carenciaAte: ac.carenciaAte,
    permiteMaster: ac.permiteMaster, trialInicio: a.trialInicio || null, trialFim: a.trialFim || null, codigoFim: a.codigoFim || null, agora };
}

// O app chama ao entrar. Cria o teste grátis UMA vez (nunca renova) e devolve o acesso atual.
exports.statusAcesso = optsLeve.region(REGIAO).https.onRequest(async (req, res) => {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return falha(res, 405, 'metodo');
  const uid = await quem(req); if (!uid) return falha(res, 401, 'sem_login');
  try {
    const u = (await refU(uid).get()).data() || {};
    const precisaPlano = !!L.planoDaConta(u);
    const agora = Date.now();
    await db().runTransaction(async (tx) => {
      const s = await tx.get(refA(uid)); const a = s.exists ? s.data() : {};
      if (precisaPlano && !a.trialInicio) { const t = L.inicioTeste(agora); tx.set(refA(uid), { trialInicio: t.inicio, trialFim: t.fim }, { merge: true }); }
    });
    const ac = await atualizarAcesso(uid);
    const a = (await refA(uid).get()).data() || {};
    return res.json({ ok: true, acesso: resumo(a, ac, agora) });
  } catch (e) { console.error('statusAcesso', uid, e.message); return falha(res, 500, 'erro_servidor'); }
});

// Liga/desliga o modo "Todas as áreas" (master_ativo). Ligar só se o servidor confirmar o direito.
exports.definirModoMaster = optsLeve.region(REGIAO).https.onRequest(async (req, res) => {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return falha(res, 405, 'metodo');
  const uid = await quem(req); if (!uid) return falha(res, 401, 'sem_login');
  try {
    const ativo = (req.body || {}).ativo === true;
    if (!ativo) { await refU(uid).set({ master_ativo: false, master_modo: admin.firestore.FieldValue.delete() }, { merge: true }); return res.json({ ok: true, master: false }); }
    const u = (await refU(uid).get()).data() || {};
    if (['prestador', 'academico', 'empresa'].indexOf(u.tipo) === -1) return falha(res, 400, 'plano_indisponivel');
    const ac = await atualizarAcesso(uid);
    if (!ac.permiteMaster) return falha(res, 403, 'sem_direito');
    await refU(uid).set({ master_ativo: true }, { merge: true });
    return res.json({ ok: true, master: true });
  } catch (e) { console.error('definirModoMaster', uid, e.message); return falha(res, 500, 'erro_servidor'); }
});

// Registro de aceite dos Termos de Uso e ciência da Política de Privacidade.
// A pessoa é SEMPRE a do token (nunca um uid vindo do corpo), a data/hora é do servidor e as versões válidas são as daqui:
// o cliente só informa qual versão estava na tela; se estiver desatualizada, o registro é recusado.
// Isto registra ACEITE DOS TERMOS + CIÊNCIA da Política. NÃO é consentimento para finalidades específicas
// (ex.: dado de saúde em pedido de serviço, localização) — esses têm tela e registro próprios.
const TEXTOS_VIGENTES = { termos: '1.1', privacidade: '1.1' }; // atualizar junto com os textos do app (cfgTermos/cfgPrivacidade)
const ACOES_ACEITE = ['cadastro_email', 'cadastro_google', 'reaceite'];
exports.registrarAceite = optsLeve.region(REGIAO).https.onRequest(async (req, res) => {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return falha(res, 405, 'metodo');
  const uid = await quem(req); if (!uid) return falha(res, 401, 'sem_login');
  try {
    const b = req.body || {};
    if (ACOES_ACEITE.indexOf(b.acao) === -1) return falha(res, 400, 'acao_invalida');
    if (b.termosVersao !== TEXTOS_VIGENTES.termos || b.privacidadeVersao !== TEXTOS_VIGENTES.privacidade) return falha(res, 409, 'versao_desatualizada');
    const ref = db().collection('aceites_termos').doc(uid);
    const dado = {
      termosVersao: TEXTOS_VIGENTES.termos,
      privacidadeVersao: TEXTOS_VIGENTES.privacidade,
      aceitoEm: admin.firestore.FieldValue.serverTimestamp(),
      acao: b.acao,
      origem: String(req.headers.origin || '').slice(0, 80),
      agente: String(req.headers['user-agent'] || '').slice(0, 160)
    };
    const lote = db().batch(); // atômico: ou grava o registro e o histórico juntos, ou nenhum
    lote.set(ref, dado, { merge: true });
    lote.set(ref.collection('eventos').doc(), dado); // histórico: cada aceite/reaceite fica guardado
    await lote.commit();
    return res.json({ ok: true, termosVersao: TEXTOS_VIGENTES.termos, privacidadeVersao: TEXTOS_VIGENTES.privacidade });
  } catch (e) { console.error('registrarAceite', uid, e.message); return falha(res, 500, 'erro_servidor'); }
});

// Selo "verificado": só o servidor liga, e só se existir verificacoes/{uid} com CPF válido (algoritmo oficial) e selfie.
// ATENÇÃO: isto NÃO confere o CPF na Receita nem compara o rosto com um documento — é a mesma verificação que o app já fazia, mas agora o usuário não consegue se dar o selo sem enviar os dados.
exports.confirmarVerificacao = optsLeve.region(REGIAO).https.onRequest(async (req, res) => {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return falha(res, 405, 'metodo');
  const uid = await quem(req); if (!uid) return falha(res, 401, 'sem_login');
  try {
    const v = (await db().collection('verificacoes').doc(uid).get()).data();
    if (!v || !L.cpfValido(v.cpf) || typeof v.selfie !== 'string' || v.selfie.length < 200) return falha(res, 400, 'verificacao_incompleta');
    await refU(uid).set({ verificado: true }, { merge: true });
    return res.json({ ok: true });
  } catch (e) { console.error('confirmarVerificacao', uid, e.message); return falha(res, 500, 'erro_servidor'); }
});


// Aviso automático do Mercado Pago (configure esta URL no painel de Webhooks, eventos "Planos e assinaturas").
// Não confiamos no que vem no aviso: ele só diz "olhe a assinatura X"; os dados vêm da API do Mercado Pago com a nossa chave.
exports.webhookMercadoPago = optsWebhook.region(REGIAO).https.onRequest(async (req, res) => {
  try {
    // 1) Autenticidade: nada é lido nem gravado antes de conferir o x-signature.
    const v = L.verificarAssinatura({
      segredo: process.env.MP_WEBHOOK_SECRET,
      xSignature: req.headers['x-signature'],
      xRequestId: req.headers['x-request-id'],
      dataId: (req.query || {})['data.id']
    });
    if (!v.ok) {
      console.warn('webhookMercadoPago rejeitado:', v.motivo);
      return res.status(v.motivo === 'sem_segredo_configurado' ? 500 : 401).send('assinatura invalida');
    }
    const b = req.body || {}, q = req.query || {};
    const tipo = b.type || q.type || q.topic || '';
    const id = q['data.id'] || ''; // só o id assinado na URL (o corpo não é assinado)
    if (!id) return res.status(200).send('ok');
    let preId = '', sinalizar = null;
    if (tipo === 'subscription_preapproval') preId = String(id);
    else if (tipo === 'subscription_authorized_payment') {
      const ap = await mp('GET', '/authorized_payments/' + id);
      preId = String(ap.preapproval_id || '');
      const rec = (ap.payment && ap.payment.status === 'rejected') || ap.status === 'recycling';
      const ok = ap.payment && ap.payment.status === 'approved';
      if (preId && (rec || ok)) sinalizar = !!rec && !ok;   // gravado DEPOIS de aplicar(), senão o status 'authorized' apagaria o aviso
    } else return res.status(200).send('ok');
    if (!preId) return res.status(200).send('ok');
    const pre = await mp('GET', '/preapproval/' + preId);
    if (pre.external_reference) {
      await aplicar(pre.external_reference, pre);
      const atual = (await refA(pre.external_reference).get()).data() || {};
      if (sinalizar !== null && pre.id === atual.preapprovalId) {
        await refA(pre.external_reference).set(sinalizar
          ? { pagamentoRecusado: true, recusadoEm: atual.recusadoEm || Date.now() }
          : { pagamentoRecusado: false, recusadoEm: admin.firestore.FieldValue.delete() }, { merge: true });
      }
      await atualizarAcesso(pre.external_reference);
    }
    return res.status(200).send('ok');
  } catch (e) { console.error('webhookMercadoPago', e.message); return res.status(500).send('erro'); }
});
