// Regras puras da assinatura (sem Firebase e sem rede) — fáceis de testar.
const PRECOS = { golden: 14.90, master: 34.90, diamond: 79.90 };          // R$ por mês (fonte única de verdade)
const NOMES  = { golden: 'Somente uma área', master: 'Todas as áreas de acesso', diamond: 'Minha Loja' };
const CAMPANHA_ATE = Date.parse('2026-11-30T23:59:59-03:00');              // até aqui tudo grátis
const PRIMEIRA_COBRANCA = Date.parse('2026-12-01T09:00:00-03:00');         // 1º/12/2026
const DIAS_TESTE_DEPOIS = 7;                                                // quem entra depois de 1º/12

// Mesma regra do app (_planoDaConta): Pessoa Física não tem plano.
function planoDaConta(u) {
  u = u || {};
  if (u.master_ativo === true) return 'master';
  if (u.tipo === 'negocio') return 'diamond';
  if (['prestador', 'academico', 'empresa'].indexOf(u.tipo) !== -1) return 'golden';
  return '';
}
// Quando começa a primeira cobrança.
function inicioCobranca(agora, proximaExistente) {
  if (proximaExistente && proximaExistente > agora + 3600e3) return proximaExistente; // troca de cartão: mantém a data
  if (agora <= CAMPANHA_ATE) return PRIMEIRA_COBRANCA;
  return agora + DIAS_TESTE_DEPOIS * 86400e3;
}
function emailValido(e) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(e || '').trim()); }
// Do que o Mercado Pago devolve para o que gravamos em assinaturas/{uid}.
function camposDoPreapproval(pre, antes) {
  antes = antes || {};
  const ms = (v) => { const t = Date.parse(v); return isNaN(t) ? null : t; };
  const out = { status: pre.status, atualizadoEm: Date.now() };
  const prox = ms(pre.next_payment_date); if (prox) out.nextBillingAt = prox;
  const ini = ms(pre.auto_recurring && pre.auto_recurring.start_date); if (ini && !antes.firstChargeAt) out.firstChargeAt = ini;
  if (pre.last_four_digits) out.cartaoFinal = String(pre.last_four_digits);
  if (pre.status === 'authorized') out.pagamentoRecusado = false;
  if (pre.status === 'cancelled') out.acessoAte = antes.acessoAte || out.nextBillingAt || antes.nextBillingAt || antes.firstChargeAt || Date.now();
  return out;
}
// Verificação do x-signature do Mercado Pago (HMAC-SHA256).
// Formato do cabeçalho: "ts=1704908010,v1=<hex>". Texto assinado ("manifest"):
//   id:<data.id da URL, minúsculo>;request-id:<cabeçalho x-request-id>;ts:<ts>;
// (partes ausentes são omitidas). Rejeita se faltar qualquer elemento ou se não bater.
const crypto = require('crypto');
function verificarAssinatura(o) {
  o = o || {};
  const seg = String(o.segredo || '');
  if (!seg) return { ok: false, motivo: 'sem_segredo_configurado' };
  const cab = String(o.xSignature || '');
  if (!cab) return { ok: false, motivo: 'sem_assinatura' };
  let ts = '', v1 = '';
  cab.split(',').forEach((p) => { const i = p.indexOf('='); if (i < 0) return; const k = p.slice(0, i).trim(), v = p.slice(i + 1).trim(); if (k === 'ts') ts = v; else if (k === 'v1') v1 = v; });
  if (!ts || !/^[0-9]+$/.test(ts)) return { ok: false, motivo: 'ts_invalido' };
  if (!/^[0-9a-f]{64}$/i.test(v1)) return { ok: false, motivo: 'v1_invalido' };
  const reqId = String(o.xRequestId || '');
  if (!reqId) return { ok: false, motivo: 'sem_request_id' };
  const dataId = o.dataId == null ? '' : String(o.dataId);
  const manifest = (dataId ? 'id:' + dataId.toLowerCase() + ';' : '') + 'request-id:' + reqId + ';ts:' + ts + ';';
  const esperado = Buffer.from(crypto.createHmac('sha256', seg).update(manifest).digest('hex'), 'hex');
  const recebido = Buffer.from(v1, 'hex');
  if (esperado.length !== recebido.length || !crypto.timingSafeEqual(esperado, recebido)) return { ok: false, motivo: 'assinatura_nao_confere' };
  return { ok: true };
}

// ═══════════════════════════════════════════════════════════════════════════
// ACESSO PAGO DECIDIDO PELO SERVIDOR
// Tudo abaixo é função pura (sem Firebase/rede) para poder ser testada.
// Os campos ficam em assinaturas/{uid}, que o usuário só LÊ (regras) — quem grava é o servidor.
// ═══════════════════════════════════════════════════════════════════════════
const DIA = 86400e3;
const CARENCIA = 3 * DIA;               // 3 dias após o fim do teste/código (igual ao app hoje)
const CARENCIA_RECUSADO = 3 * DIA;      // cartão recusado: mantém acesso por 3 dias e depois suspende
const ILIMITADO = 9999999999999;        // "sem data de fim" (assinatura autorizada)

// Teste grátis: criado UMA vez por conta. Até 30/11/2026 vale até 30/11; a partir de 01/12 dura 7 dias.
function inicioTeste(agora) {
  return { inicio: agora, fim: agora <= CAMPANHA_ATE ? CAMPANHA_ATE : agora + DIAS_TESTE_DEPOIS * DIA };
}
// Janelas de acesso válidas agora (assinatura, assinatura cancelada com período pago, teste, benefício legado já concedido, concessão manual).
function calcularAcesso(a, agora) {
  a = a || {}; agora = agora || Date.now();
  const J = [];
  if (a.status === 'authorized') {
    const recusadoVencido = a.pagamentoRecusado === true && a.recusadoEm && agora > a.recusadoEm + CARENCIA_RECUSADO;
    if (!recusadoVencido) J.push({ fonte: 'assinatura', ate: ILIMITADO, plano: a.plano || '' });
  }
  if (a.status === 'cancelled' && a.acessoAte > agora) J.push({ fonte: 'assinatura_cancelada', ate: a.acessoAte, plano: a.plano || '' });
  if (a.trialFim > agora) J.push({ fonte: 'teste', ate: a.trialFim, plano: 'todos' });
  if (a.codigoFim > agora) J.push({ fonte: 'codigo', ate: a.codigoFim, plano: 'todos' });
  if (a.manualAte > agora) J.push({ fonte: 'manual', ate: a.manualAte, plano: a.manualPlano || 'todos' });
  J.sort((x, y) => y.ate - x.ate);
  const ultimoFim = Math.max(a.trialFim || 0, a.codigoFim || 0, a.manualAte || 0);
  const emCarencia = !J.length && ultimoFim > 0 && agora <= ultimoFim + CARENCIA;
  return {
    temAcesso: J.length > 0,
    fonte: J.length ? J[0].fonte : (emCarencia ? 'carencia' : 'nenhuma'),
    ate: J.length ? J[0].ate : 0,
    plano: J.length ? J[0].plano : '',
    permiteMaster: J.some((j) => j.plano === 'master' || j.plano === 'todos'),
    emCarencia: !!emCarencia,
    carenciaAte: emCarencia ? ultimoFim + CARENCIA : 0
  };
}
// Campos derivados que o servidor grava para as regras e para o app ler.
// acessoValidoAte  = fim da janela de acesso (0 se não há); ILIMITADO para assinatura autorizada.
// acessoRegraAte   = até quando as REGRAS do Firestore aceitam (já com a carência de 3 dias; cobre também o período de carência
//                    depois que acessoValidoAte virou 0). As regras comparam SÓ este campo (e, em registros antigos sem ele, usam validoAte + 3 dias).
// acessoPlano      = plano que o acesso cobre ('golden' | 'master' | 'diamond' | 'todos' | ''); informativo: desde a v18.2 as regras NÃO usam acessoPlano para loja (Minha Loja tem autorização própria em lojas_autorizadas).
function camposDerivados(a, agora) {
  a = a || {}; agora = agora || Date.now();
  const ac = calcularAcesso(a, agora);
  let regraAte = 0, plano = '';
  if (ac.temAcesso) { regraAte = ac.ate >= ILIMITADO ? ILIMITADO : ac.ate + CARENCIA; plano = ac.plano || ''; }
  else if (ac.emCarencia) {
    regraAte = ac.carenciaAte;
    const fim = ac.carenciaAte - CARENCIA;   // fim da última janela (teste/benefício/manual)
    plano = (a.manualAte === fim && a.manualPlano) ? a.manualPlano : 'todos';
  }
  return { acessoValidoAte: ac.temAcesso ? ac.ate : 0, acessoRegraAte: regraAte, acessoPlano: plano, acessoFonte: ac.fonte, acessoCalculadoEm: agora };
}

// ── Benefício legado (campo codigoFim) ─────────────────────────────────────
// O antigo sistema de códigos (GP/MN/CV) foi RETIRADO: não existe mais função de resgate nem coleção "codigos".
// O campo assinaturas/{uid}.codigoFim continua sendo respeitado SÓ para preservar direitos já concedidos e ainda válidos
// (gravado apenas pelos scripts migracao/preservar-beneficios-codigos.js ou conceder-acesso-manual.js, rodados por você).
// CPF: mesmo algoritmo do app (usado na confirmação de verificação no servidor)
function cpfValido(cpf) {
  cpf = String(cpf || '').replace(/\D/g, '');
  if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;
  let s = 0; for (let i = 1; i <= 9; i++) s += parseInt(cpf[i - 1]) * (11 - i);
  let r = (s * 10) % 11; if (r === 10) r = 0; if (r !== parseInt(cpf[9])) return false;
  s = 0; for (let i = 1; i <= 10; i++) s += parseInt(cpf[i - 1]) * (12 - i);
  r = (s * 10) % 11; if (r === 10) r = 0; return r === parseInt(cpf[10]);
}

module.exports = { inicioTeste, calcularAcesso, camposDerivados, cpfValido, ILIMITADO, DIA, verificarAssinatura, PRECOS, NOMES, CAMPANHA_ATE, PRIMEIRA_COBRANCA, planoDaConta, inicioCobranca, emailValido, camposDoPreapproval };
