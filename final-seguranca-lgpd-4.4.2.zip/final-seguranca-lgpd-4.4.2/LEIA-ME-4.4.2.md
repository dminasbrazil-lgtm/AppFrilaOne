# FrilaOne — pacote 4.4.2 (revisão — NÃO é "pronto para produção")

## O que mudou em relação ao 4.4.1
Somente `app/teste-final.html`:
1. Botão do Facebook removido do login/cadastro (botão e código dele). Google e e-mail seguem iguais.
2. "Prestar serviço" -> "Prestar Serviço" na tela "O que você quer fazer hoje?".
3. Cadastro de prestador: bloco "Tipo de atendimento" com a mesma estrutura da edição (alinhamento no topo + linha de explicação).
Todo o resto (regras v18.4, functions, migracao, testes, docs) é idêntico ao 4.4.1.

## Estado real
- Regras v18.4: publicadas no Firebase (via CLI) — decisão e ação do dono.
- Migração de dados privados: copiada e verificada; CPF público AINDA existe nos documentos (limpar só depois de tudo confirmado).
- Cloud Functions (exclusão de conta, assinaturas, webhook Mercado Pago): NÃO publicadas (precisa do plano Blaze). Sem elas: exclusão de conta não é processada e não há cobrança.
- `_ASSINATURA_ATIVA` NÃO ativada. Cobrança por data só em 01/12/2026.
- Testado só no preview do Vercel (branch revisão-4.4.1), parcialmente. Não testado: assinatura Mercado Pago ponta a ponta, exclusão de conta, comportamento sem functions em todas as telas.
- Pendente de decisão: loja "Tênis Life"; texto da seção 4 dos Termos (Planos e Pagamentos) ainda genérico, sem campanha gratuita até 30/11 / teste de 7 dias a partir de 01/12.

## Para subir no GitHub (somente a branch revisão-4.4.1, NUNCA a main)
Substituir `app/teste-final.html` (ou subir este zip). A `main` publica sozinha em produção: só mexer nela depois de aprovar o preview.
